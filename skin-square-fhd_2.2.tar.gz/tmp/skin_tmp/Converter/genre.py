#
# Genre-Typen aus der Dokumentation der DVB-Standards
#
# Einige Sender definieren andere Typen, sodass diese Liste erweitert oder ersetzt werden kann..
#
# edited and translated by Maggy
#
maintype = [	_("Reserved"),		
        _("Film/Drama"),
        _("Aktuelles"),
        _("Show Spielshow"),
        _("Sport"),
        _("Kinder/Jugendliche"),
        _("Musik/Ballett/Tanz"),
        _("Kultur/Kunst/Doku"),
        _("Soziales Politik/Wirtschaft"),
        _("Bildung/Wissenschaft / ..."),
        _("Freizeit Hobbys"),
        _("Sonstiges")]


subtype = {}
# Filme/Drama
subtype[1] = [	                
                    _("Film/Drama (allgemein)"),
                    _("Detektiv/Thriller"),
                    _("Abenteuer/Western/Krieg"),
                    _("Science Fiction/Fantasy/Horror"),
                    _("Komoedie"),
                    _("Spielshow/Soap/Melodram/Folklore"),
                    _("Romantik"),
                    _("ernsthafter/klassischer/religioeser/historischer Film/Drama"),
                    _("Erwachsenenfilm/Drama")]

# Nachrichten/Aktuelles
subtype[2] = [				    
                    _("Nachrichten/lokales/Aktuelles (allgemein)"),
                    _("Nachrichten/Wetterbericht"),
                    _("Nachrichtenmagazin"),
                    _("Dokumentation/Dokumentarfilm"),
                    _("Diskussion/Interview / Debatte")]

# Show Spiele show
subtype[3] = [					
                    _("show/spielshow (allgemein)"),
                    _("Spielshow/Quiz/Wettbewerb"),
                    _("Variete"),
                    _("Talkshow")]

# Sports
subtype[4] = [					
                    _("Sport (allgemein)"),
                    _("besondere Ereignisse"),
                    _("Sportmagazin"),
                    _("Fussball"),
                    _("Tennis/Squash"),
                    _("Team-Sport"),
                    _("Leichtathletik"),
                    _("Motorsport"),
                    _("Wassersport"),
                    _("Wintersport"),
                    _("Reiter"),
                    _("Kampfsport")]

# Kinder/Jugendliche
subtype[5] = [					
                    _("Kinder-/Jugendprogramm (allgemein)"),
                    _("Vorschulkinderprogramm"),
                    _("Unterhaltung (6-14 Jahre)"),
                    _("Unterhaltung (10-16 Jahre)"),
                    _("Informations-/Bildungs-/Schulprogramm"),
                    _("Cartoon/Puppen")]

# Musik/Ballet/Tanz
subtype[6] = [
                    _("Musik/Ballett/Tanz (allgemein)"),
                    _("Rock/Pop"),
                    _("ernsthafte Musik/klassische Musik"),
                    _("Volksmusik/traditionelle Musik"),
                    _("Jazz"),
                    _("Musical/Oper"),
                    _("Ballett")]

# KulturKunst/Doku
subtype[7] = [					
                    _("Kultur/Kunst/Doku (allgemein)"),
                    _("darstellende Kueste"),
                    _("Bildende Kunst"),
                    _("Religion"),
                    _("populaire Kultur/traditionelle Kueste"),
                    _("Literatur"),
                    _("Film/Kino"),
                    _("experimenteller Film/Video"),
                    _("Rundfunk/Presse"),
                    _("neue Medien"),
                    _("Kunst-/Kulturmagazin"),
                    _("Mode")]

# Soziales/Politik/Wirtschaft
subtype[8] = [					
                    _("Soziales/Politik/wirtschaftliche Fragen (allgemein)"),
                    _("Zeitschriften/Berichte/Dokumentationen"),
                    _("Wirtschafts-/Sozialberatung"),
                    _("bemerkenswerte Leute")]

# Bildung/Wissenschaft/...
subtype[9] = [					
                    _("Bildung/Wissenschaft/Sachthemen (allgemein)"),
                    _("Natur/Tiere/Umwelt"),
                    _("Technik/Naturwissenschaft"),
                    _("Medizin/Physiologie / Psychologie"),
                    _("Ausland/Expeditionen"),
                    _("Sozial-/Geisteswissenschaft"),
                    _("Weiterbildung"),
                    _("Sprachen")]

# Freizeit Hobbys
subtype[10] = [					
                    _("Freizeithobbys (allgemein)"),
                    _("Tourismus/Reisen"),
                    _("Handwerk"),
                    _("Autofahren"),
                    _("Fitness & Gesundheit"),
                    _("Kochen"),
                    _("Werbung/Shopping"),
                    _("Gartenarbeit")]

# Sonstiges
subtype[11] = [					
                    _("Original Sprache"),
                    _("Schwarz-Weiss"),
                    _("unveroeffentlicht"),
                    _("Live-uebertragung")]

def getGenreStringMain(hn, ln):
#	if hn == 0:
#		return _("Undefinierter Inhalt")
	if hn == 15:
		return _("Benutzerdefiniert")
	if hn > 0 and hn < len(maintype):
		return maintype[hn]
#	return _("Reserved") + " " + str(hn)
	return ""

def getGenreStringSub(hn, ln):
#	if hn == 0:
#		return _("Undefinierter Inhalt") + " " + str(ln)
	if hn == 15:
		return _("Benutzerdefiniert") + " " + str(ln)
	if hn > 0 and hn < len(maintype):
		if ln == 15:
			return _("User defined")
		if ln < len(subtype[hn]):
			return subtype[hn][ln]
#		return _("Reserved") " " + str(ln)
#	return _("Reserved") + " " + str(hn) + "," + str(ln)
	return ""

def getGenreStringLong(hn, ln):
#	if hn == 0:
#		return _("Undefinierter Inhalt") + " " + str(ln)
	if hn == 15:
		return _("Benutzerdefiniert") + " " + str(ln)
	if hn > 0 and hn < len(maintype):
		return maintype[hn] + ": " + getGenreStringSub(hn, ln)
#	return _("Reserved") + " " + str(hn) + "," + str(ln)
	return ""

#
# The End
#
