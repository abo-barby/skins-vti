#!/usr/bin/env python
# -*- coding: utf-8 -*-
#################################################################################
#																				#
#								AdvancedEventLibrary							#
#																				#
#						thanks to scrounger for initial idea					#
#							thanks to hmmmdada for EPGShare						#
#																				#
#						License: this is closed source!							#
#	you are not allowed to use this or parts of it on any other image than VTi	#
#		you are not allowed to use this or parts of it on NON VU Hardware		#
#																				#
#							Copyright: tsiegel 2019								#
#																				#
#################################################################################

import os
import skin
import linecache
import requests
import json
import shutil
from time import localtime
from enigma import eLabel, ePixmap, ePoint, eSize, eTimer, eWidget, loadJPG, loadPNG
from Renderer import Renderer
from skin import parseColor, parseFont
from Components.Sources.Event import Event
from Components.Sources.ExtEvent import ExtEvent
from Components.Sources.extEventInfo import extEventInfo
from Components.Sources.CurrentService import CurrentService
from Components.Sources.ServiceEvent import ServiceEvent
from enigma import iServiceInformation, iPlayableService, iPlayableServicePtr, eServiceCenter
from ServiceReference import ServiceReference
from Components.config import config, ConfigText, ConfigSubsection, ConfigInteger, ConfigSelection
from Tools import AdvancedEventLibrary
from Tools.AdvancedEventLibrary import DB_Functions, getEPGShareExtraData
from thread import start_new_thread

log = "/var/tmp/AdvancedEventLibrary.log"
config.plugins.AdvancedEventLibrary = ConfigSubsection()
config.plugins.AdvancedEventLibrary.Location = ConfigText(default = '/media/hdd/')
dbfolder = config.plugins.AdvancedEventLibrary.dbFolder = ConfigSelection(default="Datenverzeichnis", choices = ["Datenverzeichnis", "Flash"])
dir = config.plugins.AdvancedEventLibrary.Location.value
if not "AdvancedEventLibrary/" in dir:
	dir = dir + "AdvancedEventLibrary/"

def write_log(svalue):
	t = localtime()
	logtime = '%02d:%02d:%02d' % (t.tm_hour, t.tm_min, t.tm_sec)
	Chamaeleon_log = open(log,"a")
	Chamaeleon_log.write(str(logtime) + " : [AdvancedEventLibraryImage] - " + str(svalue) + "\n")
	Chamaeleon_log.close()

class AdvancedEventLibraryImage(Renderer):
	IMAGE = "Image"
	PREFER_IMAGE = "preferImage"
	POSTER = "Poster"
	PREFER_POSTER = "preferPoster"

	def __init__(self):
		Renderer.__init__(self)

		self.scaletype = 1
		self.imageType = self.IMAGE
		self.WCover = self.HCover = 0
		self.foundImage = False
		self.foundPoster = False
		self.ifilename = None
		self.pfilename = None
		self.sizetype = 'Poster'
		self.noImage = None
		self.rotate = "left"
		self.values = None
		self.frameImage = '/usr/share/enigma2/Chamaeleon/png/pigframe.png'
		self.coverPath = AdvancedEventLibrary.getPictureDir()+'cover/'
		self.posterPath = AdvancedEventLibrary.getPictureDir()+'poster/'
		self.nameCache = { }
		self.db = None
		if dbfolder.value == "Flash":
			self.db = DB_Functions('/etc/enigma2/eventLibrary.db')
		else:
			self.db = DB_Functions(dir + 'eventLibrary.db')
		return

	GUI_WIDGET = eWidget

	def applySkin(self, desktop, screen):
		if self.skinAttributes:
			attribs = []
			for attrib, value in self.skinAttributes:
				if attrib == 'size':
					attribs.append((attrib, value))
					x, y = value.split(',')
					self.WCover, self.HCover = int(x), int(y)
				elif attrib == 'position':
					attribs.append((attrib, value))
					x, y = value.split(',')
					self.x, self.y = int(x), int(y)
				elif attrib == 'foregroundColor':
					self.fg = parseColor(str(value))
				elif attrib == 'scale':
					self.scaletype = int(value)
				elif attrib == 'backgroundColor':
					attribs.append((attrib, value))
					self.bg = parseColor(str(value))
				elif attrib == 'imageType':
					params = str(value).split(",")
					self.imageType = params[0]
					if len(params) > 1:
						self.frameImage = params[1]
						self.imageframe.setPixmap(loadPNG(self.frameImage))
					if len(params) > 2:
						self.noImage = params[2]
					if len(params) > 3:
						self.rotate = params[3]
				else:
					attribs.append((attrib, value))

			self.skinAttributes = attribs

		self.image.resize(eSize(self.WCover-20, self.HCover-20))
		self.imageframe.resize(eSize(self.WCover, self.HCover))
		self.imageframe.setScale(1)
		self.imageframe.setAlphatest(1)
		self.image.move(ePoint(10, 10))

		ret = Renderer.applySkin(self, desktop, screen)
		return ret

	def changed(self, what):
		try:
			isMovieFile = None
			event = None
			if not self.instance:
				return
			self.hideimage()
			if hasattr(self.source, 'getEvent'):
				# source is 'extEventInfo'
				event = self.source.getEvent()
			else:#			hasattr(self.source, 'event'):
				# source is 'ServiceEvent' / 'ExtEvent'
				event = self.source.event

			try:
				if hasattr(self.source, 'service'):
					service = self.source.service
					if not isinstance(self.source, CurrentService):
						serviceHandler = eServiceCenter.getInstance()
						info = serviceHandler.info(service)
						path = service.getPath()
						isMovieFile = path
						if path.endswith(".ts") or path.endswith(".mkv") or path.endswith(".mpg") or path.endswith(".avi") or path.endswith(".mp4") or path.endswith(".iso") or path.endswith(".mpeg2") or path.endswith(".wmv"):
							if os.path.isfile(path + '.meta'):
								isMovieFile = linecache.getline(path + '.meta', 2).replace("\n","").strip()
							else:
								isMovieFile = ((str(path).split('/')[-1]).rsplit('.', 1)[0]).replace('_',' ')
						elif path.endswith("/"):
							path = path[:-1]
							isMovieFile = ((str(path).split('/')[-1]).rsplit('.', 1)[0]).replace('_',' ')
#							isMovieFile = path.split('/')[-1]
						elif service.toString() != '':
							tmp = service.toString().rsplit('::', 1)[1].strip()
							if tmp.find('.ts') > 0:
								tmp = tmp[:tmp.find('.ts')]
							if tmp.find('.mkv') > 0:
								tmp = tmp[:tmp.find('.mkv')]
							if tmp.find('.avi') > 0:
								tmp = tmp[:tmp.find('.avi')]
							if tmp.find('.mpg') > 0:
								tmp = tmp[:tmp.find('.mpg')]
							if tmp.find('.mp4') > 0:
								tmp = tmp[:tmp.find('.mp4')]
							if tmp.find('.iso') > 0:
								tmp = tmp[:tmp.find('.iso')]
							if tmp.find('.mpeg2') > 0:
								tmp = tmp[:tmp.find('.mpeg2')]
							if tmp.find('.wmv') > 0:
								tmp = tmp[:tmp.find('.wmv')]
							if tmp.find('(') > 0:
								tmp = tmp[:tmp.find('(')]
							isMovieFile = tmp.strip()
						else:
							isMovieFile = self.removeExtension(info.getName(service))
					else:
						if isinstance(service, iPlayableServicePtr):
							info = service and service.info()
							ref = None
						else: # reference
							info = service and self.source.info
							ref = service
						if info != None:
							name = ref and info.getName(ref)
							if name is None:
								name = info.getName()
								if ref is None:
									if isinstance(self.source, CurrentService):
										ref = self.source.getCurrentServiceReference()
								if ref:
									if ref.getPath():
										isMovieFile = str(ref.getPath())
										serviceHandler = eServiceCenter.getInstance()
										info_tmp = serviceHandler.info(ref)
										if info_tmp:
											event = info_tmp.getEvent(ref)
								else:
									ref = ServiceReference(info.getInfoString(iServiceInformation.sServiceref))
									isMovieFile = os.path.realpath(ref.getPath())
							else:
								ref = ServiceReference(info.getInfoString(iServiceInformation.sServiceref))
								isMovieFile = os.path.realpath(ref.getPath())
			except:
				pass

			# Prüfen ob event tuple ist
			if (isinstance(event, tuple) and event):
				event = event[0]

			if what[0] != self.CHANGED_CLEAR:
				self.foundPoster = False
				self.foundImage = False
				self.pfilename = None
				self.ifilename = None
				self.values = None
				try:
					eventName = self.removeExtension(event.getEventName())
				except:
					eventName = ((str(isMovieFile).split('/')[-1]).rsplit('.', 1)[0]).replace('_',' ')
				eventName = AdvancedEventLibrary.convertDateInFileName(AdvancedEventLibrary.convertSearchName(eventName))
				# wenn DefaultImage aus Share vorhanden, dann dieses anzeigen
				if self.imageType == self.PREFER_IMAGE or self.imageType == self.PREFER_POSTER or self.imageType == self.IMAGE:
					self.ifilename = AdvancedEventLibrary.getEpgShareDefaultImage(eventName)
					if self.ifilename:
						self.foundImage = True
				if not self.foundImage and not self.foundPoster:
					name = AdvancedEventLibrary.convertTitle(eventName)
					pictureName = AdvancedEventLibrary.convert2base64(name) + '.jpg'
					coverFileName = os.path.join(self.coverPath, pictureName)
					posterFileName = os.path.join(self.posterPath, pictureName)
					if (os.path.exists(coverFileName)):
						self.foundImage = True
						self.ifilename = coverFileName
					else:
						name = AdvancedEventLibrary.convertTitle2(eventName)
						pictureName = AdvancedEventLibrary.convert2base64(name) + '.jpg'
						coverFileName = os.path.join(self.coverPath, pictureName)
						if (os.path.exists(coverFileName)):
							self.foundImage = True
							self.ifilename = coverFileName
					if (os.path.exists(posterFileName)):
						self.foundPoster = True
						self.pfilename = posterFileName
					else:
						name = AdvancedEventLibrary.convertTitle2(eventName)
						pictureName = AdvancedEventLibrary.convert2base64(name) + '.jpg'
						posterFileName = os.path.join(self.posterPath, pictureName)
						if (os.path.exists(posterFileName)):
							self.foundPoster = True
							self.pfilename = posterFileName
				if not self.foundImage:
					try:
						eventid = None
						if hasattr(self.source, 'getEvent'):
							eventid = self.source.getEventId()
						else:
							if event != None:
								eventid = event.getEventId()
						if eventid != None and event != None:
							self.ifilename = AdvancedEventLibrary.getEpgShareEventImage(event.getBeginTime(), eventid)
							if self.ifilename:
								self.foundImage = True
							else:
								extraData = getEPGShareExtraData(self.source)
								self.values = self.deserializeJson(extraData)
					except:
						pass

				if not self.foundImage or not self.foundPoster and isMovieFile:
					name = AdvancedEventLibrary.convertDateInFileName(AdvancedEventLibrary.convertSearchName(AdvancedEventLibrary.convertTitle(((str(isMovieFile).split('/')[-1]).rsplit('.', 1)[0]).replace('_',' '))))
					name2 = AdvancedEventLibrary.convertDateInFileName(AdvancedEventLibrary.convertSearchName(AdvancedEventLibrary.convertTitle2(((str(isMovieFile).split('/')[-1]).rsplit('.', 1)[0]).replace('_',' '))))
					pictureName = AdvancedEventLibrary.convert2base64(name) + '.jpg'
					coverFileName = os.path.join(self.coverPath, pictureName)
					posterFileName = os.path.join(self.posterPath, pictureName)
					if (os.path.exists(coverFileName)):
						self.foundImage = True
						self.ifilename = coverFileName
					else:
						pictureName = AdvancedEventLibrary.convert2base64(name2) + '.jpg'
						coverFileName = os.path.join(self.coverPath, pictureName)
						if (os.path.exists(coverFileName)):
							self.foundImage = True
							self.ifilename = coverFileName
					if (os.path.exists(posterFileName)):
						self.foundPoster = True
						self.pfilename = posterFileName
					else:
						pictureName = AdvancedEventLibrary.convert2base64(name2) + '.jpg'
						posterFileName = os.path.join(self.posterPath, pictureName)
						if (os.path.exists(posterFileName)):
							self.foundPoster = True
							self.pfilename = posterFileName

				# set alternative falls angegeben und nix gefunden
				if self.noImage and not self.foundImage and (self.imageType == self.PREFER_IMAGE or self.imageType == self.IMAGE):
					if (os.path.exists(self.noImage)):
						self.foundImage = True
						self.ifilename = self.noImage
				if self.noImage and not self.foundPoster and (self.imageType == self.PREFER_POSTER or self.imageType == self.POSTER):
					if (os.path.exists(self.noImage)):
						self.foundPoster = True
						self.pfilename = self.noImage

				start_new_thread(self.setthePixmap, ())
		except Exception as e:
			write_log("changed : " + str(e))
			self.hideimage()
		return

	def GUIcreate(self, parent):
		self.instance = eWidget(parent)
		self.imageframe = ePixmap(self.instance)
		self.image = ePixmap(self.instance)
		self.imageframe.setPixmap(loadPNG(self.frameImage))

	def showimage(self):
		self.instance.show()
		self.imageframe.show()
		self.image.show()

	def hideimage(self):
		self.labelheight = self.HCover
		self.image.hide()
		self.imageframe.hide()
		self.instance.hide()

	def onShow(self):
		self.suspended = False

	def onHide(self):
		self.suspended = True

	def setthePixmap(self):
		tvMovie = False
		#capi.tvmovie.de/v1/broadcasts?date_from=2020-04-02T22:00:00
		if not self.foundPoster and not self.foundImage and self.values != None:
			try:
				url = 'http://capi.tvmovie.de/v1/broadcast/%s?fields=images.id,previewImage.id' % str(self.values['id'])
				r = requests.get(url, timeout=4)
				if r.status_code == 200:
					res = json.loads(r.content)
					if res['previewImage']['id']:
						imgsize = str(self.WCover) + 'x' + str(self.HCover)
						imgname = '/tmp/aelPreview' + str(imgsize) + '.jpg'
						imgurl = 'http://images.tvmovie.de/' + str(imgsize) + '/North/' + res['previewImage']['id']
						ir = requests.get(imgurl, stream=True, timeout=4)
						if ir.status_code == 200:
							with open(imgname, 'wb') as f:
								ir.raw.decode_content = True
								shutil.copyfileobj(ir.raw, f)
						if os.path.isfile(imgname):
							self.foundImage = True
							self.foundPoster = True
							self.ifilename = imgname
							self.pfilename = imgname
							tvMovie = True
			except Exception as ex:
				write_log("Fehler beim laden des Previewbildes : " + str(ex))

		if self.imageType == self.IMAGE and self.foundImage:
			self.image.setPixmap(loadJPG(self.ifilename))
			self.image.setScale(self.scaletype)
			self.showimage()
			if not tvMovie:
				self.db.updateCoverCalls(os.path.splitext(os.path.basename(self.ifilename))[0])
		elif self.imageType == self.POSTER and self.foundPoster:
			self.image.setPixmap(loadJPG(self.pfilename))
			self.image.setScale(self.scaletype)
			self.showimage()
			self.db.updatePosterCalls(os.path.splitext(os.path.basename(self.pfilename))[0])
		elif self.imageType == self.PREFER_IMAGE and self.foundImage:
			if self.sizetype != 'Image':
				self.calcSize('Image')
			self.sizetype = 'Image'
			self.image.setPixmap(loadJPG(self.ifilename))
			self.image.setScale(self.scaletype)
			self.showimage()
			if not tvMovie:
				self.db.updateCoverCalls(os.path.splitext(os.path.basename(self.ifilename))[0])
		elif self.imageType == self.PREFER_IMAGE and self.foundPoster:
			if self.sizetype != 'Poster':
				self.calcSize('Poster')
			self.sizetype = 'Poster'
			self.image.setPixmap(loadJPG(self.pfilename))
			self.image.setScale(self.scaletype)
			self.showimage()
			self.db.updatePosterCalls(os.path.splitext(os.path.basename(self.pfilename))[0])
		elif self.imageType == self.PREFER_POSTER and self.foundPoster:
			if self.sizetype != 'Poster':
				self.calcSize('Poster')
			self.sizetype = 'Poster'
			self.image.setPixmap(loadJPG(self.pfilename))
			self.image.setScale(self.scaletype)
			self.showimage()
			self.db.updatePosterCalls(os.path.splitext(os.path.basename(self.pfilename))[0])
		elif self.imageType == self.PREFER_POSTER and self.foundImage:
			if self.sizetype != 'Image':
				self.calcSize('Image')
			self.sizetype = 'Image'
			self.image.setPixmap(loadJPG(self.ifilename))
			self.image.setScale(self.scaletype)
			self.showimage()
			if not tvMovie:
				self.db.updateCoverCalls(os.path.splitext(os.path.basename(self.ifilename))[0])
		else:
			self.hideimage()

	def calcSize(self, how):
		if how == 'Poster':
			self.instance.move(ePoint(self.x, self.y))
			self.instance.resize(eSize(self.WCover, self.HCover))
			self.image.resize(eSize(self.WCover-20, self.HCover-20))
			self.imageframe.resize(eSize(self.WCover, self.HCover))
		elif how == 'Image':
			if self.rotate == "left":
				self.instance.move(ePoint(self.x-self.HCover+self.WCover, self.y-self.WCover+self.HCover))
			self.instance.resize(eSize(self.HCover, self.WCover))
			self.image.resize(eSize(self.HCover-20, self.WCover-20))
			self.imageframe.resize(eSize(self.HCover, self.WCover))
		else:
			return
		self.imageframe.setScale(1)
		self.imageframe.setAlphatest(1)
		self.image.move(ePoint(10, 10))
		return

	def deserializeJson(self, extraData):
		try:
			if str(extraData) != '':
				return json.loads(extraData)
			return None
		except:
			return None

	def removeExtension(self, ext):
		ext = ext.replace('.wmv','').replace('.mpeg2','').replace('.ts','').replace('.m2ts','').replace('.mkv','').replace('.avi','').replace('.mpeg','').replace('.mpg','').replace('.iso','').replace('.mp4','')
		return ext