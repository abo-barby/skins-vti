#!/usr/bin/env python
# -*- coding: utf-8 -*-
#################################################################################
#																				#
#								AdvancedEventLibrary							#
#																				#
#						thanks to scrounger for initial idea					#
#							thanks to hmmmdada for EPGShare						#
#																				#
#						License: this is closed source!							#
#	you are not allowed to use this or parts of it on any other image than VTi	#
#		you are not allowed to use this or parts of it on NON VU Hardware		#
#																				#
#							Copyright: tsiegel 2019								#
#																				#
#################################################################################
__all__ = ['randbelow']

import urllib2
import json
import codecs
import os
import base64
import shutil
import requests
import re
import sqlite3
import linecache
import subprocess
from random import SystemRandom
from sqlite3 import Error
from time import time, localtime, strftime
from thread import start_new_thread
from enigma import eEPGCache, iServiceInformation, eServiceReference, eServiceCenter, eTimer, iPlayableServicePtr, iPlayableService
from Screens.ChannelSelection import service_types_tv
from operator import itemgetter
from Components.config import config, ConfigText, ConfigSubsection, ConfigInteger, ConfigYesNo, ConfigSelection
from PIL import Image
from Tools.Alternatives import GetWithAlternative
from Components.Sources.Event import Event
from Components.Sources.ExtEvent import ExtEvent
from Components.Sources.extEventInfo import extEventInfo
from Components.Sources.CurrentService import CurrentService
from Components.Sources.ServiceEvent import ServiceEvent
from Tools.Directories import defaultRecordingLocation
from ServiceReference import ServiceReference
from difflib import get_close_matches

isInstalled = False
try:
	from Plugins.Extensions.AdvancedEventLibrary import tvdbsimple as tvdb
	from Plugins.Extensions.AdvancedEventLibrary import tmdbsimple as tmdb
	isInstalled = True
except:
	pass

log = "/var/tmp/AdvancedEventLibrary.log"

bestmount = defaultRecordingLocation().replace('movie/','') + 'AdvancedEventLibrary/'
config.plugins.AdvancedEventLibrary = ConfigSubsection()
config.plugins.AdvancedEventLibrary.Location = ConfigText(default = bestmount)
dir = config.plugins.AdvancedEventLibrary.Location.value
if not "AdvancedEventLibrary/" in dir:
	dir = dir + "AdvancedEventLibrary/"
addlog = config.plugins.AdvancedEventLibrary.Log = ConfigYesNo(default = False)
coverquality = config.plugins.AdvancedEventLibrary.coverQuality = ConfigSelection(default="w1280", choices = [("w300", "300x169"), ("w780", "780x439"), ("w1280", "1280x720"), ("original", "Original")])
posterquality = config.plugins.AdvancedEventLibrary.posterQuality = ConfigSelection(default="w780", choices = [("w342", "342x513"), ("w500", "500x750"), ("w780", "780x1170"), ("original", "Original")])
coverqualityb = config.plugins.AdvancedEventLibrary.coverQualityb = ConfigSelection(default="w780", choices = [("w300", "300x169"), ("w780", "780x439"), ("w1280", "1280x720")])
posterqualityb = config.plugins.AdvancedEventLibrary.posterQualityb = ConfigSelection(default="w342", choices = [("w185", "185x280"), ("w342", "342x513"), ("w500", "500x750"), ("w780", "780x1170")])
coverqualityDict = {"w300": "300x169", "w780": "780x439", "w1280": "1280x720", "original": "0x0"}
posterqualityDict = {"w342": "342x513", "w500": "500x750", "w780": "780x1170", "original": "0x0"}
searchPlaces = config.plugins.AdvancedEventLibrary.searchPlaces = ConfigText(default = '')
dbfolder = config.plugins.AdvancedEventLibrary.dbFolder = ConfigSelection(default="Datenverzeichnis", choices = ["Datenverzeichnis", "Flash"])

sPDict = {}
if searchPlaces.value != '':
	try:
		sPDict = eval(searchPlaces.value)
	except:
		pass

vtidb_loc = config.misc.db_path.value + '/vtidb.db'

STATUS = None
PARAMETER_SET = 0
PARAMETER_GET = 1

tmdb_genres = {10759 : "Action-Abenteuer", 16 : "Animation", 10762 : "Kinder", 10763 : "News", 10764 : "Reality", 10765 : "Sci-Fi-Fantasy", 10766 : "Soap", 10767 : "Talk", 10768 : "War & Politics", 28 : "Action", 12 : "Abenteuer", 16 : "Animation", 35 : "Comedy", 80 : "Crime", 99 : "Dokumentation", 18 : "Drama", 10751 : "Familie", 14 : "Fantasy", 36 : "History", 27 : "Horror", 10402 : "Music", 9648 : "Mystery", 10749 : "Romance", 878 : "Science-Fiction", 10770 : "TV-Movie", 53 : "Thriller", 10752 : "War", 37 : "Western"}

ApiKeys = {"tmdb": ["ZTQ3YzNmYzJkYzRlMWMwN2UxNGE4OTc1YjI5MTE1NWI=","MDA2ZTU5NGYzMzFiZDc1Nzk5NGQwOTRmM2E0ZmMyYWM=","NTRkMzg1ZjBlYjczZDE0NWZhMjNkNTgyNGNiYWExYzM="], "tvdb": ["NTRLVFNFNzFZWUlYM1Q3WA==","MzRkM2ZjOGZkNzQ0ODA5YjZjYzgwOTMyNjI3ZmE4MTM=","Zjc0NWRiMDIxZDY3MDQ4OGU2MTFmNjY2NDZhMWY4MDQ="], "omdb": ["ZmQwYjkyMTY=","YmY5MTFiZmM=","OWZkNzFjMzI="]}

networks = {
	'3sat': 'DEU',
	'A&E': 'USA',
	'AAG TV': 'PAK',
	'Aaj TV': 'PAK',
	'ABC (US)': 'USA',
	'ABC (AU)': 'AUS',
	'ABC (JA)': 'JPN',
	'ABC (PH)': 'PHL',
	'ABC Family': 'USA',
	'ABS-CBN Broadcasting Company': 'PHL',
	'Abu Dhabi TV': 'ARE',
	'Adult Channel': 'GBR',
	'Al Alam': 'IRN',
	'Al Arabiyya': 'ARE',
	'Al Jazeera': 'QAT',
	'Alpha TV GUJARATI': 'IND',
	'Alpha TV PUNJABI': 'IND',
	'America One Television Network': 'USA',
	'Animal Planet': 'USA',
	'Anime Network': 'USA',
	'ANT1': 'GRC',
	'Antena 3': 'ESP',
	'ARY Digital': 'PAK',
	'ARY Digital': 'PAK',
	'ARY One World': 'PAK',
	'ARY Shopping Channel': 'PAK',
	'ARY Zouq': 'PAK',
	'ATN Aastha Channel': 'IND',
	'AXN': 'USA',
	'B4U Movies': 'GBR',
	'B4U Music': 'GBR',
	'BabyFirstTV': 'USA',
	'BBC America': 'USA',
	'BBC Canada': 'CAN',
	'BBC Four': 'GBR',
	'BBC Kids': 'CAN',
	'BBC News': 'GBR',
	'BBC One': 'GBR',
	'BBC Parliament': 'GBR',
	'BBC Prime': 'GBR',
	'BBC Three': 'GBR',
	'BBC Two': 'GBR',
	'BBC World News': 'GBR',
	'FYI': 'USA',
	'Boomerang': 'USA',
	'BR': 'DEU',
	'BR-alpha': 'DEU',
	'Bravo (US)': 'USA',
	'Bravo (UK)': 'GBR',
	'Bravo (CA)': 'CAN',
	'Bubble Hits': 'IRL',
	'Canal+': 'FRA',
	'Canvas/Ketnet': 'BEL',
	'Carlton Television': 'GBR',
	'Cartoon Network': 'USA',
	'CBBC': 'GBR',
	'CBC (CA)': 'CAN',
	'CBeebies': 'GBR',
	'CBS': 'USA',
	'CCTV': 'CHN',
	'Challenge': 'GBR',
	'Channel [V]': 'CHN',
	'Channel 4': 'GBR',
	'Channel 5': 'SGP',
	'Channel 6': 'IRL',
	'Channel 8': 'SGP',
	'Channel U': 'SGP',
	'Chart Show TV': 'GBR',
	'Chorus Sports': 'IRL',
	'City Channel': 'IRL',
	'Classic Arts Showcase': 'USA',
	'Classic FM TV': 'GBR',
	'CN8': 'USA',
	'CNBC TV18': 'IND',
	'CNN': 'USA',
	'Comedy Channel': 'USA',
	'CPAC': 'CAN',
	'C-Span': 'USA',
	'CTV': 'CAN',
	'DR1': 'DNK',
	'Das Erste': 'DEU',
	'Dawn News': 'PAK',
	'Deutsche Welle TV': 'DEU',
	'Discovery': 'USA',
	'Discovery Kids': 'USA',
	'Dish TV': 'USA',
	'Disney Channel (US)': 'USA',
	'WOWOW': 'JPN',
	'Disney Cinemagic': 'GBR',
	'Doordarshan National': 'IND',
	'DD-Gujarati': 'IND',
	'Doordarshan News': 'IND',
	'Doordarshan Sports': 'IND',
	'E!': 'USA',
	'E! (CA)': 'CAN',
	'E4': 'GBR',
	'EBS': 'KOR',
	'ERT': 'GRC',
	'ESPN': 'USA',
	'ESPN Asia': 'HKG',
	'ESPN Hong Kong': 'HKG',
	'ESPN India': 'IND',
	'ESPN Philippines': 'PHL',
	'ESPN Taiwan': 'TWN',
	'ETV Gujarati': 'IND',
	'Eurosport': 'GBR',
	'Family (CA)': 'CAN',
	'Fashion TV': 'FRA',
	'Five': 'GBR',
	'Five Life': 'GBR',
	'Five US': 'GBR',
	'Fox Reality': 'USA',
	'France 2': 'FRA',
	'France 3': 'FRA',
	'France 4': 'FRA',
	'France 5': 'FRA',
	'France �': 'FRA',
	'Fred TV': 'USA',
	'Fuji TV': 'JPN',
	'FUNimation Channel': 'USA',
	'FX': 'USA',
	'GEO Super': 'PAK',
	'Geo TV': 'PAK',
	'GMA': 'PHL',
	'GSN': 'USA',
	'Guardian Television Network': 'USA',
	'Hallmark Channel': 'USA',
	'Indus Music': 'PAK',
	'Indus News': 'PAK',
	'Indus Vision': 'PAK',
	'Ion Television': 'USA',
	'KanaalTwee': 'BEL',
	'Kashish TV': 'PAK',
	'KBS': 'KOR',
	'Kerrang! TV': 'GBR',
	'Kids and Teens TV': 'USA',
	'KIKA': 'DEU',
	'Kiss': 'GBR',
	'KTN': 'KEN',
	'KTN': 'PAK',
	'LCI': 'FRA',
	'Liberty Channel': 'USA',
	'Liberty TV': 'GBR',
	'Living': 'GBR',
	'M6': 'FRA',
	'Magic': 'GBR',
	'MATV': 'GBR',
	'MBS': 'JPN',
	'MDR': 'DEU',
	'Mega Channel': 'GRC',
	'MTV (US)': 'USA',
	'MTV Base': 'GBR',
	'MTV Dance': 'GBR',
	'MTV Hits': 'USA',
	'MTV2': 'USA',
	'MBC': 'KOR',
	'MUTV': 'GBR',
	'National Geographic (US)': 'USA',
	'NBC': 'USA',
	'NDR': 'DEU',
	'NDTV 24x7': 'IND',
	'NDTV India': 'IND',
	'New Tang Dynasty TV': 'USA',
	'News One': 'PAK',
	'NHK': 'JPN',
	'Nick at Nite': 'USA',
	'Nick GAS': 'USA',
	'Nickelodeon': 'USA',
	'NickToons': 'USA',
	'Nine Network': 'AUS',
	'Noggin': 'USA',
	'NTA': 'NGA',
	'NTV (JP)': 'JPN',
	'Ovation TV': 'USA',
	'Paramount Comedy': 'GBR',
	'PBS': 'USA',
	'PBS Kids Sprout': 'USA',
	'Phoenix': 'DEU',
	'Phoenix TV': 'CHN',
	'Playboy TV': 'USA',
	'Playhouse Disney': 'USA',
	'PlayJam': 'GBR',
	'Press TV': 'IRN',
	'PRO TV': 'ROU',
	'PTV Bolan': 'PAK',
	'PTV Global': 'USA',
	'PTV Home': 'PAK',
	'PTV News': 'PAK',
	'Pub Channel': 'GBR',
	'Q TV': 'GBR',
	'QTV': 'PAK',
	'QVC': 'USA',
	'Radio Bremen': 'DEU',
	'Radio Canada': 'CAN',
	'RAI': 'ITA',
	'RBB': 'DEU',
	'RCTI': 'IDN',
	'Record': 'BRA',
	'Red Hot TV': 'GBR',
	'Rede Globo': 'BRA',
	'Revelation TV': 'GBR',
	'rmusic TV': 'GBR',
	'Royal News': 'PAK',
	'RT� One': 'IRL',
	'RT� Two': 'IRL',
	'RTL Television': 'DEU',
	'RTP A�ores': 'PRT',
	'RTP �frica': 'PRT',
	'RTP Internacional': 'PRT',
	'RTP Madeira': 'PRT',
	'RTP N': 'PRT',
	'RTP1': 'PRT',
	'S4/C': 'GBR',
	'S4C2': 'GBR',
	'Sab TV': 'IND',
	'Sahara ONE': 'IND',
	'Sanskar': 'IND',
	'SBS': 'KOR',
	'SBS (AU)': 'AUS',
	'Scuzz': 'GBR',
	'SET MAX': 'IND',
	'Setanta Ireland': 'IRL',
	'Seven Network': 'AUS',
	'Showtime': 'USA',
	'SIC': 'PRT',
	'SIC Com�dia': 'PRT',
	'SIC Mulher': 'PRT',
	'SIC Not�cias': 'PRT',
	'SIC Radical': 'PRT',
	'SIC Sempre Gold': 'PRT',
	'Sirasa': 'LKA',
	'Sky Box Office': 'GBR',
	'Sky Cinema (UK)': 'GBR',
	'Sky Movies': 'GBR',
	'Sky News': 'GBR',
	'Sky News Ireland': 'IRL',
	'Sky Sports': 'GBR',
	'Sky Travel': 'GBR',
	'Sky1': 'GBR',
	'Sky2': 'GBR',
	'Sky3': 'GBR',
	'Sleuth': 'USA',
	'Smash Hits': 'GBR',
	'SOAPnet': 'USA',
	'Sony Entertainment Television': 'USA',
	'Sony TV': 'IND',
	'Spike TV': 'USA',
	'STAR Gold': 'IND',
	'STAR Movies': 'HKG',
	'STAR News': 'IND',
	'STAR Plus': 'IND',
	'STAR Sports Asia': 'HKG',
	'STAR Sports Hong Kong': 'HKG',
	'STAR Sports India': 'IND',
	'STAR Sports Southeast Asia': 'HKG',
	'STAR Sports Malaysia': 'MYS',
	'STAR Sports Taiwan': 'TWN',
	'STAR Vijay': 'IND',
	'Star World': 'HKG',
	'Starz!': 'USA',
	'Studio 23': 'PHL',
	'STV (UK)': 'GBR',
	'Style': 'USA',
	'SUN music': 'IND',
	'SUN news': 'IND',
	'SUN TV': 'IND',
	'Superstation WGN': 'USA',
	'Swarnawahini': 'LKA',
	'SWR': 'DEU',
	'Tokyo Broadcasting System': 'JPN',
	'TBS': 'USA',
	'TCM': 'GBR',
	'TeleG': 'GBR',
	'Telemundo': 'USA',
	'Televisa': 'MEX',
	'TEN Sports': 'IND',
	'TF1': 'FRA',
	'The Amp': 'GBR',
	'The Box': 'GBR',
	'The CW': 'USA',
	'The Den': 'IRL',
	'TeenNick': 'USA',
	'The WB': 'USA',
	'The Weather Channel': 'USA',
	'TMC': 'MCO',
	'TMF': 'NLD',
	'TNT': 'USA',
	'Toon Disney': 'USA',
	'TQS': 'CAN',
	'Travel Channel (UK)': 'GBR',
	'Treehouse TV': 'CAN',
	'truTV': 'USA',
	'Turner South': 'USA',
	'TV Asahi': 'JPN',
	'TV Cabo': 'PRT',
	'TV Chile': 'CHL',
	'TV Guide Channel': 'USA',
	'TV Land': 'USA',
	'TVOne Global': 'PAK',
	'TV Tokyo': 'JPN',
	'TV5 Monde': 'FRA',
	'TVB': 'CHN',
	'TVBS': 'CHN',
	'TVE': 'ESP',
	'TVG Network': 'USA',
	'TVI': 'PRT',
	'TVM': 'MLT',
	'TVRI': 'IDN',
	'TVS Sydney': 'AUS',
	'UK Entertainment Channel': 'GBR',
	'Eden': 'GBR',
	'UKTV Drama': 'GBR',
	'UKTV Food': 'GBR',
	'Dave': 'GBR',
	'UKTV Gold': 'GBR',
	'UKTV History': 'GBR',
	'UKTV Style': 'GBR',
	'Univision': 'USA',
	'UNTV 37': 'PHL',
	'UPN': 'USA',
	'USA Network': 'USA',
	'UTV': 'IRL',
	'Varsity TV': 'USA',
	'VH1': 'USA',
	'VH1 Classics': 'USA',
	'VijfTV': 'BEL',
	'Volksmusik TV': 'DEU',
	'VT4': 'BEL',
	'VTM': 'BEL',
	'Warner Channel': 'USA',
	'WDR': 'DEU',
	'WE tv': 'USA',
	'XY TV': 'USA',
	'YLE': 'FIN',
	'YTV (CA)': 'CAN',
	'ZDF': 'DEU',
	'Zee Gujarati': 'IND',
	'Zee Cinema': 'IND',
	'Zee Muzic': 'IND',
	'Zee TV': 'IND',
	'ZOOM': 'IND',
	'ITV': 'GBR',
	'BBC HD': 'GBR',
	'ITV1': 'GBR',
	'ITV2': 'GBR',
	'ITV3': 'GBR',
	'ITV4': 'GBR',
	'FOX (US)': 'USA',
	'Space': 'CAN',
	'HBO': 'USA',
	'SciFi': 'USA',
	'Syndicated': '',
	'Showcase (CA)': 'CAN',
	'Teletoon': 'CAN',
	'T�l�toon': 'FRA',
	'TVNZ': 'NZL',
	'Comedy Central (US)': 'USA',
	'TLC': 'USA',
	'Food Network': 'USA',
	'Global': 'CAN',
	'DuMont Television Network': 'USA',
	'History': 'USA',
	'Encore': 'USA',
	'Lifetime': 'USA',
	'��n': 'BEL',
	'G4': 'USA',
	'Revision3': 'USA',
	'Network Ten': 'AUS',
	'Cinemax': 'USA',
	'Canale 5': 'ITA',
	'Oxygen': 'USA',
	'Court TV': 'USA',
	'HGTV': 'USA',
	'CTC': 'JPN',
	'NRK1': 'NOR',
	'NRK2': 'NOR',
	'NRK3': 'NOR',
	'NRK Super': 'NOR',
	'TV 2': 'NOR',
	'TV 2 Zebra': 'NOR',
	'TV 2 Filmkanalen': 'NOR',
	'TV 2 Nyhetskanalen': 'NOR',
	'TV 2 Sport': 'NOR',
	'TV 2 Science Fiction': 'NOR',
	'TVNorge': 'NOR',
	'Viasat 4': 'NOR',
	'FEM': 'GBR',
	'Syfy': 'USA',
	'IFC': 'USA',
	'SundanceTV': 'USA',
	'TV 2': 'DNK',
	'TV 3': 'DNK',
	'Speed': 'USA',
	'TV 4': 'POL',
	'TVN': 'POL',
	'TVN Turbo': 'POL',
	'TVP SA': 'POL',
	'TVP1': 'POL',
	'TVP2': 'POL',
	'Tokyo MX': 'JPN',
	'SAT.1': 'DEU',
	'ProSieben': 'DEU',
	'TV4': 'SWE',
	'History (CA)': 'CAN',
	'BS11': 'JPN',
	'Arte': 'FRA',
	'Planet Green': 'USA',
	'Schweizer Fernsehen': 'CHE',
	'CBC (JP)': 'JPN',
	'HBO Canada': 'CAN',
	'The Movie Network': 'CAN',
	'Movie Central': 'CAN',
	'Travel Channel': 'USA',
	'AMC': 'USA',
	'ORF 1': 'AUT',
	'ORF 2': 'AUT',
	'Animax': 'JPN',
	'Telecinco': 'ESP',
	'La Siete': 'ESP',
	'TVA (JP)': 'JPN',
	'Investigation Discovery': 'USA',
	'TV Azteca': 'MEX',
	'S�ries+': 'CAN',
	'V': 'CAN',
	'Television Osaka': 'JPN',
	'SVT': 'SWE',
	'Zt�l�': 'CAN',
	'Vrak.TV': 'CAN',
	'Casa': 'CAN',
	'Logo': 'USA',
	'Disney XD': 'USA',
	'Prime (NZ)': 'NZL',
	'2�2': 'RUS',
	'TV Nova': 'CZE',
	'Cesk� televize': 'CZE',
	'Prima televize': 'CZE',
	'Science Channel': 'USA',
	'DIY Network': 'USA',
	'AVRO': 'NLD',
	'NCRV': 'NLD',
	'KRO': 'NLD',
	'VPRO': 'NLD',
	'VARA': 'NLD',
	'BNN (NL)': 'NLD',
	'EO': 'NLD',
	'TROS': 'NLD',
	'Veronica': 'NLD',
	'SBS 6': 'NLD',
	'NET 5': 'NLD',
	'BET': 'USA',
	'ORTF': 'FRA',
	'Fox Business': 'USA',
	'AT-X': 'JPN',
	'OWN': 'USA',
	'CMT': 'USA',
	'Cooking Channel': 'USA',
	'HOT': 'ISR',
	'yes': 'ISR',
	'Current TV': 'USA',
	'The Hub': 'USA',
	'1+1': 'UKR',
	'ICTV': 'UKR',
	'Military Channel': 'USA',
	'WealthTV': 'USA',
	'MTV3': 'FIN',
	'Nelonen': 'FIN',
	'TV3 (NZ)': 'NZL',
	'TV 2 Zulu': 'DNK',
	'TV 2 Charlie': 'DNK',
	'TV3+': 'DNK',
	'TV3 Puls': 'DNK',
	'DR2': 'DNK',
	'DR K': 'DNK',
	'DR Ramasjang': 'DNK',
	'Kanal 4': 'DNK',
	'Kanal 5': 'DNK',
	'dk4': 'DNK',
	'Magyar Telev�zi�': 'HUN',
	'Outdoor Channel': 'USA',
	'The Sportsman Channel': 'USA',
	'ATV': 'AUT',
	'Puls 4': 'AUT',
	'Servus TV': 'AUT',
	'LifeStyle': 'AUS',
	'SVT1': 'SWE',
	'SVT2': 'SWE',
	'Kunskapskanalen': 'SWE',
	'SVT24': 'SWE',
	'SVTB': 'SWE',
	'TV11': 'SWE',
	'TV4 Plus': 'SWE',
	'TV4 Guld': 'SWE',
	'TV4 Fakta': 'SWE',
	'TV4 Komedi': 'SWE',
	'TV4 Science Fiction': 'SWE',
	'TV3 (SE)': 'SWE',
	'TV6': 'SWE',
	'TV7 (SE)': 'SWE',
	'TV8': 'SWE',
	'TV8': 'SWE',
	'HDNet': 'USA',
	'JIM': 'FIN',
	'SuoimiTV': 'FIN',
	'Sub': 'FIN',
	'MoonTV': 'FIN',
	'ReelzChannel': 'USA',
	'BYU Television': 'USA',
	'DMAX (DE)': 'DEU',
	'OLN': 'CAN',
	'Action': 'CAN',
	'Rai 1': 'ITA',
	'Rai 2': 'ITA',
	'Rai 3': 'ITA',
	'Rete 4': 'ITA',
	'Italia 1': 'ITA',
	'Joi': 'ITA',
	'Mya': 'ITA',
	'Steel': 'ITA',
	'Fox (IT)': 'ITA',
	'Fox Life': 'ITA',
	'Fox Crime': 'ITA',
	'RTL 4': 'NLD',
	'RTL 5': 'NLD',
	'RTL 7': 'NLD',
	'RTL 8': 'NLD',
	'CNBC': 'USA',
	'ZDF.Kultur': 'DEU',
	'ZDFneo': 'DEU',
	'Kids Station': 'JPN',
	'Watch': 'GBR',
	'YTV (JP)': 'JPN',
	'TNU': 'URY',
	'Canal 10 Saeta': 'URY',
	'Teledoce': 'URY',
	'Canal 4 Montecarlo': 'URY',
	'Tev�Ciudad': 'URY',
	'Encuentro': 'ARG',
	'TV P�blica': 'ARG',
	'Einsfestival': 'DEU',
	'SR': 'DEU',
	'Kyoto Broadcasting System': 'JPN',
	'YTV (UK)': 'GBR',
	'Velocity': 'USA',
	'ITV Granada': 'GBR',
	'Netflix': 'USA',
	'NTR': 'NLD',
	'TV3 (ES)': 'ESP',
	'BNT1': 'BGR',
	'bTV': 'BGR',
	'NovaTV': 'BGR',
	'TV7 (BG)': 'BGR',
	'MNN': 'USA',
	'Voyage': 'FRA',
	'Fox8': 'AUS',
	'CI': 'AUS',
	'LifeStyle FOOD': 'AUS',
	'LifeStyle HOME': 'AUS',
	'MSNBC': 'USA',
	'NHNZ': 'NZL',
	'Kanal 5': 'SWE',
	'RVU': 'NLD',
	'Jupiter Broadcasting ': 'USA',
	'TWiT': 'USA',
	'Smithsonian Channel': 'USA',
	'Discovery HD World': 'SGP',
	'Discovery Turbo UK': 'GBR',
	'Discovery Turbo': 'USA',
	'Discovery Science': 'USA',
	'FOX Traveller': 'IND',
	'DDR1': 'DEU',
	'G4 Canada': 'CAN',
	'H2': 'USA',
	'TV3 (NO)': 'NOR',
	'TG4': 'IRL',
	'Sky Arts': 'GBR',
	'ABC1': 'AUS',
	'ABC2': 'AUS',
	'ABC3': 'AUS',
	'ABC4Kids': 'AUS',
	'ABC News 24': 'AUS',
	'Fuel TV': 'USA',
	'RT': 'RUS',
	'Russia Today': 'RUS',
	'T�l�-Qu�bec': 'CAN',
	'FOX (FI)': 'FIN',
	'C31': 'AUS',
	'La7': 'ITA',
	'LaSexta': 'ITA',
	'Cuatro': 'ESP',
	'YouTube': 'USA',
	'TNT Serie': 'DEU',
	'TFO': 'CAN',
	'TVA': 'CAN',
	'Slice': 'CAN',
	'IKON': 'NLD',
	'KBS TV1': 'KOR',
	'KBS TV2': 'KOR',
	'KBS World': 'KOR',
	'FOX SPORTS': 'AUS',
	'City': 'CAN',
	'tvN': 'KOR',
	'Sky Atlantic': 'GBR',
	'Pick TV': 'GBR',
	'Niconico': 'JPN',
	'W9': 'FRA',
	'Antenne 2': 'FRA',
	'SET TV': 'TWN',
	'Channel 5': 'GBR',
	'Oasis HD': 'CAN',
	'eqhd': 'CAN',
	'radX': 'CAN',
	'HIFI': 'CAN',
	'La Une': 'BEL',
	'La Deux': 'BEL',
	'La Trois': 'BEL',
	'RTL TVI': 'BEL',
	'Club RTL': 'BEL',
	'Plug RTL': 'BEL',
	'SBT': 'BRA',
	'Multishow': 'BRA',
	'Audience Network': 'USA',
	'Sky Uno': 'ITA',
	'Cielo': 'ITA',
	'VIER': 'BEL',
	'2BE': 'BEL',
	'Tele 5': 'DEU',
	'Hulu': 'USA',
	'Star TV': 'TUR',
	'Show TV': 'TUR',
	'Kanal D': 'TUR',
	'Rooster Teeth': 'USA',
	'here!': 'USA',
	'Prime (BE)': 'BEL',
	'laSexta': 'ESP',
	'GNT': 'BRA',
	'NT1': 'FRA',
	'NBCSN': 'USA',
	'Destination America': 'USA',
	'ARTV': 'CAN',
	'Yahoo! Screen': 'USA',
	'Duna TV': 'HUN',
	'H�r TV': 'HUN',
	'National Geographic Adventure': 'USA',
	'Nat Geo Wild': 'USA',
	'More4': 'GBR',
	'National Geographic (UK)': 'GBR',
	'TV Aichi': 'JPN',
	'FTV': 'TWN',
	'CTV (CN)': 'CHN',
	'DR3': 'DNK',
	'Sky Cinema (IT)': 'ITA',
	'TV Cultura': 'BRA',
	'MTV Italia': 'ITA',
	'TV3 (IE)': 'IRL',
	'EinsPlus': 'DEU',
	'TRT 1': 'TUR',
	'RTL': 'LUX',
	'ATV T�rkiye': 'TUR',
	'RCN TV': 'COL',
	'Caracol TV': 'COL',
	'Venevision': 'VEN',
	'Televen': 'VEN',
	'RCTV': 'VEN',
	'Hrvatska radiotelevizija': 'HRV',
	'tvk': 'JPN',
	'Amazon': 'USA',
	'MBC Plus Media': 'KOR',
	'MBN': 'KOR',
	'CGV': 'KOR',
	'OCN': 'KOR',
	'Fox Channel': 'DEU',
	'Ustream': 'USA',
	'BTV': 'CHN',
	'Mnet': 'KOR',
	'Australian Christian Channel': 'AUS',
	'The Africa Channel': 'GBR',
	'Esquire Network': 'USA',
	'ORF III': 'AUT',
	'Nolife': 'FRA',
	'TestTube': 'USA',
	'jTBC': 'KOR',
	'Hunan TV': 'CHN',
	'La Cinq': 'FRA',
	'AlloCin�': 'FRA',
	'FXX': 'USA',
	'BBC ALBA': 'GBR',
	'TVGN': 'USA',
	'SABC1': 'ZAF',
	'SABC2': 'ZAF',
	'SABC3': 'ZAF',
	'SoHo': 'AUS',
	'TheBlaze': 'USA',
	'Comedy (CA)': 'CAN',
	'MTV (UK)': 'GBR',
	'TV One (US)': 'USA',
	'Crackle': 'USA',
	'Nick Jr.': 'USA',
	'Gulli': 'FRA',
	'Canal J': 'FRA',
	'Syndication': 'USA',
	'FOX Sports 1': 'USA',
	'FOX Sports 2': 'USA',
	'Ch�rie 25': 'FRA',
	'NOS': 'NLD',
	'Colors': 'IND',
	'Omroep MAX': 'NLD',
	'PowNed': 'NLD',
	'WNL': 'NLD',
	'The Verge': 'USA',
	'WGN America': 'USA',
	'Adult Swim': 'USA',
	'Super Channel': 'CAN',
	'RLTV': 'USA',
	'W Network': 'CAN',
	'PTS': 'TWN',
	'PTS HD': 'TWN',
	'Hakka TV': 'TWN',
	'TITV': 'TWN',
	'CTS': 'TWN',
	'CTi TV': 'TWN',
	'ETTV': 'TWN',
	'ETTV Yoyo': 'TWN',
	'GTV': 'TWN',
	'MTV Mandarin': 'TWN',
	'NTV (TW)': 'TWN',
	'SET Metro': 'TWN',
	'STAR Chinese Channel': 'TWN',
	'TTV': 'TWN',
	'TVBS Entertainment Channel': 'TWN',
	'Videoland Television Network': 'TWN',
	'DaAi TV': 'TWN',
	'Much TV': 'TWN',
	'Aizo TV': 'TWN',
	'STV (TW)': 'TWN',
	'Nou 24': 'ESP',
	'Nou Televisi�': 'ESP',
	'Teletama': 'JPN',
	'Toei Channel': 'JPN',
	'CTV (JP)': 'JPN',
	'VOX': 'DEU',
	'El Rey Network': 'USA',
	'Sky Living': 'GBR',
	'Channel 3': 'THA',
	'Kamp�s TV': 'TUR',
	'Life OK': 'IND',
	'Canal Once': 'MEX',
	'Food Network Canada': 'CAN',
	'Al Jazeera America': 'USA',
	'HGTV Canada': 'CAN',
	'Discovery Shed': 'GBR',
	'Pivot': 'USA',
	'TVN': 'CHL',
	'Canal 13': 'CHL',
	'MavTV': 'USA',
	'Great American Country': 'USA',
	'D8': 'FRA',
	'BNN': 'CAN',
	'Crime & Investigation Network': 'USA',
	'CSTV': 'KOR',
	'TrueVisions': 'THA',
	'LMN': 'USA',
	'Jeuxvideo.com': 'FRA',
	'Thames Television': 'GBR',
	'Polsat': 'POL',
	'TVN Style': 'POL',
	'Arena': 'AUS',
	'AXS TV': 'USA',
	'TV One (NZ)': 'NZL',
	'TV2': 'NZL',
	'KCET': 'USA',
	'Omroep Brabant': 'NLD',
	'fuse': 'USA',
	'TSN': 'CAN',
	'El Trece': 'ARG',
	'Vimeo': 'USA',
	'Xbox Video': 'USA',
	'FEARnet': 'USA',
	'Channel 7': 'THA',
	'AHC': 'USA',
	'FOX T�rkiye': 'TUR',
	'RTBF': 'BEL',
	'Ora TV': 'USA',
	'Discovery MAX': 'ESP',
	'DMAX (IT)': 'ITA',
	'ITV Wales': 'GBR',
	'OCS': 'FRA',
	'vtmKzoom': 'BEL',
	'TVO': 'CAN',
	'Televisi�n de Galicia': 'ESP',
	'RTL Klub': 'HUN',
	'Showcase (AU)': 'AUS',
	'Canal Sur': 'ESP',
	'RTL Televizija': 'HRV',
	'Discovery Channel (Asia)': 'SGP',
	'Lifetime UK': 'GBR',
	'TSR': 'CHE',
	'RTS Un': 'CHE',
	'SRF 1': 'CHE',
	'Maori Television': 'NZL',
	'MusiquePlus': 'CAN',
	'Spektrum': 'HUN',
	'Disney Channel (Germany)': 'DEU',
	'TeleZ�ri': 'CHE',
	'3+': 'CHE',
	'MBC Every1': 'KOR',
	'Sportsman Channel': 'USA',
	'Anhui TV': 'CHN',
	'Dragon TV': 'CHN',
	'Jiangsu TV': 'CHN',
	'Zhejiang TV': 'CHN',
	'TVS China': 'CHN',
	'NECO': 'JPN',
	'ART TV': 'GRC',
	'Epsilon TV': 'GRC',
	'Skai': 'GRC',
	'TV S�o Carlos': 'BRA',
	'TBN (Trinity Broadcasting Network)': 'USA',
	'Bounce TV': 'USA',
	'HLN': 'USA',
	'APTN': 'CAN',
	'Omni': 'CAN',
	'addikTV': 'CAN',
	'Centric': 'USA',
	'ICI Tou.tv': 'CAN',
	'RDI': 'CAN',
	'TV Osaka': 'JPN',
	'PlayStation Network': 'USA',
	'ICI Explora': 'CAN',
	'MBC Drama': 'KOR',
	'Sky Deutschland': 'DEU',
	'AOL': 'USA',
	'Channel 2': 'ISR',
	'DRAMAcube': 'KOR',
	'Community Channel': 'GBR',
	'This TV': 'USA',
	'Nagoya Broadcasting Network': 'JPN',
	'M-Net': 'ZAF',
	'NFL Network': 'USA',
	'Pop': 'USA',
	'Super!': 'ITA',
	'Cartoon Network Australia': 'AUS',
	'Canadian Learning Television': 'CAN',
	'Oprah Winfrey Network': 'USA',
	'Alpha TV': 'GRC',
	'TV Net': 'TUR',
	'TRT Kurd�': 'TUR',
	'Kanal A (Turkey)': 'TUR',
	'TRT HD': 'TUR',
	'TRT Haber': 'TUR',
	'TRT Belgesel': 'TUR',
	'TRT World': 'TUR',
	'360': 'TUR',
	'TRT T�rk': 'TUR',
	'TRT �ocuk': 'TUR',
	'TRT Avaz': 'TUR',
	'TRT Arabic': 'TUR',
	'TRT Diyanet': 'TUR',
	'TRT Okul': 'TUR',
	'Cine 5': 'TUR',
	'Dost TV': 'TUR',
	'24': 'TUR',
	'Semerkand TV': 'TUR',
	'A Haber': 'TUR',
	'Kanal 7': 'TUR',
	'�lke TV': 'TUR',
	'TGRT Haber': 'TUR',
	'Beyaz TV': 'TUR',
	'L�leg�l TV': 'TUR',
	'HBO Nordic': 'SWE',
	'Bandai Channel': 'JPN',
	'Sixx': 'DEU',
	'element14': 'USA',
	'HBO Magyarorsz�g': 'HUN',
	'HBO Europe': 'HUN',
	'HBO Latin America': 'BRA',
	'Canal Off': 'BRA',
	'ETV': 'EST',
	'Super �cran': 'CAN',
	'Discovery Life': 'USA',
	'The Family Channel': 'USA',
	'Fox Family': 'USA',
	'Canal 9 (AR)': 'ARG',
	'B92': 'SRB',
	'Ceskoslovensk� televize': 'CZE',
	'CNNI': 'USA',
	'Channel 101': 'USA',
	'Canal 5': 'MEX',
	'MyNetworkTV': 'USA',
	'Blip': 'USA',
	'WPIX': 'USA',
	'Canal Famille': 'CAN',
	'Canal D': 'CAN',
	'�vasion': 'CAN',
	'DIY Network Canada': 'CAN',
	'Much (CA)': 'CAN',
	'MTV Brazil': 'BRA',
	'UKTV Yesterday': 'GBR',
	'Swearnet': 'CAN',
	'Dailymotion': 'USA',
	'RMC D�couverte': 'FRA',
	'Discovery Family': 'USA',
	'SBS Plus': 'KOR',
	'Olive': 'KOR',
	'NAVER tvcast': 'KOR',
	'BBC iPlayer': 'GBR',
	'E-Channel': 'KOR',
	'Pakapaka': 'ARG',
	'Trend E': 'KOR',
	'MBC Queen': 'KOR',
	'iQiyi': 'CHN',
	'CW Seed': 'USA',
	'Rede Bandeirantes': 'BRA',
	'NBA TV': 'USA',
	'ITVBe': 'GBR',
	'Comedy Central (UK)': 'GBR',
	'NRJ 12': 'FRA',
	'Gaiam TV ': 'USA',
	'STAR One': 'IND',
	'Canal de las Estrellas': 'MEX',
	'TVQ (Japan)': 'JPN',
	'TVQ (Australia)': 'AUS',
	'UP TV': 'USA',
	'Universal Channel': 'BRA',
	'Golf Channel': 'USA',
	'CITV': 'GBR',
	'SKY PerfecTV!': 'JPN',
	'Disney Junior': 'USA',
	'Mondo TV': 'ITA',
	't�va': 'FRA',
	'MCM': 'FRA',
	'June': 'FRA',
	'Com�die !': 'FRA',
	'Com�die+': 'FRA',
	'Filles TV': 'FRA',
	'Discovery Channel (Australia)': 'AUS',
	'FOX (UK)': 'GBR',
	'Disney Junior (UK)': 'GBR',
	'n-tv': 'DEU',
	'OnStyle': 'KOR'
	}

def write_log(svalue, logging=True):
	if logging:
		t = localtime()
		logtime = '%02d:%02d:%02d' % (t.tm_hour, t.tm_min, t.tm_sec)
		Chamaeleon_log = open(log,"a")
		Chamaeleon_log.write(str(logtime) + " : [AdvancedEventLibrary] - " + str(svalue) + "\n")
		Chamaeleon_log.close()

def randbelow(exclusive_upper_bound):
	if exclusive_upper_bound <= 0:
		return 0
	return SystemRandom()._randbelow(exclusive_upper_bound)

def get_keys(forwhat):
	return base64.b64decode(ApiKeys[forwhat][randbelow(3)])

def convert2base64(title):
	if title.find('(') > 1:
		return base64.b64encode(title.decode('utf-8').lower().split('(')[0].strip()).replace('/','')
	return base64.b64encode(title.decode('utf-8').lower().strip()).replace('/','')

def createDirs(path):
	path = str(path).replace('poster/','').replace('cover/','')
	if not path.endswith('/'):
		path = path + '/'
	if not path.endswith('AdvancedEventLibrary/'):
		path = path + 'AdvancedEventLibrary/'
	if not os.path.exists(path):
		os.makedirs(path)
		os.makedirs(path+'poster/')
		os.makedirs(path+'cover/')
createDirs(dir)

def getPictureDir():
	return dir

def removeExtension(ext):
	ext = ext.replace('.wmv','').replace('.mpeg2','').replace('.ts','').replace('.m2ts','').replace('.mkv','').replace('.avi','').replace('.mpeg','').replace('.mpg','').replace('.iso','').replace('.mp4','')
	return ext

def checkUsedSpace(db=None):
	try:
		if dbfolder.value == "Flash":
			dbpath = '/etc/enigma2/eventLibrary.db'
		else:
			dbpath = os.path.join(getPictureDir(), 'eventLibrary.db')
		if os.path.isfile(dbpath) and db:
			config.plugins.AdvancedEventLibrary.MaxSize = ConfigInteger(default=1, limits=(1, 100))
			if "/etc" in dir:
				maxSize = 1 * 1024.0 * 1024.0
			else:
				maxSize = config.plugins.AdvancedEventLibrary.MaxSize.value * 1024.0 * 1024.0
			PDIR = dir + 'poster/'
			CDIR = dir + 'cover/'
			posterSize = float(subprocess.check_output(['du','-sk', PDIR]).split()[0])
			coverSize = float(subprocess.check_output(['du','-sk', CDIR]).split()[0])
			write_log('benutzter Speicherplatz = ' + str(float(posterSize) + float(coverSize)) + ' kB von ' + str(maxSize) + ' kB.')
			if (posterSize + coverSize) > maxSize:
				i = 0
				while i <= 100:
					titles = db.getUnusedTitles(i)
					if titles:
						write_log('l�sche ' + str(i) + ' mal angesehene Poster und Cover.')
						for title in titles:
							try:
								if os.path.isfile(PDIR + title[0] + '.jpg'):
									os.remove(PDIR + title[0] + '.jpg')
								if os.path.isfile(CDIR + title[0] + '.jpg'):
									os.remove(CDIR + title[0] + '.jpg')
								db.cleanDB(title[0])
							except:
								continue
						posterSize = float(subprocess.check_output(['du','-sk', PDIR]).split()[0])
						coverSize = float(subprocess.check_output(['du','-sk', CDIR]).split()[0])
					if (posterSize + coverSize) < maxSize:
						break
					i +=1
				db.vacuumDB()
				write_log('benutzter Speicherplatz = ' + str(float(posterSize) + float(coverSize)) + ' kB von ' + str(maxSize) + ' kB.')
	except Exception as ex:
		write_log("Fehler in getUsedSpace : " + str(ex))

def removeLogs():
	if os.path.isfile(log):
		os.remove(log)

def startUpdate():
	if isInstalled:
		start_new_thread(getallEventsfromEPG, ())
	else:
		write_log("AdvancedEventLibrary not installed")

def isconnected():
	try:
		return os.system("ping -c 2 -W 2 -w 4 8.8.8.8")
	except Exception as ex:
		write_log("no internet connection! " + str(ex))
		return False

def getAllRecords(db):
	global STATUS
	try:
		STATUS = 'durchsuche Aufnahmeverzeichnisse...'
		PDIR = dir + 'poster/'
		CDIR = dir + 'cover/'
		names = set()
		recordPaths = config.movielist.videodirs.value
		doPics = False
		if "Pictures" in sPDict:
			if sPDict["Pictures"]:
				doPics = True
		else:
			doPics = True
		for recordPath in recordPaths:
			for root, directories, files in os.walk(recordPath):
				if os.path.isdir(root):
					doIt = False
					if str(root) in sPDict:
						if sPDict[root]:
							doIt = True
					fileCount = 0
					if doIt:
						for filename in files:
							try:
								if (filename.endswith('.ts') or filename.endswith('.mkv') or filename.endswith('.avi') or filename.endswith('.mpg') or filename.endswith('.mp4') or filename.endswith('.iso') or filename.endswith('.mpeg2')) and doPics:
									fname = convertDateInFileName(convertSearchName(convertTitle(((filename.split('/')[-1]).rsplit('.', 3)[0]).replace('_',' '))))
									searchName = filename + '.jpg'
									if (os.path.isfile(os.path.join(root,searchName)) and not os.path.isfile(PDIR + convert2base64(fname) + '.jpg')):
										write_log('copy poster ' + str(searchName) + ' nach ' + str(fname) + ".jpg")
										shutil.copy2(os.path.join(root,searchName), PDIR + convert2base64(fname) + ".jpg")
									searchName = removeExtension(filename) + '.jpg'
									if (os.path.isfile(os.path.join(root,searchName)) and not os.path.isfile(PDIR + convert2base64(fname) + '.jpg')):
										write_log('copy poster ' + str(searchName) + ' nach ' + str(fname) + ".jpg")
										shutil.copy2(os.path.join(root,searchName), PDIR + convert2base64(fname) + ".jpg")
									searchName = filename + '.bdp.jpg'
									if (os.path.isfile(os.path.join(root,searchName)) and not os.path.isfile(CDIR + convert2base64(fname) + '.jpg')):
										write_log('copy cover ' + str(searchName) + ' nach ' + str(fname) + ".jpg")
										shutil.copy2(os.path.join(root,searchName), CDIR + convert2base64(fname) + ".jpg")
									searchName = removeExtension(filename) + '.bdp.jpg'
									if (os.path.isfile(os.path.join(root,searchName)) and not os.path.isfile(CDIR + convert2base64(fname) + '.jpg')):
										write_log('copy cover ' + str(searchName) + ' nach ' + str(fname) + ".jpg")
										shutil.copy2(os.path.join(root,searchName), CDIR + convert2base64(fname) + ".jpg")
								if filename.endswith('.meta'):
									fileCount += 1
									foundInBl = False
									name = convertDateInFileName(convertTitle(linecache.getline(os.path.join(root,filename), 2).replace("\n","")))
									if db.getblackList(convert2base64(name)):
										name = convertDateInFileName(convertTitle2(linecache.getline(os.path.join(root,filename), 2).replace("\n","")))
										if db.getblackList(convert2base64(name)):
											foundInBl = True
									if not db.checkTitle(convert2base64(name)) and not foundInBl and name != '' and name != ' ':
										names.add(name)
								if (filename.endswith('.ts') or filename.endswith('.mkv') or filename.endswith('.avi') or filename.endswith('.mpg') or filename.endswith('.mp4') or filename.endswith('.iso') or filename.endswith('.mpeg2')) and doPics:
									foundInBl = False
									name = convertDateInFileName(convertTitle(((filename.split('/')[-1]).rsplit('.', 1)[0]).replace('__',' ').replace('_',' ')))
									if db.getblackList(convert2base64(name)):
										name = convertDateInFileName(convertTitle2(((filename.split('/')[-1]).rsplit('.', 1)[0]).replace('_',' ')))
										if db.getblackList(convert2base64(name)):
											foundInBl = True
									if not db.checkTitle(convert2base64(name)) and not foundInBl and name != '' and name != ' ':
										names.add(name)
							except Exception as ex:
								write_log("Fehler in getAllRecords : " + ' - ' + str(name) + ' - ' + str(ex))
								continue
						write_log('check ' + str(fileCount) + ' meta Files in ' + str(root))
		write_log('found ' + str(len(names)) + ' new Records in meta Files')
#		check vtidb
		doIt = False
		if "VTiDB" in sPDict:
			if sPDict["VTiDB"]:
				doIt = True
		else:
			doIt = True
		if (os.path.isfile(vtidb_loc) and doIt):
			STATUS = 'durchsuche VTI-DB...'
			vtidb_conn = sqlite3.connect(vtidb_loc,check_same_thread=False)
			cur = vtidb_conn.cursor()
			query = "SELECT title FROM moviedb_v0001"
			cur.execute(query)
			rows = cur.fetchall()
			if rows:
				write_log('check ' + str(len(rows)) + ' titles in vtidb')
				for row in rows:
					try:
						if row[0] and row[0] != '' and row[0] != ' ':
							foundInBl = False
							name = convertTitle(row[0])
							if db.getblackList(convert2base64(name)):
								name = convertTitle2(row[0])
								if db.getblackList(convert2base64(name)):
									foundInBl = True
							if not db.checkTitle(convert2base64(name)) and not foundInBl:
								names.add(name)
					except Exception as ex:
						write_log("Fehler in getAllRecords vtidb: " + str(row[0]) + ' - ' + str(ex))
						continue
		write_log('found ' + str(len(names)) + ' new Records')
		return names
	except Exception as ex:
		write_log("Fehler in getAllRecords : " + str(ex))
		return names

def getallEventsfromEPG():
	global STATUS
	try:
		createDirs(dir)
		removeLogs()
		write_log("Update start...")
		write_log("searchOptions " + str(sPDict))
		if dbfolder.value == "Flash":
			db = DB_Functions('/etc/enigma2/eventLibrary.db')
		else:
			db = DB_Functions(os.path.join(getPictureDir(), 'eventLibrary.db'))
		db.parameter(PARAMETER_SET, 'laststart', str(time()))
		checkUsedSpace(db)
		names = getAllRecords(db)
		names = getallEventsfromEPGShare(names, db)
		STATUS = 'durchsuche aktuelles EPG...'
		hHDonly=False
		lines = []
		mask = (eServiceReference.isMarker | eServiceReference.isDirectory)
		root = eServiceReference(str(service_types_tv + ' FROM BOUQUET "bouquets.tv" ORDER BY bouquet'))
		serviceHandler = eServiceCenter.getInstance()
		tvbouquets = serviceHandler.list(root).getContent("SN", True)
		for bouquet in tvbouquets:
			root = eServiceReference(str(bouquet[0]))
			serviceHandler = eServiceCenter.getInstance()
			ret = serviceHandler.list(root).getContent("SN", True)
			doIt = False
			if str(bouquet[1]) in sPDict:
				if sPDict[str(bouquet[1])]:
					doIt = True
			else:
				doIt = True
			if doIt:
				for (serviceref, servicename) in ret:
					playable = not (eServiceReference(serviceref).flags & mask)
					if playable and "p%3a" not in serviceref and "<n/a>" not in servicename and servicename != ".":
						if hHDonly == False or "1:0:19:" in serviceref:
							line = [serviceref,servicename]
							if line not in lines:
								lines.append(line)

		acttime = time() + 1000
		test = ['RITBDSE']
		for line in lines:
			test.append((line[0], 0, acttime, -1))

		epgcache = eEPGCache.getInstance()
		allevents = epgcache.lookupEvent(test) or []
		write_log('found ' + str(len(allevents)) + ' Events in EPG')
		for serviceref, eit, name, begin, duration, shortdesc, extdesc in allevents:
			try:
				foundInBl = False
				name = convertTitle(name)
				if db.getblackList(convert2base64(name)):
					name = convertTitle2(name)
					if db.getblackList(convert2base64(name)):
						foundInBl = True
				if not db.checkTitle(convert2base64(name)) and not foundInBl:
					names.add(name)
			except:
				continue
		write_log('check ' + str(len(names)) + ' new Events')
		get_titleInfo(names)
	except Exception as ex:
		write_log("Fehler in get_allEventsfromEPG : " + str(ex))

def convertTitle(name):
	if name.find(' (') > 0:
		regexfinder = re.compile(r"\([12][90]\d{2}\)", re.IGNORECASE)
		ex = regexfinder.findall(name)
		if not ex:
			name = name[:name.find(' (')]
	if name.find(' S0') > 0:
		name = name[:name.find(' S0')]
	return name

def convertTitle2(name):
	if name.find(' (') > 0:
		regexfinder = re.compile(r"\([12][90]\d{2}\)", re.IGNORECASE)
		ex = regexfinder.findall(name)
		if not ex:
			name = name[:name.find(' (')]
	if name.find(':') > 0:
		name = name[:name.find(':')]
	if name.find(' S0') > 0:
		name = name[:name.find(' S0')]
	if name.find(' -') > 0:
		name = name[:name.find(' -')]
	return name

def convertSearchName(eventName):
	try:
		text = eventName.decode('utf-8', 'ignore').replace(u'\x86', u'').replace(u'\x87', u'').encode('utf-8', 'ignore')
	except:
		text = eventName.decode('utf-8', 'ignore').replace(u'\x86', u'').replace(u'\x87', u'')
	return text

def convertDateInFileName(fileName):
	regexfinder = re.compile('\d{8} - ', re.IGNORECASE)
	ex = regexfinder.findall(fileName)
	if ex:
		return fileName.replace(ex[0], '')
	return fileName

def convertYearInTitle(title):
	regexfinder = re.compile(r"\([12][90]\d{2}\)", re.IGNORECASE)
	ex = regexfinder.findall(title)
	if ex:
		return [title.replace(ex[0], '').strip(), ex[0].replace('(','').replace(')','')]
	return [title, '']

def downloadImage(url, filename, timeout=5):
	try:
		if not os.path.isfile(filename):
			r = requests.get(url, stream=True, timeout=timeout)
			if r.status_code == 200:
				with open(filename, 'wb') as f:
					r.raw.decode_content = True
					shutil.copyfileobj(r.raw, f)
			else:
				write_log("Fehlerhafter Statuscode beim Download f�r : " + str(filename) + ' auf ' + str(url))
		else:
			write_log("Picture : " + str(base64.b64decode(filename.split('/')[-1].replace('.jpg',''))) + ' exists already ', addlog.value)
	except Exception as ex:
		write_log("Fehler in download image: " + str(ex))

def get_titleInfo(titles, research=None, loadImages=True):
	global STATUS
	if isconnected() == 0 and isInstalled:
		if dbfolder.value == "Flash":
			db = DB_Functions('/etc/enigma2/eventLibrary.db')
		else:
			db = DB_Functions(os.path.join(getPictureDir(), 'eventLibrary.db'))
		posterDir = getPictureDir()+'poster/'
		coverDir = getPictureDir()+'cover/'
		posters = 0
		covers = 0
		entrys = 0
		blentrys = 0
		position = 0
		for title in titles:
			try:
				if title and title != '' and title != ' ':
					tvdb.KEYS.API_KEY = get_keys('tvdb')
					tmdb.API_KEY = get_keys('tmdb')
					titleinfo = {
						"title" : "",
						"genre" : "",
						"poster_url" : "",
						"backdrop_url" : "",
						"year" : "",
						"rating" : "",
						"fsk" : "",
						"country" : ""
						}
					titleinfo['title'] = convertSearchName(title)
					titleNyear = convertYearInTitle(title)
					title = convertSearchName(titleNyear[0])
					jahr = str(titleNyear[1])
					position += 1
					org_name = None
					imdb_id = None
					omdb_image = None
					foundAsMovie = False
		#			write_log('################################################### themoviedb movie ##############################################')
					try:
						STATUS = str(position) + '/' + str(len(titles)) + ' : themoviedb movie -' + str(title)  + '  (' + str(posters)  + '|' + str(covers)  + '|' + str(entrys)  + '|' + str(blentrys)  + ')'
						write_log('looking for ' + str(title) + ' on themoviedb movie', addlog.value)
						search = tmdb.Search()
						if jahr != '':
							res = search.movie(query=title, language='de', year=jahr)
						else:
							res = search.movie(query=title, language='de')
						if res:
							if res['results']:
								reslist = []
								for item in res['results']:
									reslist.append(item['title'].lower())
								bestmatch = get_close_matches(title.lower(), reslist, 1, 0.7)
								if not bestmatch:
									bestmatch = [title.lower()]
								for item in res['results']:
									if item['title'].lower() == bestmatch[0]:
										foundAsMovie = True
										write_log('found ' + str(bestmatch[0]) + ' for ' + str(title.lower()) + ' on themoviedb movie', addlog.value)
										if item['original_title']:
											org_name = item['original_title']
										if item['poster_path'] and loadImages:
											if item['poster_path'].endswith('.jpg'):
												titleinfo['poster_url'] = 'http://image.tmdb.org/t/p/' + str(posterqualityb.value) +  item['poster_path']
										if item['backdrop_path'] and loadImages:
											if item['backdrop_path'].endswith('.jpg'):
												titleinfo['backdrop_url'] = 'http://image.tmdb.org/t/p/' + str(coverqualityb.value) +  item['backdrop_path']
										if 'release_date' in item:
											titleinfo['year'] = item['release_date'][:4]
										if item['genre_ids']:
											for genre in item['genre_ids']:
												if not tmdb_genres[genre] in titleinfo['genre']:
													titleinfo['genre'] = titleinfo['genre'] + tmdb_genres[genre] + ' '
										if 'vote_average' in item and item['vote_average'] != "0":
											titleinfo['rating'] = str(item['vote_average'])
										if 'id' in item:
											details = tmdb.Movies(item['id'])
											for country in details.releases(language='de')['countries']:
												if str(country['iso_3166_1']) == "DE":
													titleinfo['fsk'] = str(country['certification'])
													break
											for country in details.info(language='de')['production_countries']:
												titleinfo['country'] = titleinfo['country'] + country['iso_3166_1'] + " | "
											titleinfo['country'] = titleinfo['country'][:-3]
											imdb_id = details.info(language='de')['imdb_id']
											if not titleinfo['poster_url'].startswith('http') or not titleinfo['backdrop_url'].startswith('http') and loadImages:
												try:
													if not titleinfo['backdrop_url'].startswith('http'):
														showimgs = details.images(language='de')['backdrops']
														if showimgs:
															titleinfo['backdrop_url'] = 'http://image.tmdb.org/t/p/' + str(coverqualityb.value) +  showimgs[0]['file_path']
												except Exception as ex:
													pass
												try:
													if not titleinfo['poster_url'].startswith('http'):
														showimgs = details.images(language='de')['posters']
														if showimgs:
															titleinfo['poster_url'] = 'http://image.tmdb.org/t/p/' + str(posterqualityb.value) +  showimgs[0]['file_path']
												except Exception as ex:
													pass
										break
					except Exception as ex:
						write_log('Fehler in get_titleInfo themoviedb movie : ' + str(ex))

		#			write_log('################################################### themoviedb tv ##############################################')
					try:
						if not foundAsMovie:
							STATUS = str(position) + '/' + str(len(titles)) + ' : themoviedb tv -' + str(title)  + '  (' + str(posters)  + '|' + str(covers)  + '|' + str(entrys)  + '|' + str(blentrys)  + ')'
							write_log('looking for ' + str(title) + ' on themoviedb tv', addlog.value)
							search = tmdb.Search()
							if jahr != '':
								res = search.tv(query=title, language='de', year=jahr) 
							else:
								res = search.tv(query=title, language='de') 
							if res:
								if res['results']:
									reslist = []
									for item in res['results']:
										reslist.append(item['name'].lower())
									bestmatch = get_close_matches(title.lower(), reslist, 1, 0.7)
									if not bestmatch:
										bestmatch = [title.lower()]
									for item in res['results']:
										if item['name'].lower() == bestmatch[0]:
											write_log('found ' + str(bestmatch[0]) + ' for ' + str(title.lower()) + ' on themoviedb tv', addlog.value)
											if item['original_name']:
												org_name = item['original_name']
											if item['origin_country']:
												for country in item['origin_country']:
													titleinfo['country'] = titleinfo['country'] + country + ' | '
												titleinfo['country'] = titleinfo['country'][:-3]
											if item['poster_path'] and loadImages:
												if item['poster_path'].endswith('.jpg'):
													titleinfo['poster_url'] = 'http://image.tmdb.org/t/p/' + str(posterqualityb.value) +  item['poster_path']
											if item['backdrop_path'] and loadImages:
												if item['backdrop_path'].endswith('.jpg'):
													titleinfo['backdrop_url'] = 'http://image.tmdb.org/t/p/' + str(coverqualityb.value) +  item['backdrop_path']
											if 'first_air_date' in item:
												titleinfo['year'] = item['first_air_date'][:4]
											if item['genre_ids']:
												for genre in item['genre_ids']:
													if not tmdb_genres[genre] in titleinfo['genre']:
														titleinfo['genre'] = titleinfo['genre'] + tmdb_genres[genre] + '-Serie '
											if 'vote_average' in item and item['vote_average'] != "0":
												titleinfo['rating'] = str(item['vote_average'])
											if 'id' in item:
												details = tmdb.TV(item['id'])
												for country in details.content_ratings(language='de')['results']:
													if str(country['iso_3166_1']) == "DE":
														titleinfo['fsk'] = str(country['rating'])
														break
												if not titleinfo['poster_url'].startswith('http') or not titleinfo['backdrop_url'].startswith('http') and loadImages:
													try:
														if not titleinfo['backdrop_url'].startswith('http'):
															showimgs = details.images(language='de')['backdrops']
															if showimgs:
																titleinfo['backdrop_url'] = 'http://image.tmdb.org/t/p/' + str(coverqualityb.value) +  showimgs[0]['file_path']
													except Exception as ex:
														pass
													try:
														if not titleinfo['poster_url'].startswith('http'):
															showimgs = details.images(language='de')['posters']
															if showimgs:
																titleinfo['poster_url'] = 'http://image.tmdb.org/t/p/' + str(posterqualityb.value) +  showimgs[0]['file_path']
													except Exception as ex:
														pass
											break
					except Exception as ex:
						write_log('Fehler in get_titleInfo themoviedb tv : ' + str(ex))

		#			write_log('################################################### thetvdb ##############################################')
					if not foundAsMovie:
						if titleinfo['genre'] == "" or titleinfo['year'] == "" or titleinfo['country'] == "" or titleinfo['rating'] == "" or titleinfo['fsk'] == "" or titleinfo['poster_url'] == "" or titleinfo['backdrop_url'] == "":
							STATUS = str(position) + '/' + str(len(titles)) + ' : thetvdb -' + str(title)  + '  (' + str(posters)  + '|' + str(covers)  + '|' + str(entrys)  + '|' + str(blentrys)  + ')'
							write_log('looking for ' + str(title) + ' on thetvdb', addlog.value)
							seriesid = None
							search = tvdb.Search()
							try:
								try:
									response = search.series(title, language="de")
									if response:
										reslist = []
										for result in response:
											reslist.append(result['seriesName'].lower())
										bestmatch = get_close_matches(title.lower(), reslist, 1, 0.7)
										if not bestmatch:
											bestmatch = [title.lower()]
										for result in response:
											if result['seriesName'].lower() == bestmatch[0]:
												write_log('found ' + str(bestmatch[0]) + ' for ' + str(title.lower()) + ' on thetvdb', addlog.value)
												seriesid = result['id']
												break
								except Exception as ex:
									try:
										response = search.series(title)
										if response:
											reslist = []
											for result in response:
												reslist.append(result['seriesName'].lower())
											bestmatch = get_close_matches(title.lower(), reslist, 1, 0.7)
											if not bestmatch:
												bestmatch = [title.lower()]
											for result in response:
												if result['seriesName'].lower() == bestmatch[0]:
													write_log('found ' + str(bestmatch[0]) + ' for ' + str(title.lower()) + ' on thetvdb', addlog.value)
													seriesid = result['id']
													break
									except Exception as ex:
										pass

								if seriesid:
									show = tvdb.Series(seriesid)
									response = show.info()
									if response:
										if titleinfo['year'] == "":
											titleinfo['year'] = response['firstAired'][:4]
										if titleinfo['genre'] == "":
											for genre in response['genre']:
												titleinfo['genre'] = titleinfo['genre'] + genre + '-Serie '
										titleinfo['genre'] = titleinfo['genre'].replace("Documentary", "Dokumentation").replace("Children", "Kinder")
										if titleinfo['country'] == "":
											if response['network'] in networks:
												titleinfo['country'] = networks[response['network']]
										imdb_id = response['imdbId']
										if titleinfo['rating'] == "" and response['siteRating'] != "0":
											titleinfo['rating'] = response['siteRating']
										if titleinfo['fsk'] == "":
											if "TV-MA" in str(response['rating']):
												titleinfo['fsk'] = "18"
											elif "TV-PG" in str(response['rating']):
												titleinfo['fsk'] = "16"
											elif "TV-14" in str(response['rating']):
												titleinfo['fsk'] = "12"
											elif "TV-Y7" in str(response['rating']):
												titleinfo['fsk'] = "6"
										if response['poster'] and loadImages:
											if response['poster'].endswith('.jpg') and not titleinfo['poster_url'].startswith('http'):
												titleinfo['poster_url'] = 'https://www.thetvdb.com/banners/' + response['poster']
										if response['fanart'] and loadImages:
											if response['fanart'].endswith('.jpg') and not titleinfo['backdrop_url'].startswith('http'):
												titleinfo['backdrop_url'] = 'https://www.thetvdb.com/banners/' + response['fanart']

										if not titleinfo['poster_url'].startswith('http') or not titleinfo['backdrop_url'].startswith('http') and loadImages:
											showimgs = tvdb.Series_Images(seriesid)
											try:
												if not titleinfo['backdrop_url'].startswith('http'):
													response = showimgs.fanart(language="de")
													if response:
														titleinfo['backdrop_url'] = 'https://www.thetvdb.com/banners/' + response[0]['fileName']
													else:
														response = showimgs.fanart()
														if response:
															titleinfo['backdrop_url'] = 'https://www.thetvdb.com/banners/' + response[0]['fileName']
											except Exception as ex:
												pass
											try:
												if not titleinfo['poster_url'].startswith('http'):
													response = showimgs.poster(language="de")
													if response:
														titleinfo['poster_url'] = 'https://www.thetvdb.com/banners/' + response[0]['fileName']
													else:
														response = showimgs.poster()
														if response:
															titleinfo['backdrop_url'] = 'https://www.thetvdb.com/banners/' + response[0]['fileName']
											except Exception as ex:
												pass
							except Exception as ex:
								write_log('thetvdb : ' + str(ex))


		#			write_log('################################################### maze.tv ##############################################')
					if not foundAsMovie:
						if titleinfo['genre'] == "" or titleinfo['country'] == "" or titleinfo['year'] == "" or titleinfo['rating'] == "" or titleinfo['poster_url'] == "":
							STATUS = str(position) + '/' + str(len(titles)) + ' : maze.tv -' + str(title)  + '  (' + str(posters)  + '|' + str(covers)  + '|' + str(entrys)  + '|' + str(blentrys)  + ')'
							write_log('looking for ' + str(title) + ' on maze.tv', addlog.value)
							try:
								if org_name:
									url = "http://api.tvmaze.com/search/shows?q=%s" % (org_name)
								else:
									url = "http://api.tvmaze.com/search/shows?q=%s" % (title)
								r = requests.get(url, timeout=5)
								if r.status_code == 200:
									res = json.loads(r.content)
									if res:
										reslist = []
										for item in res:
											reslist.append(item['show']['name'].lower())
										bestmatch = get_close_matches(title.lower(), reslist, 1, 0.7)
										if not bestmatch:
											bestmatch = [title.lower()]
										for item in res:
											if item['show']['name'].lower() == bestmatch[0]:
												if item['show']['network']['country'] and titleinfo['country'] == "":
													titleinfo['country'] = item['show']['network']['country']['code']
												if item['show']['premiered'] and titleinfo['year'] == "":
													titleinfo['year'] = item['show']['premiered'][:4]
												if item['show']['genres'] and titleinfo['genre'] == "":
													for genre in item['show']['genres']:
														if not genre in titleinfo['genre']:
															titleinfo['genre'] = titleinfo['genre'] + genre + '-Serie '
													titleinfo['genre'] = titleinfo['genre'].replace("Documentary", "Dokumentation").replace("Children", "Kinder")
												if item['show']['image'] and not titleinfo['poster_url'].startswith('http') and loadImages:
													titleinfo['poster_url'] = item['show']['image']['original']
												if item['show']['rating']['average'] and titleinfo['rating'] == "":
													titleinfo['rating'] = item['show']['rating']['average']
												if item['show']['externals']['imdb'] and not imdb_id:
													imdb_id = item['show']['externals']['imdb']
												break
							except Exception as ex:
								write_log('Fehler in get_titleInfo maze.tv : ' + str(ex))

		#			write_log('################################################### omdb ##############################################')
					if titleinfo['genre'] == "" or titleinfo['year'] == "" or titleinfo['rating'] == "" or titleinfo['fsk'] == "" or titleinfo['poster_url'] == "":
						try:
							STATUS = str(position) + '/' + str(len(titles)) + ' : omdb -' + str(title)  + '  (' + str(posters)  + '|' + str(covers)  + '|' + str(entrys)  + '|' + str(blentrys)  + ')'
							write_log('looking for ' + str(title) + ' on omdb', addlog.value)
							if imdb_id:
								url = "http://www.omdbapi.com/?apikey=%s&i=%s" % (get_keys('omdb'), imdb_id)
							else:
								if org_name:
									url = "http://www.omdbapi.com/?apikey=%s&s=%s&page=1" % (get_keys('omdb'), org_name)
								else:
									url = "http://www.omdbapi.com/?apikey=%s&s=%s&page=1" % (get_keys('omdb'), title)
								r = requests.get(url, timeout=5)
								url = "http://www.omdbapi.com/?apikey=%s&t=%s" % (get_keys('omdb'), title)
								if r.status_code == 200:
									res = json.loads(r.content)
									if res['Response'] == "True":
										reslist = []
										for result in res['Search']:
											reslist.append(result['Title'].lower())
										bestmatch = get_close_matches(title.lower(), reslist, 1, 0.7)
										if not bestmatch:
											bestmatch = [title.lower()]
										for result in res['Search']:
											if result['Title'].lower() == bestmatch[0]:
												url = "http://www.omdbapi.com/?apikey=%s&i=%s" % (get_keys('omdb'), result['imdbID'])
												break

							r = requests.get(url, timeout=5)
							if r.status_code == 200:
								res = json.loads(r.content)
								if res['Response'] == "True":
									if res['Year'] and titleinfo['year'] == "":
										titleinfo['year'] = res['Year'][:4]
									if res['Genre'] != "N/A" and titleinfo['genre'] == "":
										type = ' '
										if res['Type']:
											if res['Type'] == 'series':
												type = '-Serie'
										genres = res['Genre'].split(', ')
										for genre in genres:
											if not genre in titleinfo['genre']:
												titleinfo['genre'] = titleinfo['genre'] + genre + type
										titleinfo['genre'] = titleinfo['genre'].replace("Documentary", "Dokumentation").replace("Children", "Kinder")
									if res['Poster'].startswith('http') and not titleinfo['poster_url'].startswith('http') and loadImages:
										titleinfo['poster_url'] = res['Poster']
										omdb_image = True
									if res['imdbRating'] != "N/A" and titleinfo['rating'] == "":
										titleinfo['rating'] = res['imdbRating']
									if res['Country'] != "N/A" and titleinfo['country'] == "":
										rescountries = res['Country'].split(', ')
										countries = ""
										for country in rescountries:
											countries = countries + country + ' | '
										titleinfo['country'] = countries[:-2].replace('West Germany','DE').replace('East Germany','DE').replace('Germany','DE').replace('France','FR').replace('Canada','CA').replace('Austria','AT').replace('Switzerland','S').replace('Belgium','B').replace('Spain','ESP').replace('Poland','PL').replace('Russia','RU').replace('Czech Republic','CZ').replace('Netherlands','NL').replace('Italy','IT')
									if res['imdbID'] != "N/A" and not imdb_id:
										imdb_id = res['imdbID']
									if titleinfo['fsk'] == "" and res['Rated'] != "N/A":
										if "R" in str(res['Rated']):
											titleinfo['fsk'] = "18"
										elif "TV-MA" in str(res['Rated']):
											titleinfo['fsk'] = "18"
										elif "TV-PG" in str(res['Rated']):
											titleinfo['fsk'] = "16"
										elif "TV-14" in str(res['Rated']):
											titleinfo['fsk'] = "12"
										elif "TV-Y7" in str(res['Rated']):
											titleinfo['fsk'] = "6"
										elif "PG-13" in str(res['Rated']):
											titleinfo['fsk'] = "12"
										elif "PG" in str(res['Rated']):
											titleinfo['fsk'] = "6"
										elif "G" in str(res['Rated']):
											titleinfo['fsk'] = "16"
						except Exception as ex:
							write_log('Fehler in get_titleInfo omdb : ' + str(ex))

					if imdb_id and titleinfo['fsk'] == "":
						try:
							STATUS = str(position) + '/' + str(len(titles)) + ' : altersfreigaben.de -' + str(title)  + '  (' + str(posters)  + '|' + str(covers)  + '|' + str(entrys)  + '|' + str(blentrys)  + ')'
							write_log('looking for fsk on altersfreigaben.de', addlog.value)
							url = "https://altersfreigaben.de/api2/s/%s/de" % (imdb_id)
							r = requests.get(url, timeout=6)
							if r.status_code == 200:
								if r.content not in ['100', '300', '310']:
									titleinfo['fsk'] = r.content
									write_log("found FSK " + str(titleinfo['fsk']) + " for " + str(title) + " on altersfreigaben.de", addlog.value)
						except Exception as ex:
							write_log('Fehler in get_titleInfo altersfreigaben.de : ' + str(ex))

					filename = convert2base64(title)
					if filename and filename != '' and filename != ' ':
						if titleinfo['genre'] == "" and titleinfo['year'] == "" and titleinfo['rating'] == "" and titleinfo['fsk'] == "" and titleinfo['country'] == "" and titleinfo['poster_url'] == "" and titleinfo['backdrop_url'] == "":
							blentrys += 1
							db.addblackList(filename)
							write_log('nothing found for : ' + str(titleinfo['title']), addlog.value)

						if titleinfo['genre'] != "" or titleinfo['year'] != "" or titleinfo['rating'] != "" or titleinfo['fsk'] != "" or titleinfo['country'] != "":
							entrys += 1
							if research:
								if db.checkTitle(research):
									db.updateTitleInfo(titleinfo['title'],titleinfo['genre'],titleinfo['year'],titleinfo['rating'],titleinfo['fsk'],titleinfo['country'],research)
								else:
									db.addTitleInfo(filename,titleinfo['title'],titleinfo['genre'],titleinfo['year'],titleinfo['rating'],titleinfo['fsk'],titleinfo['country'])
							else:
								db.addTitleInfo(filename,titleinfo['title'],titleinfo['genre'],titleinfo['year'],titleinfo['rating'],titleinfo['fsk'],titleinfo['country'])
							write_log('found data for : ' + str(titleinfo['title']), addlog.value)
						if titleinfo['poster_url'] and loadImages:
							if titleinfo['poster_url'].startswith('http'):
								posters += 1
								if research:
									downloadImage(titleinfo['poster_url'], os.path.join(posterDir, research +'.jpg'))
								else:
									downloadImage(titleinfo['poster_url'], os.path.join(posterDir, filename +'.jpg'))
								if omdb_image:
									img = Image.open(os.path.join(posterDir, filename +'.jpg'))
									w, h = img.size
									if w > h:
										shutil.move(os.path.join(posterDir, filename +'.jpg'), os.path.join(coverDir, filename +'.jpg'))
									img = None
						if titleinfo['backdrop_url'] and loadImages:
							if titleinfo['backdrop_url'].startswith('http'):
								covers += 1
								if research:
									downloadImage(titleinfo['backdrop_url'], os.path.join(coverDir, research +'.jpg'))
								else:
									downloadImage(titleinfo['backdrop_url'], os.path.join(coverDir, filename +'.jpg'))
					db.parameter(PARAMETER_SET, 'laststop', str(time()))
			except Exception as ex:
				write_log("Fehler in get_titleInfo for : " + str(title) + ' infos = ' + str(titleinfo) + ' : ' + str(ex))
				continue
		write_log("set " + str(entrys) + " on eventInfo")
		write_log("set " + str(blentrys) + " on Blacklist")
		if loadImages:
			write_log("found " + str(posters) + " posters")
			write_log("found " + str(covers) + " covers")
		write_log("Update done")
		db.parameter(PARAMETER_SET, 'laststop', str(time()))
		STATUS = None
		if research:
			return True
	else:
		STATUS = None
		if research:
			return False


def get_PictureList(title, what='Cover', count=20, b64title=None):
	if isconnected() == 0 and isInstalled:
		posterDir = getPictureDir()+'poster/'
		coverDir = getPictureDir()+'cover/'
		tvdb.KEYS.API_KEY = get_keys('tvdb')
		tmdb.API_KEY = get_keys('tmdb')
		pictureList = []
		try:
			titleNyear = convertYearInTitle(title)
			title = convertSearchName(titleNyear[0])
			jahr = str(titleNyear[1])
			write_log('searching ' + str(what) + ' for ' + str(title) + ' with year ' + str(jahr))
			if not b64title:
				b64title = convert2base64(title)
#			write_log('################################################### themoviedb tv ##############################################')
			try:
				search = tmdb.Search()
				if jahr != '':
					res = search.tv(query=title, language='de', year=jahr)
				else:
					res = search.tv(query=title, language='de')
				if res:
					if res['results']:
						reslist = []
						for item in res['results']:
							reslist.append(item['name'].lower())
						bestmatch = get_close_matches(title.lower(), reslist, 4, 0.6)
						if not bestmatch:
							bestmatch = [title.lower()]
						for item in res['results']:
							write_log('found on TMDb TV ' + str(item['name']))
							if item['name'].lower() in bestmatch:
								if 'id' in item:
									idx = tmdb.TV(item['id'])
									try:
										if what == 'Cover':
											imgs = idx.images(language='de')['backdrops']
											if imgs:
												for img in imgs:
													if coverquality.value != "original":
														imgsize = coverqualityDict[coverquality.value]
													else:
														imgsize = str(img['width']) + 'x' + str(img['height'])
													itm = [item['name'], what, str(imgsize) + ' gefunden auf TMDb TV', 'http://image.tmdb.org/t/p/' + str(coverquality.value) + img['file_path'], os.path.join(coverDir, b64title +'.jpg'), convert2base64(img['file_path']) +'.jpg']
													pictureList.append((itm,))
											if len(imgs) < 2:
												imgs = idx.images()['backdrops']
												if imgs:
													for img in imgs:
														if coverquality.value != "original":
															imgsize = coverqualityDict[coverquality.value]
														else:
															imgsize = str(img['width']) + 'x' + str(img['height'])
														itm = [item['name'], what, str(imgsize) + ' gefunden auf TMDb TV', 'http://image.tmdb.org/t/p/' + str(coverquality.value) + img['file_path'], os.path.join(coverDir, b64title +'.jpg'), convert2base64(img['file_path']) +'.jpg']
														pictureList.append((itm,))
									except:
										pass
									try:
										if what == 'Poster':
											imgs = idx.images(language='de')['posters']
											if imgs:
												for img in imgs:
													if posterquality.value != "original":
														imgsize = posterqualityDict[posterquality.value]
													else:
														imgsize = str(img['width']) + 'x' + str(img['height'])
													itm = [item['name'], what, str(imgsize) + ' gefunden auf TMDb TV', 'http://image.tmdb.org/t/p/' + str(posterquality.value) + img['file_path'], os.path.join(posterDir, b64title +'.jpg'), convert2base64(img['file_path']) +'.jpg']
													pictureList.append((itm,))
											if len(imgs) < 2:
												imgs = idx.images()['posters']
												if imgs:
													for img in imgs:
														if posterquality.value != "original":
															imgsize = posterqualityDict[posterquality.value]
														else:
															imgsize = str(img['width']) + 'x' + str(img['height'])
														itm = [item['name'], what, str(imgsize) + ' gefunden auf TMDb TV', 'http://image.tmdb.org/t/p/' + str(posterquality.value) + img['file_path'], os.path.join(posterDir, b64title +'.jpg'), convert2base64(img['file_path']) +'.jpg']
														pictureList.append((itm,))
									except:
										pass
			except:
				pass

#			write_log('################################################### themoviedb movie ##############################################')
			try:
				search = tmdb.Search()
				if jahr != '':
					res = search.movie(query=title, language='de', year=jahr)
				else:
					res = search.movie(query=title, language='de')
				if res:
					if res['results']:
						reslist = []
						for item in res['results']:
							reslist.append(item['title'].lower())
						bestmatch = get_close_matches(title.lower(), reslist, 4, 0.6)
						if not bestmatch:
							bestmatch = [title.lower()]
						for item in res['results']:
							write_log('found on TMDb Movie ' + str(item['title']))
							if item['title'].lower() in bestmatch:
								if 'id' in item:
									idx = tmdb.Movies(item['id'])
									try:
										if what == 'Cover':
											imgs = idx.images(language='de')['backdrops']
											if imgs:
												for img in imgs:
													if coverquality.value != "original":
														imgsize = coverqualityDict[coverquality.value]
													else:
														imgsize = str(img['width']) + 'x' + str(img['height'])
													itm = [item['title'], what, str(imgsize) + ' gefunden auf TMDb Movie', 'http://image.tmdb.org/t/p/' + str(coverquality.value) + img['file_path'], os.path.join(coverDir, b64title +'.jpg'), convert2base64(img['file_path']) +'.jpg']
													pictureList.append((itm,))
											if len(imgs) < 2:
												imgs = idx.images()['backdrops']
												if imgs:
													for img in imgs:
														if coverquality.value != "original":
															imgsize = coverqualityDict[coverquality.value]
														else:
															imgsize = str(img['width']) + 'x' + str(img['height'])
														itm = [item['title'], what, str(imgsize) + ' gefunden auf TMDb Movie', 'http://image.tmdb.org/t/p/' + str(coverquality.value) + img['file_path'], os.path.join(coverDir, b64title +'.jpg'), convert2base64(img['file_path']) +'.jpg']
														pictureList.append((itm,))
									except:
										pass
									try:
										if what == 'Poster':
											imgs = idx.images(language='de')['posters']
											if imgs:
												for img in imgs:
													if posterquality.value != "original":
														imgsize = posterqualityDict[posterquality.value]
													else:
														imgsize = str(img['width']) + 'x' + str(img['height'])
													itm = [item['title'], what, str(imgsize) + ' gefunden auf TMDb Movie', 'http://image.tmdb.org/t/p/' + str(posterquality.value) + img['file_path'], os.path.join(posterDir, b64title +'.jpg'), convert2base64(img['file_path']) +'.jpg']
													pictureList.append((itm,))
											if len(imgs) < 2:
												imgs = idx.images()['posters']
												if imgs:
													for img in imgs:
														if posterquality.value != "original":
															imgsize = posterqualityDict[posterquality.value]
														else:
															imgsize = str(img['width']) + 'x' + str(img['height'])
														itm = [item['title'], what, str(imgsize) + ' gefunden auf TMDb Movie', 'http://image.tmdb.org/t/p/' + str(posterquality.value) + img['file_path'], os.path.join(posterDir, b64title +'.jpg'), convert2base64(img['file_path']) +'.jpg']
														pictureList.append((itm,))
									except:
										pass
			except:
				pass

#			write_log('################################################### thetvdb ##############################################')
			seriesid = None
			search = tvdb.Search()
			try:
				try:
					response = search.series(title, language="de") 
					if response:
						reslist = []
						for result in response:
							reslist.append(result['seriesName'].lower())
						bestmatch = get_close_matches(title.lower(), reslist, 4, 0.6)
						if not bestmatch:
							bestmatch = [title.lower()]
						for result in response:
							if result['seriesName'].lower() in bestmatch:
								seriesid = result['id']
								break
				except Exception as ex:
					try:
						response = search.series(title)
						if response:
							reslist = []
							for result in response:
								reslist.append(result['seriesName'].lower())
							bestmatch = get_close_matches(title.lower(), reslist, 4, 0.6)
							if not bestmatch:
								bestmatch = [title.lower()]
							for result in response:
								if result['seriesName'].lower() in bestmatch:
									seriesid = result['id']
									break
					except:
						pass

				if seriesid:
					showimgs = tvdb.Series_Images(seriesid)
					try:
						if what == 'Cover':
							response = showimgs.fanart(language="de")
							if response:
								for img in response:
									itm = [result['seriesName'], what, str(img['resolution']) + ' gefunden auf TVDb', 'https://www.thetvdb.com/banners/' + img['fileName'], os.path.join(coverDir, b64title +'.jpg'), convert2base64(img['fileName']) +'.jpg']
									pictureList.append((itm,))
							if len(response) < 2:
								response = showimgs.fanart()
								if response:
									for img in response:
										itm = [result['seriesName'], what, str(img['resolution']) + ' gefunden auf TVDb', 'https://www.thetvdb.com/banners/' + img['fileName'], os.path.join(coverDir, b64title +'.jpg'), convert2base64(img['fileName']) +'.jpg']
										pictureList.append((itm,))
					except:
						pass
					try:
						if what == 'Poster':
							response = showimgs.poster(language="de")
							if response:
								for img in response:
									itm = [result['seriesName'], what, str(img['resolution']) + ' gefunden auf TVDb', 'https://www.thetvdb.com/banners/' + img['fileName'], os.path.join(posterDir, b64title +'.jpg'), convert2base64(img['fileName']) +'.jpg']
									pictureList.append((itm,))
							if len(response) < 2:
								response = showimgs.poster()
								if response:
									for img in response:
										itm = [result['seriesName'], what, str(img['resolution']) + ' gefunden auf TVDb', 'https://www.thetvdb.com/banners/' + img['fileName'], os.path.join(posterDir, b64title +'.jpg'), convert2base64(img['fileName']) +'.jpg']
										pictureList.append((itm,))
					except:
						pass
			except:
				pass

			if not pictureList and what == 'Poster':
				try:
					url = "http://www.omdbapi.com/?apikey=%s&t=%s" % (get_keys('omdb'), title)
					r = requests.get(url, timeout=5)
					if r.status_code == 200:
						res = json.loads(r.content)
						if res['Response'] == "True":
							if res['Poster'].startswith('http'):
								itm = [res['Title'], what, 'OMDB', res['Poster'], os.path.join(posterDir, b64title +'.jpg'), convert2base64('omdbPosterFile') + '.jpg']
								pictureList.append((itm,))

					url = "http://api.tvmaze.com/search/shows?q=%s" % (title)
					r = requests.get(url, timeout=5)
					if r.status_code == 200:
						res = json.loads(r.content)
						if res:
							reslist = []
							for item in res:
								reslist.append(item['show']['name'].lower())
							bestmatch = get_close_matches(title.lower(), reslist, 4, 0.7)
							if not bestmatch:
								bestmatch = [title.lower()]
							for item in res:
								if item['show']['name'].lower() == bestmatch[0]:
									if item['show']['image']:
										itm = [item['show']['name'], what, 'maze.tv', item['show']['image']['original'], os.path.join(posterDir, b64title +'.jpg'), convert2base64('mazetvPosterFile') + '.jpg']
										pictureList.append((itm,))
				except:
					pass

			if pictureList:
				idx = 0
				write_log('found ' + str(len(pictureList)) + ' images for ' + str(title), addlog.value)
				while idx <= int(count) and idx < len(pictureList):
					write_log('Image : ' + str(pictureList[idx]), addlog.value)
					downloadImage(pictureList[idx][0][3], os.path.join('/tmp/', pictureList[idx][0][5]))
					idx += 1
				return pictureList[:count]
			else:
				itm = ["Keine Ergebnisse gefunden", "Bildname '" + str(b64title) + ".jpg'", None, None, None, None]
				pictureList.append((itm,))
				return pictureList
		except Exception as ex:
			write_log('get_PictureList : ' + str(ex))
			return []

def get_searchResults(title):
	if isconnected() == 0 and isInstalled:
		tvdb.KEYS.API_KEY = get_keys('tvdb')
		tmdb.API_KEY = get_keys('tmdb')
		resultList = []
		try:
			titleNyear = convertYearInTitle(title)
			title = convertSearchName(titleNyear[0])
			jahr = str(titleNyear[1])
			write_log('searching results for ' + str(title) + ' with year ' + str(jahr))
			try:
				search = tmdb.Search()
				if jahr != '':
					res = search.tv(query=title, language='de', year=jahr)
				else:
					res = search.tv(query=title, language='de')
				if res:
					if res['results']:
						reslist = []
						for item in res['results']:
							reslist.append(item['name'].lower())
						bestmatch = get_close_matches(title.lower(), reslist, 10, 0.2)
						if not bestmatch:
							bestmatch = [title.lower()]
						for item in res['results']:
							if item['name'].lower() in bestmatch:
								countries = ""
								year = ""
								genres = ""
								rating = ""
								fsk = ""
								desc = ""
								if 'overview' in item:
									desc = item['overview']
								if item['origin_country']:
									for country in item['origin_country']:
										countries = countries + country + ' | '
									countries = countries[:-3]
								if 'first_air_date' in item:
									year = item['first_air_date'][:4]
								if item['genre_ids']:
									for genre in item['genre_ids']:
										genres = genres + tmdb_genres[genre] + '-Serie '
								if 'vote_average' in item and item['vote_average'] != "0":
									rating = str(item['vote_average'])
								if 'id' in item:
									details = tmdb.TV(item['id'])
									for country in details.content_ratings(language='de')['results']:
										if str(country['iso_3166_1']) == "DE":
											fsk = str(country['rating'])
											break
								itm = [str(item['name']), str(countries), str(year), str(genres), str(rating), str(fsk), "TMDb TV", desc]
								resultList.append((itm,))
			except:
				pass

			try:
				search = tmdb.Search()
				if jahr != '':
					res = search.movie(query=title, language='de', year=jahr)
				else:
					res = search.movie(query=title, language='de')
				if res:
					if res['results']:
						reslist = []
						for item in res['results']:
							reslist.append(item['title'].lower())
						bestmatch = get_close_matches(title.lower(), reslist, 10, 0.2)
						if not bestmatch:
							bestmatch = [title.lower()]
						for item in res['results']:
							if item['title'].lower() in bestmatch:
								countries = ""
								year = ""
								genres = ""
								rating = ""
								fsk = ""
								desc = ""
								if 'overview' in item:
									desc = item['overview']
								if 'release_date' in item:
									year = item['release_date'][:4]
								if item['genre_ids']:
									for genre in item['genre_ids']:
										genres = genres + tmdb_genres[genre] + ' '
								if 'vote_average' in item and item['vote_average'] != "0":
									rating = str(item['vote_average'])
								if 'id' in item:
									details = tmdb.Movies(item['id'])
									for country in details.releases(language='de')['countries']:
										if str(country['iso_3166_1']) == "DE":
											fsk = str(country['certification'])
											break
									for country in details.info(language='de')['production_countries']:
										countries = countries + country['iso_3166_1'] + " | "
									countries = countries[:-3]
								itm = [str(item['title']), str(countries), str(year), str(genres), str(rating), str(fsk), "TMDb Movie", desc]
								resultList.append((itm,))
			except:
				pass

			search = tvdb.Search()
			try:
				try:
					response = search.series(title, language="de") 
					if response:
						reslist = []
						for result in response:
							reslist.append(result['seriesName'].lower())
						bestmatch = get_close_matches(title.lower(), reslist, 10, 0.2)
						if not bestmatch:
							bestmatch = [title.lower()]
						for result in response:
							if result['seriesName'].lower() in bestmatch:
								seriesid = None
								countries = ""
								year = ""
								genres = ""
								rating = ""
								fsk = ""
								desc = ""
								seriesid = result['id']
								if seriesid:
									show = tvdb.Series(seriesid)
									response = show.info()
									if response:
										if 'overview' in response:
											desc = response['overview']
										if response['network'] in networks:
											countries = networks[response['network']]
										year = response['firstAired'][:4]
										for genre in response['genre']:
											genres = genres + genre + '-Serie '
										genres = genres.replace("Documentary", "Dokumentation").replace("Children", "Kinder")
										if response['siteRating'] != "0":
											rating = response['siteRating']
										if "TV-MA" in str(response['rating']):
											fsk = "18"
										elif "TV-PG" in str(response['rating']):
											fsk = "16"
										elif "TV-14" in str(response['rating']):
											fsk = "12"
										elif "TV-Y7" in str(response['rating']):
											fsk = "6"
										itm = [str(result['seriesName']), str(countries), str(year), str(genres), str(rating), str(fsk), "The TVDB", desc]
										resultList.append((itm,))
				except Exception as ex:
					try:
						response = search.series(title) 
						if response:
							reslist = []
							for result in response:
								reslist.append(result['seriesName'].lower())
							bestmatch = get_close_matches(title.lower(), reslist, 10, 0.2)
							if not bestmatch:
								bestmatch = [title.lower()]
							for result in response:
								if result['seriesName'].lower() in bestmatch:
									seriesid = None
									countries = ""
									year = ""
									genres = ""
									rating = ""
									fsk = ""
									desc = ""
									seriesid = result['id']
									if seriesid:
										show = tvdb.Series(seriesid)
										response = show.info()
										if response:
											if 'overview' in response:
												desc = response['overview']
											if response['network'] in networks:
												countries = networks[response['network']]
											year = response['firstAired'][:4]
											for genre in response['genre']:
												genres = genres + genre + '-Serie '
											genres = genres.replace("Documentary", "Dokumentation").replace("Children", "Kinder")
											if response['siteRating'] != "0":
												rating = response['siteRating']
											if "TV-MA" in str(response['rating']):
												fsk = "18"
											elif "TV-PG" in str(response['rating']):
												fsk = "16"
											elif "TV-14" in str(response['rating']):
												fsk = "12"
											elif "TV-Y7" in str(response['rating']):
												fsk = "6"
											itm = [str(result['seriesName']), str(countries), str(year), str(genres), str(rating), str(fsk), "The TVDB", desc]
											resultList.append((itm,))
					except:
						pass
			except:
				pass

			try:
				url = "http://api.tvmaze.com/search/shows?q=%s" % (title)
				r = requests.get(url, timeout=5)
				if r.status_code == 200:
					res = json.loads(r.content)
					reslist = []
					for item in res:
						reslist.append(item['show']['name'].lower())
					bestmatch = get_close_matches(title.lower(), reslist, 10, 0.2)
					if not bestmatch:
						bestmatch = [title.lower()]
					for item in res:
						if item['show']['name'].lower() in bestmatch:
							countries = ""
							year = ""
							genres = ""
							rating = ""
							fsk = ""
							desc = ""
							if item['show']['summary']:
								desc = item['show']['summary']
							if item['show']['network']['country']:
								countries = item['show']['network']['country']['code']
							if item['show']['premiered']:
								year = item['show']['premiered'][:4]
							if item['show']['genres']:
								for genre in item['show']['genres']:
									genres = genres + genre + '-Serie '
								genres = genres.replace("Documentary", "Dokumentation").replace("Children", "Kinder")
							if item['show']['rating']['average'] and str(item['show']['rating']['average']) != None:
								rating = item['show']['rating']['average']
							itm = [str(item['show']['name']), str(countries), str(year), str(genres), str(rating), str(fsk), "maze.tv", desc]
							resultList.append((itm,))
			except: 
				pass

			try:
				url = "http://www.omdbapi.com/?apikey=%s&s=%s&page=1" % (get_keys('omdb'), title)
				r = requests.get(url, timeout=5)
				if r.status_code == 200:
					res = json.loads(r.content)
					if res['Response'] == "True":
						reslist = []
						for result in res['Search']:
							reslist.append(result['Title'].lower())
						bestmatch = get_close_matches(title.lower(), reslist, 10, 0.2)
						if not bestmatch:
							bestmatch = [title.lower()]
						for result in res['Search']:
							if result['Title'].lower() in bestmatch:
								url = "http://www.omdbapi.com/?apikey=%s&i=%s" % (get_keys('omdb'), result['imdbID'])
								r = requests.get(url, timeout=5)
								if r.status_code == 200:
									countries = ""
									year = ""
									genres = ""
									rating = ""
									fsk = ""
									desc = ""
									res = json.loads(r.content)
									if res['Response'] == "True":
										if res['Plot']:
											desc = res['Plot']
										if res['Year']:
											year = res['Year'][:4]
										if res['Genre'] != "N/A":
											type = ' '
											if res['Type']:
												if res['Type'] == 'series':
													type = '-Serie '
											resgenres = res['Genre'].split(', ')
											for genre in resgenres:
												genres = genres + genre + type
											genres = genres.replace("Documentary", "Dokumentation").replace("Children", "Kinder")
										if res['imdbRating'] != "N/A":
											rating = res['imdbRating']
										if res['Country'] != "N/A":
											rescountries = res['Country'].split(', ')
											for country in rescountries:
												countries = countries + country + ' | '
											countries = countries[:-2].replace('West Germany','DE').replace('East Germany','DE').replace('Germany','DE').replace('France','FR').replace('Canada','CA').replace('Austria','AT').replace('Switzerland','S').replace('Belgium','B').replace('Spain','ESP').replace('Poland','PL').replace('Russia','RU').replace('Czech Republic','CZ').replace('Netherlands','NL').replace('Italy','IT')
										if res['Rated'] != "N/A":
											if "R" in str(res['Rated']):
												fsk = "18"
											elif "TV-MA" in str(res['Rated']):
												fsk = "18"
											elif "TV-PG" in str(res['Rated']):
												fsk = "16"
											elif "TV-14" in str(res['Rated']):
												fsk = "12"
											elif "TV-Y7" in str(res['Rated']):
												fsk = "6"
											elif "PG-13" in str(res['Rated']):
												fsk = "12"
											elif "PG" in str(res['Rated']):
												fsk = "6"
											elif "G" in str(res['Rated']):
												fsk = "16"
										itm = [str(res['Title']), str(countries), str(year), str(genres), str(rating), str(fsk), "omdb", desc]
										resultList.append((itm,))
			except Exception as ex:
				write_log('get_searchResults omdb: ' + str(ex))

			write_log('search results : ' + str(resultList))
			if resultList:
				return(sorted(resultList, key = lambda x: x[0]))
			else:
				itm = ["Keine Ergebnisse gefunden", None, None, None, None, None, None, None]
				resultList.append((itm,))
				return resultList
		except Exception as ex:
			write_log('get_searchResults : ' + str(ex))
			return []

############################################### EPGShare ##########################################################
def isEPGShare():
	if os.path.exists('/usr/lib/enigma2/python/Plugins/Extensions/EpgShare/main.so'):
		return True
	return False

def getEpgShareImagePath():
	if isEPGShare():
		return str(config.plugins.epgShare.autocachelocation.value)
	return None

def getEpgShareDefaultImage(title):
	try:
		path = '%s/Default/' % (getEpgShareImagePath())
		title = title.decode('utf-8').lower().split('(')[0].strip() + '.jpg'
		imageFileName = '%s%s' % (path, base64.b64encode(title))
		if (os.path.isfile(imageFileName)):
			return imageFileName
	except Exception as ex:
		write_log("getEpgShareDefaultImage :" + str(ex))
	return None

def getEpgShareEventImage(timestamp, eventId):
	try:
		path = os.path.join(getEpgShareImagePath(), str(strftime('%D', localtime(int(timestamp)))).replace('/', '.'))
		imageFileName = '%s/%s.jpg' % (path, eventId)
		if (os.path.isfile(imageFileName)):
			return imageFileName

		if os.path.isdir(path):
			files = [i for i in os.listdir(path) if os.path.isfile(os.path.join(path, i)) and i.startswith("%s_" % eventId)]
			if(len(files) > 0):
				imageFileName = '%s/%s' % (path, files[0])
				if (os.path.isfile(imageFileName)):
					return imageFileName
	except Exception as ex:
		write_log("getEpgShareEventImage : " + str(ex))
	return None

def getallEventsfromEPGShare(names=set(), db=None):
	global STATUS
	try:
		data = None
		doIt = False
		if "EPGShareDB" in sPDict:
			if sPDict["EPGShareDB"]:
				doIt = True
		else:
			doIt = True
		if isEPGShare() and doIt:
			STATUS = 'durchsuche EPGShare Datenbank...'
			from Plugins.Extensions.EpgShare.main import getEPGDB
			data = getEPGDB().selectSQL("SELECT DISTINCT title FROM epg_extradata WHERE airtime > " + str(time()))
			if data and len(data) > 0:
				write_log('found ' + str(len(data)) + ' Events in EPGShare Database')
				for titles in data:
					foundInBl = False
					name = convertTitle(titles['title'])
					if db.getblackList(convert2base64(name)):
						name = convertTitle2(titles['title'])
						if db.getblackList(convert2base64(name)):
							foundInBl = True
					if not db.checkTitle(convert2base64(name)) and not foundInBl:
						names.add(name)
				write_log('found :' + str(len(names)) + ' new Events in EPGShare Database')
				return names
			else:
				write_log('no new events in EPGShare-DB')
				return names
		else:
			write_log('EPGShare is not installed')
			return names
	except Exception as ex:
		write_log("getallEventsfromEPGShare : " + str(ex))
		return names

def getEPGShareExtraData(source):
	if source.event:
		if type(source) == ExtEvent:
			try:
				starttime = source.event.getBeginTime()
				title = source.event.getEventName()
				return json.dumps(getEPGShareDataFromDatabase(str(source.service), str(source.event.getEventId()), starttime, title))
			except Exception as ex:
				write_log("getEPGShareExtraData (ExtEvent) : " + str(ex))
				return ""
		elif str(type(source)) == "<class 'Components.Sources.extEventInfo.extEventInfo'>":
			try:
				if source.service and source.eventid:
					return json.dumps(getEPGShareDataFromDatabase(str(source.service), str(source.eventid)))
				return ""
			except Exception as ex:
				write_log("getEPGShareExtraData (ExtEventInfo) : " + str(ex))
				return ""
		elif hasattr(source, 'service'):
			try:
				service = source.getCurrentService()
				if service:
					servicereference = ServiceReference(service)
					if servicereference:
						return json.dumps(getEPGShareDataFromDatabase(str(servicereference), str(source.event.getEventId())))
				return ""
			except Exception as ex:
				write_log("getEPGShareExtraData (Service) : " + str(ex),addlog.value)
				return ""
		elif type(source) == Event:
			return source.event.getExtraEventData()
	return ""

def getEPGShareDataFromDatabase(service, eventid, beginTime=None, EventName=None):
	try:
		if isEPGShare():
			from Plugins.Extensions.EpgShare.main import getEPGDB
			data = None
			if "::" in str(service):
				service = service.split("::")[0] + ":"
			if "http" in str(service):
				service = service.split("http")[0]

			# Bug Fix, if channel has alternatives
			if str(service).startswith("1:134"):
				service = GetWithAlternative(str(service))

			if not "1:0:0:0:0:0:0:0:0:0:" in service and not "4097:0:0:0:0:0:0:0:0:0:" in service:
				if beginTime and EventName:
					queryPara = "ref: %s, eventId: %s, title:: %s, beginTime: %s" % (str(service), str(eventid), str(EventName.lower()).decode("utf-8"), str(int(beginTime)))
					data = getEPGDB().selectSQL("SELECT * FROM epg_extradata WHERE ref = ? AND (eventid = ? or (LOWER(title) = ? and airtime BETWEEN ? AND ?))",
												[str(service), str(eventid), str(EventName.lower()).decode("utf-8"), str(int(beginTime) - 120), str(int(beginTime) + 120)])
				else:
					queryPara = "ref: %s, eventId: %s" % (str(service), str(eventid))
					data = getEPGDB().selectSQL("SELECT * FROM epg_extradata WHERE ref = ? AND eventid = ?",
												[str(service), str(eventid)])
				if data and len(data) > 0:
					return data[0]
				else:
					return None
			else:
				return None
	except Exception as ex:
		write_log("getEPGShareDataFromDatabase : " + str(ex))
		return None
	return None


########################################### DB Helper Class #######################################################
class DB_Functions(object):
	@staticmethod
	def dict_factory(cursor, row):
		d = {}
		for idx, col in enumerate(cursor.description):
			d[col[0]] = row[idx]
		return d

	def __init__(self, db_file):
		self.conn = sqlite3.connect(db_file,check_same_thread=False)
		self.create_DB()

	def create_DB(self):
		try:
			cur = self.conn.cursor()
			# create table eventInfo
			query = "SELECT name FROM sqlite_master WHERE type='table' AND name='eventInfo';"
			cur.execute(query)
			if not cur.fetchall():
				query = "CREATE TABLE [eventInfo] ([base64title] TEXT NOT NULL,[title] TEXT NOT NULL,[genre] TEXT NULL,[year] TEXT NULL,[rating] TEXT NULL,[fsk] TEXT NULL,[country] TEXT NULL,[gDate] TEXT NOT NULL,[postercalls] INTEGER DEFAULT 0,[covercalls] INTEGER DEFAULT 0,PRIMARY KEY ([base64title]))"
				cur.execute(query)
				self.conn.commit()
				write_log("Tabelle 'eventInfo' hinzugef�gt")

			# create table blackList
			query = "SELECT name FROM sqlite_master WHERE type='table' AND name='blackList';"
			cur.execute(query)
			if not cur.fetchall():
				query = "CREATE TABLE [blackList] ([base64title] TEXT NOT NULL,PRIMARY KEY ([base64title]))"
				cur.execute(query)
				self.conn.commit()
				write_log("Tabelle 'blackList' hinzugef�gt")

			query = "SELECT name FROM sqlite_master WHERE type='table' AND name='parameters';"
			cur.execute(query)
			if not cur.fetchall():
				query = "CREATE TABLE `parameters` ( `name` TEXT NOT NULL UNIQUE, `value` TEXT, PRIMARY KEY(`name`) )"
				cur.execute(query)
				self.conn.commit()
				write_log("Tabelle 'parameters' hinzugef�gt")

			#append columns eventInfo
			query = "PRAGMA table_info('eventInfo');"
			cur.execute(query)
			rows = cur.fetchall()
			found = False
			for row in rows:
				if "postercalls" in row[1]:
					found = True
					break
			if found == False:
				query ="ALTER TABLE 'eventInfo' ADD COLUMN `postercalls` INTEGER DEFAULT 0"
				cur.execute(query)
				self.conn.commit()
			found = False
			for row in rows:
				if "covercalls" in row[1]:
					found = True
					break
			if found == False:
				query ="ALTER TABLE 'eventInfo' ADD COLUMN `covercalls` INTEGER DEFAULT 0"
				cur.execute(query)
				self.conn.commit()

		except Error as ex:
			write_log("Fehler in DB Create: " + str(ex))

	def releaseDB(self):
		self.conn.close()

	def execute(self,query,args=()):
		cur = self.conn.cursor()
		cur.execute(query,args)

	def parameter(self,action,name,value=None,default=None):
		cur = self.conn.cursor()
		if action == PARAMETER_GET:
			ret = None
			query = "SELECT value FROM parameters WHERE name = ?"
			cur.execute(query,(name,))
			rows = cur.fetchall()
			if rows:
				if rows[0][0] == "False":
					ret = False
				elif rows[0][0] == "True":
					ret = True
				else:
					ret = rows[0][0]
				return ret
			else:
				return default

		elif action == PARAMETER_SET:
			if value or value == False:
				if value == False:
					val = "False"
				elif value == True:
					val = "True"
				else:
					val = value

				query = "REPLACE INTO parameters (name,value) VALUES (?,?)"
				cur.execute(query,(name,val))
				self.conn.commit()
				return value
			else:
				return None
		else:
			return None

	def addTitleInfo(self, base64title,title,genre,year,rating,fsk,country):
		try:
			now = str(time())
			cur = self.conn.cursor()
			query = "insert or ignore into eventInfo (base64title,title,genre,year,rating,fsk,country,gDate) values (?,?,?,?,?,?,?,?);"
			cur.execute(query,(base64title, str(title).decode('utf8'), str(genre).decode('utf8'), year, rating, fsk, str(country).decode('utf8'),now))
			self.conn.commit()
		except Error as ex:
			write_log("Fehler in addTitleInfo : " + str(ex))

	def updateTitleInfo(self, title, genre,year,rating,fsk,country,base64title):
		try:
			now = str(time())
			cur = self.conn.cursor()
			query = "update eventInfo set title = ?, genre = ?, year = ?, rating = ?, fsk = ?, country = ?, gDate = "+now+" where base64title = ?;"
			cur.execute(query,(str(title).decode('utf8'), str(genre).decode('utf8'), year, rating, fsk, str(country).decode('utf8'), base64title))
			self.conn.commit()
		except Error as ex:
			write_log("Fehler in updateTitleInfo : " + str(ex))

	def updatePosterCalls(self, base64title):
		try:
			cur = self.conn.cursor()
			query = "update eventInfo set postercalls = postercalls + 1 where base64title = ?;"
			cur.execute(query,(str(base64title),))
			self.conn.commit()
		except Error as ex:
			write_log("Fehler in updatePosterCalls : " + str(ex))

	def updateCoverCalls(self, base64title):
		try:
			cur = self.conn.cursor()
			query = "update eventInfo set covercalls = covercalls + 1 where base64title = ?;"
			cur.execute(query,(str(base64title),))
			self.conn.commit()
		except Error as ex:
			write_log("Fehler in updateCoverCalls : " + str(ex))

	def getTitleInfo(self, base64title):
		try:
			cur = self.conn.cursor()
			query = "SELECT base64title,title,genre,year,rating,fsk,country FROM eventInfo WHERE base64title = ?"
			cur.execute(query,(str(base64title),))
			row = cur.fetchall()
			if row:
				return [row[0][0],row[0][1].decode('utf8'),row[0][2].decode('utf8'),row[0][3],row[0][4],row[0][5],row[0][6].decode('utf8')]
			else:
				return []
		except Error as ex:
			write_log("Fehler in getTitleInfo : " + str(ex))
			return []

	def getUnusedTitles(self, calls):
		try:
			titleList = []
			cur = self.conn.cursor()
			query = "SELECT base64title FROM eventInfo WHERE postercalls = ? OR covercalls = ?"
			cur.execute(query,(calls, calls))
			rows = cur.fetchall()
			if rows:
				for row in rows:
					itm = [row[0]]
					titleList.append(itm)
			return titleList
		except Error as ex:
			write_log("Fehler in getUnusedTitles : " + str(ex))
			return []

	def checkTitle(self, base64title):
		try:
			cur = self.conn.cursor()
			query = "SELECT base64title FROM eventInfo where base64title = ?;"
			cur.execute(query,(str(base64title),))
			rows = cur.fetchall()
			if rows:
				return True
			else:
				return False
		except Error as ex:
			write_log("Fehler in checkTitle: " + str(ex))
			return False

	def cleanDB(self, base64title):
		try:
			cur = self.conn.cursor()
			query = "delete from eventInfo where base64title = ?;"
			cur.execute(query,(str(base64title),))
			self.conn.commit()
			query = "delete from blackList where base64title = ?;"
			cur.execute(query,(str(base64title),))
			self.conn.commit()
		except Error as ex:
			write_log("Fehler in cleanDB : " + str(ex))

	def cleanblackList(self):
		try:
			cur = self.conn.cursor()
			query = "delete from blackList;"
			cur.execute(query)
			self.conn.commit()
			self.vacuumDB()
		except Error as ex:
			write_log("Fehler in blackList : " + str(ex))


	def cleanNadd2BlackList(self, base64title):
		try:
			cur = self.conn.cursor()
			query = "delete from eventInfo where base64title = ?;"
			cur.execute(query,(str(base64title),))
			self.conn.commit()
			query = "insert or ignore into blackList (base64title) values (?);"
			cur.execute(query,(str(base64title),))
			self.conn.commit()
		except Error as ex:
			write_log("Fehler in cleanNadd2BlackList : " + str(ex))

	def addblackList(self, base64title):
		try:
			cur = self.conn.cursor()
			query = "insert or ignore into blackList (base64title) values (?);"
			cur.execute(query,(str(base64title),))
			self.conn.commit()
		except Error as ex:
			write_log("Fehler in addblackList : " + str(ex))

	def getblackList(self, base64title):
		try:
			cur = self.conn.cursor()
			query = "SELECT base64title FROM blackList WHERE base64title = ?"
			cur.execute(query,(str(base64title),))
			row = cur.fetchall()
			if row:
				return True
			else:
				return False
		except Error as ex:
			write_log("Fehler in getblackList : " + str(ex))
			return False

	def getblackListCount(self):
		try:
			cur = self.conn.cursor()
			query = "SELECT COUNT(base64title) FROM blackList"
			cur.execute(query)
			row = cur.fetchall()
			if row:
				return row[0][0]
			else:
				return 0
		except Error as ex:
			write_log("Fehler in getblackListCount : " + str(ex))
			return 0

	def getTitleInfoCount(self):
		try:
			cur = self.conn.cursor()
			query = "SELECT COUNT(base64title) FROM eventInfo"
			cur.execute(query)
			row = cur.fetchall()
			if row:
				return row[0][0]
			else:
				return 0
		except Error as ex:
			write_log("Fehler in getblackList : " + str(ex))
			return 0

	def vacuumDB(self):
		cur = self.conn.cursor()
		cur.execute("VACUUM")
		self.conn.commit()
