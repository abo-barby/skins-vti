#!/usr/bin/env python
# -*- coding: utf-8 -*-
#################################################################################
#																				#
#								AdvancedEventLibrary							#
#																				#
#						thanks to scrounger for initial idea					#
#							thanks to hmmmdada for EPGShare						#
#																				#
#						License: this is closed source!							#
#	you are not allowed to use this or parts of it on any other image than VTi	#
#		you are not allowed to use this or parts of it on NON VU Hardware		#
#																				#
#							Copyright: tsiegel 2019								#
#																				#
#################################################################################

import os
import skin
import linecache
import requests
import json
import shutil
import re
import urllib2
import datetime
from time import localtime, mktime, sleep
from enigma import eLabel, ePixmap, ePicLoad, ePoint, eSize, eTimer, eWidget, loadJPG, loadPNG
from Renderer import Renderer
from skin import parseColor, parseFont
from Components.AVSwitch import AVSwitch
from Components.Sources.Event import Event
from Components.Sources.ExtEvent import ExtEvent
from Components.Sources.extEventInfo import extEventInfo
from Components.Sources.CurrentService import CurrentService
from Components.Sources.ServiceEvent import ServiceEvent
from Components.config import config, ConfigText, ConfigSubsection, ConfigYesNo
from enigma import iServiceInformation, iPlayableService, iPlayableServicePtr, eServiceCenter
from ServiceReference import ServiceReference
from Tools import AdvancedEventLibrary
from thread import start_new_thread
from datetime import datetime

config.plugins.AdvancedEventLibrary = ConfigSubsection()
usePreviewImages = config.plugins.AdvancedEventLibrary.UsePreviewImages = ConfigYesNo(default = False)
previewImages = usePreviewImages.value or usePreviewImages.value == 'true'

log = "/var/tmp/AdvancedEventLibrary.log"

def write_log(svalue):
	t = localtime()
	logtime = '%02d:%02d:%02d' % (t.tm_hour, t.tm_min, t.tm_sec)
	AEL_log = open(log,"a")
	AEL_log.write(str(logtime) + " : [AdvancedEventLibraryImage] - " + str(svalue) + "\n")
	AEL_log.close()

class AdvancedEventLibraryImage(Renderer):
	IMAGE = "Image"
	PREFER_IMAGE = "preferImage"
	POSTER = "Poster"
	PREFER_POSTER = "preferPoster"
	IMAGE_THUMBNAIL = "ImageThumbnail"
	POSTER_THUMBNAIL = "PosterThumbnail"

	def __init__(self):
		Renderer.__init__(self)
		self.nameCache = { }
		self.ishide = True
		self.imageType = self.IMAGE
		self.WCover = self.HCover = 0
		self.foundImage = False
		self.foundPoster = False
		self.ifilename = None
		self.pfilename = None
		self.scalertype = 2
		self.sizetype = 'Poster'
		self.noImage = None
		self.rotate = "left"
		self.frameImage = None
		self.lastName = ""
		self.screenName = ""
		if os.path.isfile('/usr/share/enigma2/Chamaeleon/png/pigframe.png'):
			self.frameImage = '/usr/share/enigma2/Chamaeleon/png/pigframe.png'
		self.coverPath = AdvancedEventLibrary.getPictureDir()+'cover/'
		self.posterPath = AdvancedEventLibrary.getPictureDir()+'poster/'
		self.db = AdvancedEventLibrary.getDB()
		return

	GUI_WIDGET = eWidget

	def applySkin(self, desktop, screen):
		if (isinstance(screen.skinName, str)):
			self.screenName = screen.skinName
		else:
			self.screenName = ', '.join(screen.skinName)
		if self.skinAttributes:
			attribs = []
			for attrib, value in self.skinAttributes:
				if attrib == 'size':
					attribs.append((attrib, value))
					x, y = value.split(',')
					self.WCover, self.HCover = int(x), int(y)
				elif attrib == 'position':
					attribs.append((attrib, value))
					x, y = value.split(',')
					self.x, self.y = int(x), int(y)
				elif attrib == 'foregroundColor':
					self.fg = parseColor(str(value))
				elif attrib == 'scale':
					self.scalertype = int(value)
				elif attrib == 'backgroundColor':
					attribs.append((attrib, value))
					self.bg = parseColor(str(value))
				elif attrib == 'imageType':
					params = str(value).split(",")
					self.imageType = params[0]
					if self.imageType == self.IMAGE_THUMBNAIL:
						self.coverPath = AdvancedEventLibrary.getPictureDir()+'cover/thumbnails/'
					if self.imageType == self.POSTER_THUMBNAIL:
						self.posterPath = AdvancedEventLibrary.getPictureDir()+'poster/thumbnails/'
					if len(params) > 1:
						self.frameImage = params[1]
						if os.path.isfile(self.frameImage):
							self.imageframe.setPixmap(loadPNG(self.frameImage))
						else:
							self.frameImage = None
					if len(params) > 2:
						self.noImage = params[2]
					if len(params) > 3:
						self.rotate = params[3]
				else:
					attribs.append((attrib, value))

			self.skinAttributes = attribs

		if self.frameImage:
			self.image.resize(eSize(self.WCover-20, self.HCover-20))
			self.imageframe.resize(eSize(self.WCover, self.HCover))
			self.imageframe.setScale(1)
			self.imageframe.setAlphatest(1)
			self.image.move(ePoint(10, 10))
		else:
			self.image.resize(eSize(self.WCover, self.HCover))

		self.image.setScale(self.scalertype)
		ret = Renderer.applySkin(self, desktop, screen)
		return ret

	def changed(self, what):
		try:
			if what[0] != self.CHANGED_CLEAR:
				isMovieFile = None
				event = None
				if not self.instance:
					return
				try:
					if hasattr(self.source, 'getEvent'):
						event = self.source.getEvent()
					else:
						event = self.source.event
				except Exception as ex:
					write_log('Fehler in findEvent : ' + str(ex))

				try:
					if hasattr(self.source, 'service') and not self.screenName == "ChannelSelection":
						service = self.source.service
						if not isinstance(self.source, CurrentService):
							serviceHandler = eServiceCenter.getInstance()
							info = serviceHandler.info(service)
							path = service.getPath()
							isMovieFile = path
							if path.endswith(".ts") or path.endswith(".mkv") or path.endswith(".mpg") or path.endswith(".avi") or path.endswith(".mp4") or path.endswith(".iso") or path.endswith(".mpeg2") or path.endswith(".wmv"):
								if os.path.isfile(path + '.meta'):
									isMovieFile = linecache.getline(path + '.meta', 2).replace("\n","").strip()
								else:
									isMovieFile = str(path)
							elif path.endswith("/"):
								path = path[:-1]
								isMovieFile = str(path)
							elif str(service.toString()) != '':
								try:
									if '::' in str(service.toString()):
										tmp = service.toString().rsplit('::', 1)[1].strip()
										tmp = self.removeExtension(tmp)
										isMovieFile = tmp.strip()
								except Exception as ex:
									write_log('Fehler in Service toString : ' + str(ex))
							else:
								isMovieFile = self.removeExtension(info.getName(service))
						else:
							if isinstance(service, iPlayableServicePtr):
								info = service and service.info()
								ref = None
							else: # reference
								info = service and self.source.info
								ref = service
							if info != None:
								name = ref and info.getName(ref)
								if name is None:
									name = info.getName()
									if ref is None:
										if isinstance(self.source, CurrentService):
											ref = self.source.getCurrentServiceReference()
									if ref:
										if ref.getPath():
											isMovieFile = str(ref.getPath())
											serviceHandler = eServiceCenter.getInstance()
											info_tmp = serviceHandler.info(ref)
											if info_tmp:
												event = info_tmp.getEvent(ref)
												if event:
													isMovieFile = event.getEventName()
				except:
					pass

				# Prüfen ob event tuple ist
				if (isinstance(event, tuple) and event):
					event = event[0]

				if not isMovieFile:
					try:
						if event != None:
							eventName = self.removeExtension(event.getEventName())
							if previewImages and (self.imageType == self.PREFER_IMAGE or self.imageType == self.IMAGE or self.imageType == self.IMAGE_THUMBNAIL or self.imageType == self.PREFER_POSTER):
								evt = self.db.getliveTV(event.getEventId(),eventName, event.getBeginTime())
								if evt:
									if evt[0][3] != '' and not str(evt[0][3]).endswith('.jpg'):
										eventName = str(evt[0][3])
						else:
							self.hideimage()
							return
					except:
						self.hideimage()
						return
				else:
					eventName = self.removeExtension((str(isMovieFile).split('/')[-1])).replace('__',': ').replace('_ ',': ').replace('_',' ')
				eventName = AdvancedEventLibrary.convertDateInFileName(AdvancedEventLibrary.convertSearchName(eventName))

				if self.lastName != eventName:
					start_new_thread(self.setthePixmap, (eventName,))
#					self.setthePixmap(eventName)
		except Exception as e:
			self.hideimage()
			write_log("changed : " + str(e))
		return

	def GUIcreate(self, parent):
		self.instance = eWidget(parent)
		self.imageframe = ePixmap(self.instance)
		self.image = ePixmap(self.instance)
		if self.imageframe:
			self.imageframe.setPixmap(loadPNG(self.frameImage))

	def GUIdelete(self):
		self.imageframe = None
		self.image = None
		self.instance = None
		return

	def showimage(self):
		self.instance.show()
		if self.imageframe:
			self.imageframe.show()
		self.image.show()
		self.ishide = False

	def hideimage(self):
		self.image.hide()
		if self.imageframe:
			self.imageframe.hide()
		self.instance.hide()
		self.ishide = True

	def onShow(self):
		self.suspended = False

	def onHide(self):
		self.suspended = True

	def setthePixmap(self, eventName):
		self.lastName = eventName
		self.foundPoster = False
		self.foundImage = False
		self.pfilename = None
		self.ifilename = None

		inCache = self.nameCache.get(eventName + str(self.imageType), "")
		if str(self.IMAGE) in inCache or str(self.IMAGE_THUMBNAIL) in inCache or str(self.PREFER_IMAGE) in inCache or str(self.PREFER_POSTER) in inCache:
			self.ifilename = inCache
			self.foundImage = True
		elif (self.imageType == self.PREFER_IMAGE or self.imageType == self.IMAGE or self.imageType == self.IMAGE_THUMBNAIL or self.imageType == self.PREFER_POSTER):
			if not self.foundImage:
				self.ifilename = AdvancedEventLibrary.getImageFile(self.coverPath, eventName)
				if self.ifilename:
					self.foundImage = True
				else:
					self.ifilename = AdvancedEventLibrary.getEpgShareDefaultImage(eventName)
					if self.ifilename:
						self.foundImage = True

		if str(self.POSTER) in inCache or str(self.POSTER_THUMBNAIL) in inCache or str(self.PREFER_POSTER) in inCache or str(self.PREFER_IMAGE) in inCache:
			self.pfilename = inCache
			self.foundPoster = True
		elif (self.imageType == self.PREFER_POSTER or self.imageType == self.POSTER or self.imageType == self.POSTER_THUMBNAIL or self.imageType == self.PREFER_IMAGE):
			self.pfilename = AdvancedEventLibrary.getImageFile(self.posterPath, eventName)
			if self.pfilename:
				self.foundPoster = True

		# set alternative falls angegeben und nix gefunden
		if self.noImage and not self.foundImage and (self.imageType == self.PREFER_IMAGE or self.imageType == self.IMAGE or self.imageType == self.IMAGE_THUMBNAIL):
			if (os.path.exists(self.noImage)):
				self.foundImage = True
				self.ifilename = self.noImage
		if self.noImage and not self.foundPoster and (self.imageType == self.PREFER_POSTER or self.imageType == self.POSTER or self.imageType == self.POSTER_THUMBNAIL):
			if (os.path.exists(self.noImage)):
				self.foundPoster = True
				self.pfilename = self.noImage

		if self.ifilename:
			self.nameCache[eventName + str(self.imageType)] = str(self.ifilename)
		if self.pfilename:
			self.nameCache[eventName + str(self.imageType)] = str(self.pfilename)


		if (self.imageType == self.IMAGE or self.imageType == self.IMAGE_THUMBNAIL) and self.foundImage:
			self.loadPic(self.ifilename)
		elif (self.imageType == self.POSTER or self.imageType == self.POSTER_THUMBNAIL) and self.foundPoster:
			self.loadPic(self.pfilename)
		elif self.imageType == self.PREFER_IMAGE and self.foundImage:
			if self.sizetype != 'Image':
				self.calcSize('Image')
			self.sizetype = 'Image'
			self.loadPic(self.ifilename)
		elif self.imageType == self.PREFER_IMAGE and self.foundPoster:
			if self.sizetype != 'Poster':
				self.calcSize('Poster')
			self.sizetype = 'Poster'
			self.loadPic(self.pfilename)
		elif self.imageType == self.PREFER_POSTER and self.foundPoster:
			if self.sizetype != 'Poster':
				self.calcSize('Poster')
			self.sizetype = 'Poster'
			self.loadPic(self.pfilename)
		elif self.imageType == self.PREFER_POSTER and self.foundImage:
			if self.sizetype != 'Image':
				self.calcSize('Image')
			self.sizetype = 'Image'
			self.loadPic(self.ifilename)
		else:
			self.hideimage()

	def calcSize(self, how):
		if how == 'Poster':
			self.instance.move(ePoint(self.x, self.y))
			self.instance.resize(eSize(self.WCover, self.HCover))
			if self.imageframe:
				self.image.resize(eSize(self.WCover-20, self.HCover-20))
				self.imageframe.resize(eSize(self.WCover, self.HCover))
			else:
				self.image.resize(eSize(self.WCover, self.HCover))
		elif how == 'Image':
			if self.rotate == "left":
				self.instance.move(ePoint(self.x-self.HCover+self.WCover, self.y-self.WCover+self.HCover))
			self.instance.resize(eSize(self.HCover, self.WCover))
			if self.imageframe:
				self.image.resize(eSize(self.HCover-20, self.WCover-20))
				self.imageframe.resize(eSize(self.HCover, self.WCover))
			else:
				self.image.resize(eSize(self.HCover, self.WCover))
		else:
			return
		if self.imageframe:
			self.imageframe.setScale(1)
			self.imageframe.setAlphatest(1)
			self.image.move(ePoint(10, 10))
		return

	def removeExtension(self, ext):
		ext = ext.replace('.wmv','').replace('.mpeg2','').replace('.ts','').replace('.m2ts','').replace('.mkv','').replace('.avi','').replace('.mpeg','').replace('.mpg','').replace('.iso','').replace('.mp4','')
		return ext

	def loadPic(self, picname):
		try:
			if picname != "":
				size = self.image.size()
				self.picload = ePicLoad()
				self.picload.PictureData.get().append(self.showCallback)
				if self.picload:
						self.picload.setPara((size.width(), size.height(), 0, 0, False, 1, "#00000000"))
						if self.picload.startDecode(picname) != 0:
							del self.picload
			else:
				self.hideimage()
		except:
			self.hideimage()

	def showCallback(self, picInfo = None):
		try:
			if self.picload:
				ptr = self.picload.getData()
				if ptr != None:
					self.image.setPixmap(ptr)
					if self.ishide:
						self.showimage()
				del self.picload
		except:
			self.hideimage()
