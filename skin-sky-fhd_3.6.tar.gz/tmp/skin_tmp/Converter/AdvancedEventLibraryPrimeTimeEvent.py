# -*- coding: utf-8 -*-
#
# PrimeTime - Converter
#
# Coded by tsiegel (c) 2020

from Components.Converter.Converter import Converter
from Components.Element import cached
from Components.config import config, ConfigClock, ConfigSubsection

from enigma import eEPGCache, eServiceReference
from time import localtime, strftime, mktime, time
from datetime import datetime, timedelta
import HTMLParser

class AdvancedEventLibraryPrimeTimeEvent(Converter, object):
	htmlParser = HTMLParser.HTMLParser()
	def __init__(self, type):
		Converter.__init__(self, type)
		self.epgcache = eEPGCache.getInstance()
		config.plugins.AdvancedEventLibrary = ConfigSubsection()
		self.primeTimeStart = config.plugins.AdvancedEventLibrary.StartTime = ConfigClock(default = 69300) # 20:15

	@cached
	def getText(self):
		ref = self.source.service
		info = ref and self.source.info
		if info is None:
			return ""
		curEvent = self.source.getCurrentEvent()
		if curEvent:
			return self.getResult(curEvent, ref, 0)
		return ""

	text = property(getText)

	@cached
	def getEvent(self):
		ref = self.source.service
		info = ref and self.source.info
		if info is None:
			return None
		curEvent = self.source.getCurrentEvent()
		if curEvent:
			return self.getResult(curEvent, ref, 1)
		return None

	event = property(getEvent)

	def getResult(self, curEvent, ref, what=0):
		if not self.epgcache.startTimeQuery(eServiceReference(ref.toString()), curEvent.getBeginTime() + curEvent.getDuration()):
			now = localtime(time())
			dt = datetime(now.tm_year, now.tm_mon, now.tm_mday, self.primeTimeStart.value[0], self.primeTimeStart.value[1])
			if time() > mktime(dt.timetuple()):
				dt += timedelta(days=1)
			primeTime = int(mktime(dt.timetuple()))
			if not self.epgcache.startTimeQuery(eServiceReference(ref.toString()), primeTime):
				event = self.epgcache.getNextTimeEntry()
				if event and (event.getBeginTime() <= int(mktime(dt.timetuple()))):
					if what == 0:
						return self.getPrimeTimeEvent(event)
					else:
						return event
				else:
					if what == 0:
						return ""
					else:
						return None
			else:
				if what == 0:
					return ""
				else:
					return None
		else:
			if what == 0:
				return ""
			else:
				return None


	def getPrimeTimeEvent(self,event):
		time = "%s - %s" % (strftime("%H:%M", localtime(event.getBeginTime())), strftime("%H:%M", localtime(event.getBeginTime() + event.getDuration())))
		title = event.getEventName()
		duration = "%d Min." % (event.getDuration() / 60)
		return str(time) +  " " + str(title) + ' (' + str(duration) + ')' + str(self.getOneLineDescription(title, event))

	def getOneLineDescription(self, title, event):
		if(event != None):
			desc = event.getShortDescription()
			if(desc != "" and desc != None and desc != title):
				desc = desc.replace(title+'\n', '')
				if '\n' in desc:
					desc = desc.replace('\n', ' ' + str(self.htmlParser.unescape('&#xB7;')) + ' ')
				else:
					tdesc = desc.split("\n")
					desc = tdesc[0].replace('\\n', ' ' + str(self.htmlParser.unescape('&#xB7;')) + ' ')

				if desc.find(' Altersfreigabe: Ohne Altersbe') > 0:
					desc = desc[:desc.find(' Altersfreigabe: Ohne Altersbe')] + ' FSK: 0'
				return '\n' + self.getMaxWords(desc.replace('Altersfreigabe: ab', 'FSK:'), 18)
		return ""

	def getMaxWords(self, desc, maxWords):
		try:
			wordList = desc.split(" ")
			if (len(wordList) >= maxWords):
				del wordList[maxWords:len(wordList)]
				sep = ' '
				return sep.join(wordList) + '...'
			return desc
		except Exception as ex:
			return ""
		return ""

	def changed(self, what):
		if what[0] != self.CHANGED_SPECIFIC:
			Converter.changed(self, what)
