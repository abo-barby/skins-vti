#!/usr/bin/env python
# -*- coding: utf-8 -*-
#################################################################################
#																				#
#								AdvancedEventLibrary							#
#																				#
#						thanks to scrounger for initial idea					#
#																				#
#						License: this is closed source!							#
#	you are not allowed to use this or parts of it on any other image than VTi	#
#		you are not allowed to use this or parts of it on NON VU Hardware		#
#																				#
#							Copyright: tsiegel 2019								#
#																				#
#################################################################################
__all__ = ['randbelow']

import urllib2
import json
import codecs
import os
import StringIO
import base64
import shutil
import requests
import re
import sqlite3
import linecache
import subprocess
import glob
import urllib2
import skin
from random import SystemRandom
from sqlite3 import Error
from time import time, localtime, strftime, mktime
from thread import start_new_thread
from enigma import eEPGCache, iServiceInformation, eServiceReference, eServiceCenter, eTimer, iPlayableServicePtr, iPlayableService
from Screens.ChannelSelection import service_types_tv
from operator import itemgetter
from Components.config import config, ConfigText, ConfigSubsection, ConfigInteger, ConfigYesNo, ConfigSelection
from PIL import Image
from Tools.Alternatives import GetWithAlternative
from Tools.Bytes2Human import bytes2human
from Components.Sources.Event import Event
from Components.Sources.ExtEvent import ExtEvent
from Components.Sources.extEventInfo import extEventInfo
from Components.Sources.CurrentService import CurrentService
from Components.Sources.ServiceEvent import ServiceEvent
from Tools.Directories import defaultRecordingLocation
from ServiceReference import ServiceReference
from difflib import get_close_matches
from datetime import datetime
from twisted.web import client
from twisted.internet import reactor, defer, ssl
from twisted.python import failure
from twisted.internet._sslverify import ClientTLSOptions

isInstalled = False
try:
	from Plugins.Extensions.AdvancedEventLibrary import tvdbsimple as tvdb
	from Plugins.Extensions.AdvancedEventLibrary import tmdbsimple as tmdb
	isInstalled = True
except:
	pass

log = "/var/tmp/AdvancedEventLibrary.log"

bestmount = defaultRecordingLocation().replace('movie/','') + 'AdvancedEventLibrary/'
config.plugins.AdvancedEventLibrary = ConfigSubsection()
config.plugins.AdvancedEventLibrary.Location = ConfigText(default = bestmount)
dir = config.plugins.AdvancedEventLibrary.Location.value
if not "AdvancedEventLibrary/" in dir:
	dir = dir + "AdvancedEventLibrary/"
config.plugins.AdvancedEventLibrary.Backup = ConfigText(default = "/media/hdd/AdvancedEventLibraryBackup/")
backuppath = config.plugins.AdvancedEventLibrary.Backup.value
addlog = config.plugins.AdvancedEventLibrary.Log = ConfigYesNo(default = False)
useAELIS = config.plugins.AdvancedEventLibrary.UseAELIS = ConfigYesNo(default = True)
usePreviewImages = config.plugins.AdvancedEventLibrary.UsePreviewImages = ConfigYesNo(default = True)
previewImages = usePreviewImages.value or usePreviewImages.value == 'true'
searchfor = config.plugins.AdvancedEventLibrary.SearchFor = ConfigSelection(default = "Extradaten und Bilder", choices = [ "Extradaten und Bilder", "nur Extradaten" ])
coverquality = config.plugins.AdvancedEventLibrary.coverQuality = ConfigSelection(default="w1280", choices = [("w300", "300x169"), ("w780", "780x439"), ("w1280", "1280x720"), ("w1920", "1920x1080")])
posterquality = config.plugins.AdvancedEventLibrary.posterQuality = ConfigSelection(default="w780", choices = [("w185", "185x280"),("w342", "342x513"), ("w500", "500x750"), ("w780", "780x1170")])
coverqualityDict = {"w300": "300x169", "w780": "780x439", "w1280": "1280x720", "w1920": "1920x1080"}
posterqualityDict = {"w185": "185x280","w342": "342x513", "w500": "500x750", "w780": "780x1170"}
searchPlaces = config.plugins.AdvancedEventLibrary.searchPlaces = ConfigText(default = '')
dbfolder = config.plugins.AdvancedEventLibrary.dbFolder = ConfigSelection(default="Datenverzeichnis", choices = ["Datenverzeichnis", "Flash"])
maxImageSize = config.plugins.AdvancedEventLibrary.MaxImageSize = ConfigSelection(default="200", choices = [("100", "100kB"), ("150", "150kB"), ("200", "200kB"), ("300", "300kB"), ("400", "400kB"), ("500", "500kB"), ("750", "750kB"), ("1024", "1024kB"), ("1000000", "unbegrenzt")])
maxCompression = config.plugins.AdvancedEventLibrary.MaxCompression = ConfigInteger(default=50, limits=(10, 90))
seriesStartType = config.plugins.AdvancedEventLibrary.SeriesType = ConfigSelection(default = "Staffelstart", choices = [ "Staffelstart", "Serienstart" ])
tmdbKey = config.plugins.AdvancedEventLibrary.tmdbKey = ConfigText(default = 'intern')
tvdbKey = config.plugins.AdvancedEventLibrary.tvdbKey = ConfigText(default = 'intern')
omdbKey = config.plugins.AdvancedEventLibrary.omdbKey = ConfigText(default = 'intern')
aelDISKey = config.plugins.AdvancedEventLibrary.aelKey = ConfigText(default = 'kein')

sPDict = {}
if searchPlaces.value != '':
	try:
		sPDict = eval(searchPlaces.value)
	except:
		pass

vtidb_loc = config.misc.db_path.value + '/vtidb.db'

STATUS = None
PARAMETER_SET = 0
PARAMETER_GET = 1

tmdb_genres = {10759 : "Action-Abenteuer", 16 : "Animation", 10762 : "Kinder", 10763 : "News", 10764 : "Reality", 10765 : "Sci-Fi-Fantasy", 10766 : "Soap", 10767 : "Talk", 10768 : "War & Politics", 28 : "Action", 12 : "Abenteuer", 16 : "Animation", 35 : "Comedy", 80 : "Crime", 99 : "Dokumentation", 18 : "Drama", 10751 : "Familie", 14 : "Fantasy", 36 : "History", 27 : "Horror", 10402 : "Music", 9648 : "Mystery", 10749 : "Romance", 878 : "Science-Fiction", 10770 : "TV-Movie", 53 : "Thriller", 10752 : "War", 37 : "Western"}
convNames = ['Polizeiruf','Tatort','Die Bergpolizei','Axte X','ANIXE auf Reisen','Close Up','Der Z�rich-Krimi','Buffy','Das Traumschiff','Die Land','Faszination Berge','Hyperraum','Kreuzfahrt ins Gl','Lost Places','Mit offenen Karten','Newton','Planet Schule','Punkt 12','Regular Show','News Reportage','News Spezial','S.W.A.T','Xenius','Der Barcelona-Krimi','Die ganze Wahrheit','Firmen am Abgrund','GEO Reportage','Kommissar Wallander','Rockpalast','SR Memories','Wildes Deutschland','Wilder Planet','Die rbb Reporter','Flugzeug-Katastrophen','Heute im Osten','Kalkofes Mattscheibe','Neue Nationalparks','Auf Entdeckungsreise']
excludeNames = ['RTL UHD', '--', 'Sendeschluss', 'Dokumentation', 'EaZzzy', 'MediaShop', 'Dauerwerbesendung', 'Impressum']

ApiKeys = {"tmdb": ["ZTQ3YzNmYzJkYzRlMWMwN2UxNGE4OTc1YjI5MTE1NWI=","MDA2ZTU5NGYzMzFiZDc1Nzk5NGQwOTRmM2E0ZmMyYWM=","NTRkMzg1ZjBlYjczZDE0NWZhMjNkNTgyNGNiYWExYzM="], "tvdb": ["NTRLVFNFNzFZWUlYM1Q3WA==","MzRkM2ZjOGZkNzQ0ODA5YjZjYzgwOTMyNjI3ZmE4MTM=","Zjc0NWRiMDIxZDY3MDQ4OGU2MTFmNjY2NDZhMWY4MDQ="], "omdb": ["ZmQwYjkyMTY=","YmY5MTFiZmM=","OWZkNzFjMzI="]}

tvsref = {
	'1:0:19:7E:C:85:C00000:0:0:0:': 'scifi',
	'1:0:16:12:4:85:C00000:0:0:0:': 'sky-s',
	'1:0:1:1389:3EA:1:C00000:0:0:0:': 'bbc',
	'1:0:19:88:B:85:C00000:0:0:0:': 'tnt-c',
	'1:0:19:2855:401:1:C00000:0:0:0:': 'br',
	'1:0:19:2859:401:1:C00000:0:0:0:': 'n3',
	'1:0:19:2B98:3F2:1:C00000:0:0:0:': 'kika',
	'1:0:19:69:C:85:C00000:0:0:0:': 'buli',
	'1:0:19:286E:425:1:C00000:0:0:0:': 'rbb',
	'1:0:1:6FEF:436:1:C00000:0:0:0:': 'mtv-d',
	'1:0:19:286F:425:1:C00000:0:0:0:': 'rbb',
	'1:0:1:7094:443:1:C00000:0:0:0:': 'voxup',
	'1:0:19:EF10:421:1:C00000:0:0:0:': 'rtl',
	'1:0:1:332F:45B:1:C00000:0:0:0:': 'wdwtv',
	'1:0:19:283E:3FB:1:C00000:0:0:0:': 'arte',
	'1:0:19:1581:41F:1:C00000:0:0:0:': 'sport',
	'1:0:19:283F:3FB:1:C00000:0:0:0:': 'swr',
	'1:0:19:93:2:85:C00000:0:0:0:': 'sky1',
	'1:0:19:33AC:3EB:1:C00000:0:0:0:': 'atv',
	'1:0:19:6F:D:85:C00000:0:0:0:': 'skycs',
	'1:0:16:196:2:85:C00000:0:0:0:': 'kinow',
	'1:0:16:191:9:85:C00000:0:0:0:': 'juke',
	'1:0:16:204:6:85:C00000:0:0:0:': 'sky-n',
	'1:0:1:26:F:85:C00000:0:0:0:': 'hgtv',
	'1:0:1F:30DE:413:1:C00000:0:0:0:': 'fatv',
	'1:0:19:24C6:43C:1:C00000:0:0:0:': 'trace',
	'1:0:16:194:B:85:C00000:0:0:0:': 'c-net',
	'1:0:19:14B7:407:1:C00000:0:0:0:': 'puls4',
	'1:0:19:157E:41F:1:C00000:0:0:0:': '123tv',
	'1:0:19:6B:C:85:C00000:0:0:0:': 'sky-h',
	'1:0:19:16A9:3FF:1:C00000:0:0:0:': 'tvm',
	'1:0:19:EF14:421:1:C00000:0:0:0:': 'ntv',
	'1:0:19:6E:D:85:C00000:0:0:0:': 'skyat',
	'1:0:19:2887:40F:1:C00000:0:0:0:': 'tag24',
	'1:0:19:33FD:3ED:1:C00000:0:0:0:': 'orfsp',
	'1:0:19:526F:41D:1:C00000:0:0:0:': 'qvc',
	'1:0:19:7D:9:85:C00000:0:0:0:': 'cnbc',
	'1:0:19:7B:9:85:C00000:0:0:0:': 'tnt-s',
	'1:0:19:3402:3ED:1:C00000:0:0:0:': 'oe24tv',
	'1:0:19:8F:9:85:C00000:0:0:0:': 'spo-a',
	'1:0:19:157F:41F:1:C00000:0:0:0:': 'dmc',
	'1:0:16:31:D:85:C00000:0:0:0:': 'sptvw',
	'1:0:19:80:B:85:C00000:0:0:0:': 'e!',
	'1:0:19:8B:2:85:C00000:0:0:0:': 'sky-f',
	'1:0:19:13A7:3EA:1:C00000:0:0:0:': 'aljaz',
	'1:0:19:EF74:3F9:1:C00000:0:0:0:': 'sat1',
	'1:0:16:16:2:85:C00000:0:0:0:': 'heima',
	'1:0:19:6EA5:4B1:1:C00000:0:0:0:': 'wdr',
	'1:0:19:4331:300C:13E:820000:0:0:0:': 'sf1',
	'1:0:19:285B:401:1:C00000:0:0:0:': 'phoen',
	'1:0:19:26B6:43E:1:C00000:0:0:0:': 'tv5',
	'1:0:19:89:10:85:C00000:0:0:0:': 'sp-ge',
	'1:0:19:6EA6:4B1:1:C00000:0:0:0:': 'wdr',
	'1:0:1:32DB:45D:1:C00000:0:0:0:': 'ric',
	'1:0:1:33A7:3EB:1:C00000:0:0:0:': 'atv2',
	'1:0:19:4332:300C:13E:820000:0:0:0:': 'sf2',
	'1:0:1:114E:404:1:C00000:0:0:0:': 'dwtv',
	'1:0:19:2778:409:1:C00000:0:0:0:': 'ch21',
	'1:0:19:2B8E:3F2:1:C00000:0:0:0:': '3sat',
	'1:0:19:EF15:421:1:C00000:0:0:0:': 'rtl2',
	'1:0:1:1AF9:3FE:1:C00000:0:0:0:': 'fr24f',
	'1:0:19:82:6:85:C00000:0:0:0:': 'hddis',
	'1:0:19:2774:409:1:C00000:0:0:0:': 'tlc',
	'1:0:19:2872:425:1:C00000:0:0:0:': 'mdr',
	'1:0:1F:183A:40B:1:C00000:0:0:0:': 'travelxp',
	'1:0:19:1519:455:1:C00000:0:0:0:': 'tele5',
	'1:0:19:33FC:3ED:1:C00000:0:0:0:': 'orf3',
	'1:0:19:EF11:421:1:C00000:0:0:0:': 'vox',
	'1:0:19:17:4:85:C00000:0:0:0:': 'sky-k',
	'1:0:1:3146:459:1:C00000:0:0:0:': 'rmtv',
	'1:0:1:313C:459:1:C00000:0:0:0:': 'dmf',
	'1:0:16:DF:4:85:C00000:0:0:0:': 'buli',
	'1:0:19:1580:41F:1:C00000:0:0:0:': 'qvcp',
	'1:0:1:3138:459:1:C00000:0:0:0:': 'health',
	'1:0:19:526C:41D:1:C00000:0:0:0:': 'anixe',
	'1:0:19:196D:44E:1:C00000:0:0:0:': 'ex-sp',
	'1:0:19:151A:455:1:C00000:0:0:0:': 'dmax',
	'1:0:19:8C:4:85:C00000:0:0:0:': 'tnt-f',
	'1:0:19:2873:425:1:C00000:0:0:0:': 'hr',
	'1:0:19:EF76:3F9:1:C00000:0:0:0:': 'k1',
	'1:0:16:1013:451:35:C00000:0:0:0:': 'plane',
	'1:0:16:206:2:85:C00000:0:0:0:': 'rom',
	'1:0:1:79FE:443:1:C00000:0:0:0:': 'euron',
	'1:0:19:71:B:85:C00000:0:0:0:': 'hishd',
	'1:0:19:2BA2:3F2:1:C00000:0:0:0:': 'zinfo',
	'1:0:19:1332:3EF:1:C00000:0:0:0:': 'servu',
	'1:0:19:2777:409:1:C00000:0:0:0:': 'mtv',
	'1:0:19:7C:C:85:C00000:0:0:0:': 'fox',
	'1:0:1:1AFA:3FE:1:C00000:0:0:0:': 'fr24e',
	'1:0:1:4465:453:1:C00000:0:0:0:': 'k1doku',
	'1:0:1F:2:40B:1:C00000:0:0:0:': 'uhd1',
	'1:0:1:6FEE:436:1:C00000:0:0:0:': 'mtv-h',
	'1:0:19:7F:D:85:C00000:0:0:0:': '13th',
	'1:0:19:74:9:85:C00000:0:0:0:': 'sky-a',
	'1:0:1:700A:436:1:C00000:0:0:0:': 'nickt',
	'1:0:19:285A:401:1:C00000:0:0:0:': 'n3',
	'1:0:19:2E9B:411:1:C00000:0:0:0:': 'super',
	'1:0:19:283D:3FB:1:C00000:0:0:0:': 'ard',
	'1:0:19:83:6:85:C00000:0:0:0:': 'cin',
	'1:0:19:33A8:3EB:1:C00000:0:0:0:': 'bibel',
	'1:0:1:2F30:441:1:C00000:0:0:0:': 'rtlpl',
	'1:0:19:6C:C:85:C00000:0:0:0:': 'snhd',
	'1:0:19:72:D:85:C00000:0:0:0:': 'shd2',
	'1:0:19:2EAF:411:1:C00000:0:0:0:': 'rtl-n',
	'1:0:1:30:5:85:C00000:0:0:0:': 'n24doku',
	'1:0:19:2889:40F:1:C00000:0:0:0:': 'alpha',
	'1:0:19:1F4A:42E:1:C00000:0:0:0:': 'mezzo',
	'1:0:16:2B:6:85:C00000:0:0:0:': 'cin24',
	'1:0:19:B:4:85:C00000:0:0:0:': 'skyth',
	'1:0:16:13:2:85:C00000:0:0:0:': 'junio',
	'1:0:1:20:21:85:C00000:0:0:0:': 'sklar',
	'1:0:19:65:9:85:C00000:0:0:0:': 'unive',
	'1:0:19:70:D:85:C00000:0:0:0:': 'n-ghd',
	'1:0:1:2753:402:1:C00000:0:0:0:': 'blm',
	'1:0:16:201:B:85:C00000:0:0:0:': 'blum',
	'1:0:19:2856:401:1:C00000:0:0:0:': 'b3',
	'1:0:16:18:2:85:C00000:0:0:0:': 'class',
	'1:0:1:7008:436:1:C00000:0:0:0:': 'nick',
	'1:0:16:192:B:85:C00000:0:0:0:': 'crin',
	'1:0:19:85:3:85:C00000:0:0:0:': 'butv',
	'1:134:1:0:0:0:': 'swr',
	'1:0:1:139D:3EA:1:C00000:0:0:0:': 'nhk',
	'1:0:19:30D4:413:1:C00000:0:0:0:': 'sat1g',
	'1:0:1:1146:404:1:C00000:0:0:0:': 'cnn',
	'1:0:19:5273:41D:1:C00000:0:0:0:': 'cc',
	'1:0:19:8A:3:85:C00000:0:0:0:': 'djun',
	'1:0:19:2888:40F:1:C00000:0:0:0:': 'fes',
	'1:0:19:1260:3F7:1:C00000:0:0:0:': '3Plus',
	'1:0:19:EF77:3F9:1:C00000:0:0:0:': 'sixx',
	'1:0:19:1518:455:1:C00000:0:0:0:': 'sklar',
	'1:0:19:6D:B:85:C00000:0:0:0:': 'euro2',
	'1:0:19:81:6:85:C00000:0:0:0:': 'hdspo',
	'1:0:16:101D:451:35:C00000:0:0:0:': 'axn',
	'1:0:19:76:6:85:C00000:0:0:0:': 'n-gw',
	'1:0:19:132F:3EF:1:C00000:0:0:0:': 'orf1',
	'1:0:19:2B66:3F3:1:C00000:0:0:0:': 'zdf',
	'1:0:19:1330:3EF:1:C00000:0:0:0:': 'orf2',
	'1:0:1:6FF6:42A:1:C00000:0:0:0:': 'nickj',
	'1:0:19:1194:406:1:C00000:0:0:0:': 'spo-d',
	'1:0:1:2EFE:441:1:C00000:0:0:0:': 'toggo',
	'1:0:1:778B:424:1:C00000:0:0:0:': 'pboy',
	'1:0:16:A8:B:85:C00000:0:0:0:': 'movtv',
	'1:0:19:30D6:413:1:C00000:0:0:0:': 'euro',
	'1:0:1:6FF1:436:1:C00000:0:0:0:': 'vh1',
	'1:0:16:14C1:407:1:C00000:0:0:0:': 'sat1e',
	'1:0:19:2B7A:3F3:1:C00000:0:0:0:': '2neo',
	'1:0:1:3139:459:1:C00000:0:0:0:': 'ktv',
	'1:0:19:157C:41F:1:C00000:0:0:0:': 'disne',
	'1:0:19:33F7:3ED:1:C00000:0:0:0:': 'orf2',
	'1:0:19:EF78:3F9:1:C00000:0:0:0:': 'pro7m',
	'1:0:19:527E:41D:1:C00000:0:0:0:': 'welt',
	'1:0:19:EF75:3F9:1:C00000:0:0:0:': 'pro7',
	'1:0:16:14C2:407:1:C00000:0:0:0:': 'k1cla',
	'1:0:19:2870:425:1:C00000:0:0:0:': 'mdr',
	'1:0:16:8:3:85:C00000:0:0:0:': 'sky-c',
	'1:0:19:5270:41D:1:C00000:0:0:0:': 'hse'
	}

networks = {
	'3sat': 'DEU',
	'A&E': 'USA',
	'AAG TV': 'PAK',
	'Aaj TV': 'PAK',
	'ABC (US)': 'USA',
	'ABC (AU)': 'AUS',
	'ABC (JA)': 'JPN',
	'ABC (PH)': 'PHL',
	'ABC Family': 'USA',
	'ABS-CBN Broadcasting Company': 'PHL',
	'Abu Dhabi TV': 'ARE',
	'Adult Channel': 'GBR',
	'Al Alam': 'IRN',
	'Al Arabiyya': 'ARE',
	'Al Jazeera': 'QAT',
	'Alpha TV GUJARATI': 'IND',
	'Alpha TV PUNJABI': 'IND',
	'America One Television Network': 'USA',
	'Animal Planet': 'USA',
	'Anime Network': 'USA',
	'ANT1': 'GRC',
	'Antena 3': 'ESP',
	'ARY Digital': 'PAK',
	'ARY Digital': 'PAK',
	'ARY One World': 'PAK',
	'ARY Shopping Channel': 'PAK',
	'ARY Zouq': 'PAK',
	'ATN Aastha Channel': 'IND',
	'AXN': 'USA',
	'B4U Movies': 'GBR',
	'B4U Music': 'GBR',
	'BabyFirstTV': 'USA',
	'BBC America': 'USA',
	'BBC Canada': 'CAN',
	'BBC Four': 'GBR',
	'BBC Kids': 'CAN',
	'BBC News': 'GBR',
	'BBC One': 'GBR',
	'BBC Parliament': 'GBR',
	'BBC Prime': 'GBR',
	'BBC Three': 'GBR',
	'BBC Two': 'GBR',
	'BBC World News': 'GBR',
	'FYI': 'USA',
	'Boomerang': 'USA',
	'BR': 'DEU',
	'BR-alpha': 'DEU',
	'Bravo (US)': 'USA',
	'Bravo (UK)': 'GBR',
	'Bravo (CA)': 'CAN',
	'Bubble Hits': 'IRL',
	'Canal+': 'FRA',
	'Canvas/Ketnet': 'BEL',
	'Carlton Television': 'GBR',
	'Cartoon Network': 'USA',
	'CBBC': 'GBR',
	'CBC (CA)': 'CAN',
	'CBeebies': 'GBR',
	'CBS': 'USA',
	'CCTV': 'CHN',
	'Challenge': 'GBR',
	'Channel [V]': 'CHN',
	'Channel 4': 'GBR',
	'Channel 5': 'SGP',
	'Channel 6': 'IRL',
	'Channel 8': 'SGP',
	'Channel U': 'SGP',
	'Chart Show TV': 'GBR',
	'Chorus Sports': 'IRL',
	'City Channel': 'IRL',
	'Classic Arts Showcase': 'USA',
	'Classic FM TV': 'GBR',
	'CN8': 'USA',
	'CNBC TV18': 'IND',
	'CNN': 'USA',
	'Comedy Channel': 'USA',
	'CPAC': 'CAN',
	'C-Span': 'USA',
	'CTV': 'CAN',
	'DR1': 'DNK',
	'Das Erste': 'DEU',
	'Dawn News': 'PAK',
	'Deutsche Welle TV': 'DEU',
	'Discovery': 'USA',
	'Discovery Kids': 'USA',
	'Dish TV': 'USA',
	'Disney Channel (US)': 'USA',
	'WOWOW': 'JPN',
	'Disney Cinemagic': 'GBR',
	'Doordarshan National': 'IND',
	'DD-Gujarati': 'IND',
	'Doordarshan News': 'IND',
	'Doordarshan Sports': 'IND',
	'E!': 'USA',
	'E! (CA)': 'CAN',
	'E4': 'GBR',
	'EBS': 'KOR',
	'ERT': 'GRC',
	'ESPN': 'USA',
	'ESPN Asia': 'HKG',
	'ESPN Hong Kong': 'HKG',
	'ESPN India': 'IND',
	'ESPN Philippines': 'PHL',
	'ESPN Taiwan': 'TWN',
	'ETV Gujarati': 'IND',
	'Eurosport': 'GBR',
	'Family (CA)': 'CAN',
	'Fashion TV': 'FRA',
	'Five': 'GBR',
	'Five Life': 'GBR',
	'Five US': 'GBR',
	'Fox Reality': 'USA',
	'France 2': 'FRA',
	'France 3': 'FRA',
	'France 4': 'FRA',
	'France 5': 'FRA',
	'France �': 'FRA',
	'Fred TV': 'USA',
	'Fuji TV': 'JPN',
	'FUNimation Channel': 'USA',
	'FX': 'USA',
	'GEO Super': 'PAK',
	'Geo TV': 'PAK',
	'GMA': 'PHL',
	'GSN': 'USA',
	'Guardian Television Network': 'USA',
	'Hallmark Channel': 'USA',
	'Indus Music': 'PAK',
	'Indus News': 'PAK',
	'Indus Vision': 'PAK',
	'Ion Television': 'USA',
	'KanaalTwee': 'BEL',
	'Kashish TV': 'PAK',
	'KBS': 'KOR',
	'Kerrang! TV': 'GBR',
	'Kids and Teens TV': 'USA',
	'KIKA': 'DEU',
	'Kiss': 'GBR',
	'KTN': 'KEN',
	'KTN': 'PAK',
	'LCI': 'FRA',
	'Liberty Channel': 'USA',
	'Liberty TV': 'GBR',
	'Living': 'GBR',
	'M6': 'FRA',
	'Magic': 'GBR',
	'MATV': 'GBR',
	'MBS': 'JPN',
	'MDR': 'DEU',
	'Mega Channel': 'GRC',
	'MTV (US)': 'USA',
	'MTV Base': 'GBR',
	'MTV Dance': 'GBR',
	'MTV Hits': 'USA',
	'MTV2': 'USA',
	'MBC': 'KOR',
	'MUTV': 'GBR',
	'National Geographic (US)': 'USA',
	'NBC': 'USA',
	'NDR': 'DEU',
	'NDTV 24x7': 'IND',
	'NDTV India': 'IND',
	'New Tang Dynasty TV': 'USA',
	'News One': 'PAK',
	'NHK': 'JPN',
	'Nick at Nite': 'USA',
	'Nick GAS': 'USA',
	'Nickelodeon': 'USA',
	'NickToons': 'USA',
	'Nine Network': 'AUS',
	'Noggin': 'USA',
	'NTA': 'NGA',
	'NTV (JP)': 'JPN',
	'Ovation TV': 'USA',
	'Paramount Comedy': 'GBR',
	'PBS': 'USA',
	'PBS Kids Sprout': 'USA',
	'Phoenix': 'DEU',
	'Phoenix TV': 'CHN',
	'Playboy TV': 'USA',
	'Playhouse Disney': 'USA',
	'PlayJam': 'GBR',
	'Press TV': 'IRN',
	'PRO TV': 'ROU',
	'PTV Bolan': 'PAK',
	'PTV Global': 'USA',
	'PTV Home': 'PAK',
	'PTV News': 'PAK',
	'Pub Channel': 'GBR',
	'Q TV': 'GBR',
	'QTV': 'PAK',
	'QVC': 'USA',
	'Radio Bremen': 'DEU',
	'Radio Canada': 'CAN',
	'RAI': 'ITA',
	'RBB': 'DEU',
	'RCTI': 'IDN',
	'Record': 'BRA',
	'Red Hot TV': 'GBR',
	'Rede Globo': 'BRA',
	'Revelation TV': 'GBR',
	'rmusic TV': 'GBR',
	'Royal News': 'PAK',
	'RT� One': 'IRL',
	'RT� Two': 'IRL',
	'RTL Television': 'DEU',
	'RTP A�ores': 'PRT',
	'RTP �frica': 'PRT',
	'RTP Internacional': 'PRT',
	'RTP Madeira': 'PRT',
	'RTP N': 'PRT',
	'RTP1': 'PRT',
	'S4/C': 'GBR',
	'S4C2': 'GBR',
	'Sab TV': 'IND',
	'Sahara ONE': 'IND',
	'Sanskar': 'IND',
	'SBS': 'KOR',
	'SBS (AU)': 'AUS',
	'Scuzz': 'GBR',
	'SET MAX': 'IND',
	'Setanta Ireland': 'IRL',
	'Seven Network': 'AUS',
	'Showtime': 'USA',
	'SIC': 'PRT',
	'SIC Com�dia': 'PRT',
	'SIC Mulher': 'PRT',
	'SIC Not�cias': 'PRT',
	'SIC Radical': 'PRT',
	'SIC Sempre Gold': 'PRT',
	'Sirasa': 'LKA',
	'Sky Box Office': 'GBR',
	'Sky Cinema (UK)': 'GBR',
	'Sky Movies': 'GBR',
	'Sky News': 'GBR',
	'Sky News Ireland': 'IRL',
	'Sky Sports': 'GBR',
	'Sky Travel': 'GBR',
	'Sky1': 'GBR',
	'Sky2': 'GBR',
	'Sky3': 'GBR',
	'Sleuth': 'USA',
	'Smash Hits': 'GBR',
	'SOAPnet': 'USA',
	'Sony Entertainment Television': 'USA',
	'Sony TV': 'IND',
	'Spike TV': 'USA',
	'STAR Gold': 'IND',
	'STAR Movies': 'HKG',
	'STAR News': 'IND',
	'STAR Plus': 'IND',
	'STAR Sports Asia': 'HKG',
	'STAR Sports Hong Kong': 'HKG',
	'STAR Sports India': 'IND',
	'STAR Sports Southeast Asia': 'HKG',
	'STAR Sports Malaysia': 'MYS',
	'STAR Sports Taiwan': 'TWN',
	'STAR Vijay': 'IND',
	'Star World': 'HKG',
	'Starz!': 'USA',
	'Studio 23': 'PHL',
	'STV (UK)': 'GBR',
	'Style': 'USA',
	'SUN music': 'IND',
	'SUN news': 'IND',
	'SUN TV': 'IND',
	'Superstation WGN': 'USA',
	'Swarnawahini': 'LKA',
	'SWR': 'DEU',
	'Tokyo Broadcasting System': 'JPN',
	'TBS': 'USA',
	'TCM': 'GBR',
	'TeleG': 'GBR',
	'Telemundo': 'USA',
	'Televisa': 'MEX',
	'TEN Sports': 'IND',
	'TF1': 'FRA',
	'The Amp': 'GBR',
	'The Box': 'GBR',
	'The CW': 'USA',
	'The Den': 'IRL',
	'TeenNick': 'USA',
	'The WB': 'USA',
	'The Weather Channel': 'USA',
	'TMC': 'MCO',
	'TMF': 'NLD',
	'TNT': 'USA',
	'Toon Disney': 'USA',
	'TQS': 'CAN',
	'Travel Channel (UK)': 'GBR',
	'Treehouse TV': 'CAN',
	'truTV': 'USA',
	'Turner South': 'USA',
	'TV Asahi': 'JPN',
	'TV Cabo': 'PRT',
	'TV Chile': 'CHL',
	'TV Guide Channel': 'USA',
	'TV Land': 'USA',
	'TVOne Global': 'PAK',
	'TV Tokyo': 'JPN',
	'TV5 Monde': 'FRA',
	'TVB': 'CHN',
	'TVBS': 'CHN',
	'TVE': 'ESP',
	'TVG Network': 'USA',
	'TVI': 'PRT',
	'TVM': 'MLT',
	'TVRI': 'IDN',
	'TVS Sydney': 'AUS',
	'UK Entertainment Channel': 'GBR',
	'Eden': 'GBR',
	'UKTV Drama': 'GBR',
	'UKTV Food': 'GBR',
	'Dave': 'GBR',
	'UKTV Gold': 'GBR',
	'UKTV History': 'GBR',
	'UKTV Style': 'GBR',
	'Univision': 'USA',
	'UNTV 37': 'PHL',
	'UPN': 'USA',
	'USA Network': 'USA',
	'UTV': 'IRL',
	'Varsity TV': 'USA',
	'VH1': 'USA',
	'VH1 Classics': 'USA',
	'VijfTV': 'BEL',
	'Volksmusik TV': 'DEU',
	'VT4': 'BEL',
	'VTM': 'BEL',
	'Warner Channel': 'USA',
	'WDR': 'DEU',
	'WE tv': 'USA',
	'XY TV': 'USA',
	'YLE': 'FIN',
	'YTV (CA)': 'CAN',
	'ZDF': 'DEU',
	'Zee Gujarati': 'IND',
	'Zee Cinema': 'IND',
	'Zee Muzic': 'IND',
	'Zee TV': 'IND',
	'ZOOM': 'IND',
	'ITV': 'GBR',
	'BBC HD': 'GBR',
	'ITV1': 'GBR',
	'ITV2': 'GBR',
	'ITV3': 'GBR',
	'ITV4': 'GBR',
	'FOX (US)': 'USA',
	'Space': 'CAN',
	'HBO': 'USA',
	'SciFi': 'USA',
	'Syndicated': '',
	'Showcase (CA)': 'CAN',
	'Teletoon': 'CAN',
	'T�l�toon': 'FRA',
	'TVNZ': 'NZL',
	'Comedy Central (US)': 'USA',
	'TLC': 'USA',
	'Food Network': 'USA',
	'Global': 'CAN',
	'DuMont Television Network': 'USA',
	'History': 'USA',
	'Encore': 'USA',
	'Lifetime': 'USA',
	'��n': 'BEL',
	'G4': 'USA',
	'Revision3': 'USA',
	'Network Ten': 'AUS',
	'Cinemax': 'USA',
	'Canale 5': 'ITA',
	'Oxygen': 'USA',
	'Court TV': 'USA',
	'HGTV': 'USA',
	'CTC': 'JPN',
	'NRK1': 'NOR',
	'NRK2': 'NOR',
	'NRK3': 'NOR',
	'NRK Super': 'NOR',
	'TV 2': 'NOR',
	'TV 2 Zebra': 'NOR',
	'TV 2 Filmkanalen': 'NOR',
	'TV 2 Nyhetskanalen': 'NOR',
	'TV 2 Sport': 'NOR',
	'TV 2 Science Fiction': 'NOR',
	'TVNorge': 'NOR',
	'Viasat 4': 'NOR',
	'FEM': 'GBR',
	'Syfy': 'USA',
	'IFC': 'USA',
	'SundanceTV': 'USA',
	'TV 2': 'DNK',
	'TV 3': 'DNK',
	'Speed': 'USA',
	'TV 4': 'POL',
	'TVN': 'POL',
	'TVN Turbo': 'POL',
	'TVP SA': 'POL',
	'TVP1': 'POL',
	'TVP2': 'POL',
	'Tokyo MX': 'JPN',
	'SAT.1': 'DEU',
	'ProSieben': 'DEU',
	'TV4': 'SWE',
	'History (CA)': 'CAN',
	'BS11': 'JPN',
	'Arte': 'FRA',
	'Planet Green': 'USA',
	'Schweizer Fernsehen': 'CHE',
	'CBC (JP)': 'JPN',
	'HBO Canada': 'CAN',
	'The Movie Network': 'CAN',
	'Movie Central': 'CAN',
	'Travel Channel': 'USA',
	'AMC': 'USA',
	'ORF 1': 'AUT',
	'ORF 2': 'AUT',
	'Animax': 'JPN',
	'Telecinco': 'ESP',
	'La Siete': 'ESP',
	'TVA (JP)': 'JPN',
	'Investigation Discovery': 'USA',
	'TV Azteca': 'MEX',
	'S�ries+': 'CAN',
	'V': 'CAN',
	'Television Osaka': 'JPN',
	'SVT': 'SWE',
	'Zt�l�': 'CAN',
	'Vrak.TV': 'CAN',
	'Casa': 'CAN',
	'Logo': 'USA',
	'Disney XD': 'USA',
	'Prime (NZ)': 'NZL',
	'2�2': 'RUS',
	'TV Nova': 'CZE',
	'Cesk� televize': 'CZE',
	'Prima televize': 'CZE',
	'Science Channel': 'USA',
	'DIY Network': 'USA',
	'AVRO': 'NLD',
	'NCRV': 'NLD',
	'KRO': 'NLD',
	'VPRO': 'NLD',
	'VARA': 'NLD',
	'BNN (NL)': 'NLD',
	'EO': 'NLD',
	'TROS': 'NLD',
	'Veronica': 'NLD',
	'SBS 6': 'NLD',
	'NET 5': 'NLD',
	'BET': 'USA',
	'ORTF': 'FRA',
	'Fox Business': 'USA',
	'AT-X': 'JPN',
	'OWN': 'USA',
	'CMT': 'USA',
	'Cooking Channel': 'USA',
	'HOT': 'ISR',
	'yes': 'ISR',
	'Current TV': 'USA',
	'The Hub': 'USA',
	'1+1': 'UKR',
	'ICTV': 'UKR',
	'Military Channel': 'USA',
	'WealthTV': 'USA',
	'MTV3': 'FIN',
	'Nelonen': 'FIN',
	'TV3 (NZ)': 'NZL',
	'TV 2 Zulu': 'DNK',
	'TV 2 Charlie': 'DNK',
	'TV3+': 'DNK',
	'TV3 Puls': 'DNK',
	'DR2': 'DNK',
	'DR K': 'DNK',
	'DR Ramasjang': 'DNK',
	'Kanal 4': 'DNK',
	'Kanal 5': 'DNK',
	'dk4': 'DNK',
	'Magyar Telev�zi�': 'HUN',
	'Outdoor Channel': 'USA',
	'The Sportsman Channel': 'USA',
	'ATV': 'AUT',
	'Puls 4': 'AUT',
	'Servus TV': 'AUT',
	'LifeStyle': 'AUS',
	'SVT1': 'SWE',
	'SVT2': 'SWE',
	'Kunskapskanalen': 'SWE',
	'SVT24': 'SWE',
	'SVTB': 'SWE',
	'TV11': 'SWE',
	'TV4 Plus': 'SWE',
	'TV4 Guld': 'SWE',
	'TV4 Fakta': 'SWE',
	'TV4 Komedi': 'SWE',
	'TV4 Science Fiction': 'SWE',
	'TV3 (SE)': 'SWE',
	'TV6': 'SWE',
	'TV7 (SE)': 'SWE',
	'TV8': 'SWE',
	'TV8': 'SWE',
	'HDNet': 'USA',
	'JIM': 'FIN',
	'SuoimiTV': 'FIN',
	'Sub': 'FIN',
	'MoonTV': 'FIN',
	'ReelzChannel': 'USA',
	'BYU Television': 'USA',
	'DMAX (DE)': 'DEU',
	'OLN': 'CAN',
	'Action': 'CAN',
	'Rai 1': 'ITA',
	'Rai 2': 'ITA',
	'Rai 3': 'ITA',
	'Rete 4': 'ITA',
	'Italia 1': 'ITA',
	'Joi': 'ITA',
	'Mya': 'ITA',
	'Steel': 'ITA',
	'Fox (IT)': 'ITA',
	'Fox Life': 'ITA',
	'Fox Crime': 'ITA',
	'RTL 4': 'NLD',
	'RTL 5': 'NLD',
	'RTL 7': 'NLD',
	'RTL 8': 'NLD',
	'CNBC': 'USA',
	'ZDF.Kultur': 'DEU',
	'ZDFneo': 'DEU',
	'Kids Station': 'JPN',
	'Watch': 'GBR',
	'YTV (JP)': 'JPN',
	'TNU': 'URY',
	'Canal 10 Saeta': 'URY',
	'Teledoce': 'URY',
	'Canal 4 Montecarlo': 'URY',
	'Tev�Ciudad': 'URY',
	'Encuentro': 'ARG',
	'TV P�blica': 'ARG',
	'Einsfestival': 'DEU',
	'SR': 'DEU',
	'Kyoto Broadcasting System': 'JPN',
	'YTV (UK)': 'GBR',
	'Velocity': 'USA',
	'ITV Granada': 'GBR',
	'Netflix': 'USA',
	'NTR': 'NLD',
	'TV3 (ES)': 'ESP',
	'BNT1': 'BGR',
	'bTV': 'BGR',
	'NovaTV': 'BGR',
	'TV7 (BG)': 'BGR',
	'MNN': 'USA',
	'Voyage': 'FRA',
	'Fox8': 'AUS',
	'CI': 'AUS',
	'LifeStyle FOOD': 'AUS',
	'LifeStyle HOME': 'AUS',
	'MSNBC': 'USA',
	'NHNZ': 'NZL',
	'Kanal 5': 'SWE',
	'RVU': 'NLD',
	'Jupiter Broadcasting ': 'USA',
	'TWiT': 'USA',
	'Smithsonian Channel': 'USA',
	'Discovery HD World': 'SGP',
	'Discovery Turbo UK': 'GBR',
	'Discovery Turbo': 'USA',
	'Discovery Science': 'USA',
	'FOX Traveller': 'IND',
	'DDR1': 'DEU',
	'G4 Canada': 'CAN',
	'H2': 'USA',
	'TV3 (NO)': 'NOR',
	'TG4': 'IRL',
	'Sky Arts': 'GBR',
	'ABC1': 'AUS',
	'ABC2': 'AUS',
	'ABC3': 'AUS',
	'ABC4Kids': 'AUS',
	'ABC News 24': 'AUS',
	'Fuel TV': 'USA',
	'RT': 'RUS',
	'Russia Today': 'RUS',
	'T�l�-Qu�bec': 'CAN',
	'FOX (FI)': 'FIN',
	'C31': 'AUS',
	'La7': 'ITA',
	'LaSexta': 'ITA',
	'Cuatro': 'ESP',
	'YouTube': 'USA',
	'TNT Serie': 'DEU',
	'TFO': 'CAN',
	'TVA': 'CAN',
	'Slice': 'CAN',
	'IKON': 'NLD',
	'KBS TV1': 'KOR',
	'KBS TV2': 'KOR',
	'KBS World': 'KOR',
	'FOX SPORTS': 'AUS',
	'City': 'CAN',
	'tvN': 'KOR',
	'Sky Atlantic': 'GBR',
	'Pick TV': 'GBR',
	'Niconico': 'JPN',
	'W9': 'FRA',
	'Antenne 2': 'FRA',
	'SET TV': 'TWN',
	'Channel 5': 'GBR',
	'Oasis HD': 'CAN',
	'eqhd': 'CAN',
	'radX': 'CAN',
	'HIFI': 'CAN',
	'La Une': 'BEL',
	'La Deux': 'BEL',
	'La Trois': 'BEL',
	'RTL TVI': 'BEL',
	'Club RTL': 'BEL',
	'Plug RTL': 'BEL',
	'SBT': 'BRA',
	'Multishow': 'BRA',
	'Audience Network': 'USA',
	'Sky Uno': 'ITA',
	'Cielo': 'ITA',
	'VIER': 'BEL',
	'2BE': 'BEL',
	'Tele 5': 'DEU',
	'Hulu': 'USA',
	'Star TV': 'TUR',
	'Show TV': 'TUR',
	'Kanal D': 'TUR',
	'Rooster Teeth': 'USA',
	'here!': 'USA',
	'Prime (BE)': 'BEL',
	'laSexta': 'ESP',
	'GNT': 'BRA',
	'NT1': 'FRA',
	'NBCSN': 'USA',
	'Destination America': 'USA',
	'ARTV': 'CAN',
	'Yahoo! Screen': 'USA',
	'Duna TV': 'HUN',
	'H�r TV': 'HUN',
	'National Geographic Adventure': 'USA',
	'Nat Geo Wild': 'USA',
	'More4': 'GBR',
	'National Geographic (UK)': 'GBR',
	'TV Aichi': 'JPN',
	'FTV': 'TWN',
	'CTV (CN)': 'CHN',
	'DR3': 'DNK',
	'Sky Cinema (IT)': 'ITA',
	'TV Cultura': 'BRA',
	'MTV Italia': 'ITA',
	'TV3 (IE)': 'IRL',
	'EinsPlus': 'DEU',
	'TRT 1': 'TUR',
	'RTL': 'LUX',
	'ATV T�rkiye': 'TUR',
	'RCN TV': 'COL',
	'Caracol TV': 'COL',
	'Venevision': 'VEN',
	'Televen': 'VEN',
	'RCTV': 'VEN',
	'Hrvatska radiotelevizija': 'HRV',
	'tvk': 'JPN',
	'Amazon': 'USA',
	'MBC Plus Media': 'KOR',
	'MBN': 'KOR',
	'CGV': 'KOR',
	'OCN': 'KOR',
	'Fox Channel': 'DEU',
	'Ustream': 'USA',
	'BTV': 'CHN',
	'Mnet': 'KOR',
	'Australian Christian Channel': 'AUS',
	'The Africa Channel': 'GBR',
	'Esquire Network': 'USA',
	'ORF III': 'AUT',
	'Nolife': 'FRA',
	'TestTube': 'USA',
	'jTBC': 'KOR',
	'Hunan TV': 'CHN',
	'La Cinq': 'FRA',
	'AlloCin�': 'FRA',
	'FXX': 'USA',
	'BBC ALBA': 'GBR',
	'TVGN': 'USA',
	'SABC1': 'ZAF',
	'SABC2': 'ZAF',
	'SABC3': 'ZAF',
	'SoHo': 'AUS',
	'TheBlaze': 'USA',
	'Comedy (CA)': 'CAN',
	'MTV (UK)': 'GBR',
	'TV One (US)': 'USA',
	'Crackle': 'USA',
	'Nick Jr.': 'USA',
	'Gulli': 'FRA',
	'Canal J': 'FRA',
	'Syndication': 'USA',
	'FOX Sports 1': 'USA',
	'FOX Sports 2': 'USA',
	'Ch�rie 25': 'FRA',
	'NOS': 'NLD',
	'Colors': 'IND',
	'Omroep MAX': 'NLD',
	'PowNed': 'NLD',
	'WNL': 'NLD',
	'The Verge': 'USA',
	'WGN America': 'USA',
	'Adult Swim': 'USA',
	'Super Channel': 'CAN',
	'RLTV': 'USA',
	'W Network': 'CAN',
	'PTS': 'TWN',
	'PTS HD': 'TWN',
	'Hakka TV': 'TWN',
	'TITV': 'TWN',
	'CTS': 'TWN',
	'CTi TV': 'TWN',
	'ETTV': 'TWN',
	'ETTV Yoyo': 'TWN',
	'GTV': 'TWN',
	'MTV Mandarin': 'TWN',
	'NTV (TW)': 'TWN',
	'SET Metro': 'TWN',
	'STAR Chinese Channel': 'TWN',
	'TTV': 'TWN',
	'TVBS Entertainment Channel': 'TWN',
	'Videoland Television Network': 'TWN',
	'DaAi TV': 'TWN',
	'Much TV': 'TWN',
	'Aizo TV': 'TWN',
	'STV (TW)': 'TWN',
	'Nou 24': 'ESP',
	'Nou Televisi�': 'ESP',
	'Teletama': 'JPN',
	'Toei Channel': 'JPN',
	'CTV (JP)': 'JPN',
	'VOX': 'DEU',
	'El Rey Network': 'USA',
	'Sky Living': 'GBR',
	'Channel 3': 'THA',
	'Kamp�s TV': 'TUR',
	'Life OK': 'IND',
	'Canal Once': 'MEX',
	'Food Network Canada': 'CAN',
	'Al Jazeera America': 'USA',
	'HGTV Canada': 'CAN',
	'Discovery Shed': 'GBR',
	'Pivot': 'USA',
	'TVN': 'CHL',
	'Canal 13': 'CHL',
	'MavTV': 'USA',
	'Great American Country': 'USA',
	'D8': 'FRA',
	'BNN': 'CAN',
	'Crime & Investigation Network': 'USA',
	'CSTV': 'KOR',
	'TrueVisions': 'THA',
	'LMN': 'USA',
	'Jeuxvideo.com': 'FRA',
	'Thames Television': 'GBR',
	'Polsat': 'POL',
	'TVN Style': 'POL',
	'Arena': 'AUS',
	'AXS TV': 'USA',
	'TV One (NZ)': 'NZL',
	'TV2': 'NZL',
	'KCET': 'USA',
	'Omroep Brabant': 'NLD',
	'fuse': 'USA',
	'TSN': 'CAN',
	'El Trece': 'ARG',
	'Vimeo': 'USA',
	'Xbox Video': 'USA',
	'FEARnet': 'USA',
	'Channel 7': 'THA',
	'AHC': 'USA',
	'FOX T�rkiye': 'TUR',
	'RTBF': 'BEL',
	'Ora TV': 'USA',
	'Discovery MAX': 'ESP',
	'DMAX (IT)': 'ITA',
	'ITV Wales': 'GBR',
	'OCS': 'FRA',
	'vtmKzoom': 'BEL',
	'TVO': 'CAN',
	'Televisi�n de Galicia': 'ESP',
	'RTL Klub': 'HUN',
	'Showcase (AU)': 'AUS',
	'Canal Sur': 'ESP',
	'RTL Televizija': 'HRV',
	'Discovery Channel (Asia)': 'SGP',
	'Lifetime UK': 'GBR',
	'TSR': 'CHE',
	'RTS Un': 'CHE',
	'SRF 1': 'CHE',
	'Maori Television': 'NZL',
	'MusiquePlus': 'CAN',
	'Spektrum': 'HUN',
	'Disney Channel (Germany)': 'DEU',
	'TeleZ�ri': 'CHE',
	'3+': 'CHE',
	'MBC Every1': 'KOR',
	'Sportsman Channel': 'USA',
	'Anhui TV': 'CHN',
	'Dragon TV': 'CHN',
	'Jiangsu TV': 'CHN',
	'Zhejiang TV': 'CHN',
	'TVS China': 'CHN',
	'NECO': 'JPN',
	'ART TV': 'GRC',
	'Epsilon TV': 'GRC',
	'Skai': 'GRC',
	'TV S�o Carlos': 'BRA',
	'TBN (Trinity Broadcasting Network)': 'USA',
	'Bounce TV': 'USA',
	'HLN': 'USA',
	'APTN': 'CAN',
	'Omni': 'CAN',
	'addikTV': 'CAN',
	'Centric': 'USA',
	'ICI Tou.tv': 'CAN',
	'RDI': 'CAN',
	'TV Osaka': 'JPN',
	'PlayStation Network': 'USA',
	'ICI Explora': 'CAN',
	'MBC Drama': 'KOR',
	'Sky Deutschland': 'DEU',
	'AOL': 'USA',
	'Channel 2': 'ISR',
	'DRAMAcube': 'KOR',
	'Community Channel': 'GBR',
	'This TV': 'USA',
	'Nagoya Broadcasting Network': 'JPN',
	'M-Net': 'ZAF',
	'NFL Network': 'USA',
	'Pop': 'USA',
	'Super!': 'ITA',
	'Cartoon Network Australia': 'AUS',
	'Canadian Learning Television': 'CAN',
	'Oprah Winfrey Network': 'USA',
	'Alpha TV': 'GRC',
	'TV Net': 'TUR',
	'TRT Kurd�': 'TUR',
	'Kanal A (Turkey)': 'TUR',
	'TRT HD': 'TUR',
	'TRT Haber': 'TUR',
	'TRT Belgesel': 'TUR',
	'TRT World': 'TUR',
	'360': 'TUR',
	'TRT T�rk': 'TUR',
	'TRT �ocuk': 'TUR',
	'TRT Avaz': 'TUR',
	'TRT Arabic': 'TUR',
	'TRT Diyanet': 'TUR',
	'TRT Okul': 'TUR',
	'Cine 5': 'TUR',
	'Dost TV': 'TUR',
	'24': 'TUR',
	'Semerkand TV': 'TUR',
	'A Haber': 'TUR',
	'Kanal 7': 'TUR',
	'�lke TV': 'TUR',
	'TGRT Haber': 'TUR',
	'Beyaz TV': 'TUR',
	'L�leg�l TV': 'TUR',
	'HBO Nordic': 'SWE',
	'Bandai Channel': 'JPN',
	'Sixx': 'DEU',
	'element14': 'USA',
	'HBO Magyarorsz�g': 'HUN',
	'HBO Europe': 'HUN',
	'HBO Latin America': 'BRA',
	'Canal Off': 'BRA',
	'ETV': 'EST',
	'Super �cran': 'CAN',
	'Discovery Life': 'USA',
	'The Family Channel': 'USA',
	'Fox Family': 'USA',
	'Canal 9 (AR)': 'ARG',
	'B92': 'SRB',
	'Ceskoslovensk� televize': 'CZE',
	'CNNI': 'USA',
	'Channel 101': 'USA',
	'Canal 5': 'MEX',
	'MyNetworkTV': 'USA',
	'Blip': 'USA',
	'WPIX': 'USA',
	'Canal Famille': 'CAN',
	'Canal D': 'CAN',
	'�vasion': 'CAN',
	'DIY Network Canada': 'CAN',
	'Much (CA)': 'CAN',
	'MTV Brazil': 'BRA',
	'UKTV Yesterday': 'GBR',
	'Swearnet': 'CAN',
	'Dailymotion': 'USA',
	'RMC D�couverte': 'FRA',
	'Discovery Family': 'USA',
	'SBS Plus': 'KOR',
	'Olive': 'KOR',
	'NAVER tvcast': 'KOR',
	'BBC iPlayer': 'GBR',
	'E-Channel': 'KOR',
	'Pakapaka': 'ARG',
	'Trend E': 'KOR',
	'MBC Queen': 'KOR',
	'iQiyi': 'CHN',
	'CW Seed': 'USA',
	'Rede Bandeirantes': 'BRA',
	'NBA TV': 'USA',
	'ITVBe': 'GBR',
	'Comedy Central (UK)': 'GBR',
	'NRJ 12': 'FRA',
	'Gaiam TV ': 'USA',
	'STAR One': 'IND',
	'Canal de las Estrellas': 'MEX',
	'TVQ (Japan)': 'JPN',
	'TVQ (Australia)': 'AUS',
	'UP TV': 'USA',
	'Universal Channel': 'BRA',
	'Golf Channel': 'USA',
	'CITV': 'GBR',
	'SKY PerfecTV!': 'JPN',
	'Disney Junior': 'USA',
	'Mondo TV': 'ITA',
	't�va': 'FRA',
	'MCM': 'FRA',
	'June': 'FRA',
	'Com�die !': 'FRA',
	'Com�die+': 'FRA',
	'Filles TV': 'FRA',
	'Discovery Channel (Australia)': 'AUS',
	'FOX (UK)': 'GBR',
	'Disney Junior (UK)': 'GBR',
	'n-tv': 'DEU',
	'OnStyle': 'KOR'
	}

def getDB():
	if dbfolder.value == "Flash":
		return DB_Functions('/etc/enigma2/eventLibrary.db')
	else:
		return DB_Functions(os.path.join(getPictureDir(), 'eventLibrary.db'))

def write_log(svalue, logging=True):
	if logging:
		t = localtime()
		logtime = '%02d:%02d:%02d' % (t.tm_hour, t.tm_min, t.tm_sec)
		AEL_log = open(log,"a")
		AEL_log.write(str(logtime) + " : [AdvancedEventLibrary] - " + str(svalue) + "\n")
		AEL_log.close()

def randbelow(exclusive_upper_bound):
	if exclusive_upper_bound <= 0:
		return 0
	return SystemRandom()._randbelow(exclusive_upper_bound)

def get_keys(forwhat):
	if forwhat == 'tmdb' and tmdbKey.value != 'intern':
		return tmdbKey.value
	elif forwhat == 'tvdb' and tvdbKey.value != 'intern':
		return tvdbKey.value
	elif forwhat == 'omdb' and omdbKey.value != 'intern':
		return omdbKey.value
	else:
		return base64.b64decode(ApiKeys[forwhat][randbelow(3)])

def convert2base64(title):
	if title.find('(') > 1:
		return base64.b64encode(title.decode('utf-8').lower().split('(')[0].strip()).replace('/','')
	return base64.b64encode(title.decode('utf-8').lower().strip()).replace('/','')

def createDirs(path):
	path = str(path).replace('poster/','').replace('cover/','')
	if not path.endswith('/'):
		path = path + '/'
	if not path.endswith('AdvancedEventLibrary/'):
		path = path + 'AdvancedEventLibrary/'
	if not os.path.exists(path):
		os.makedirs(path)
	if not os.path.exists(path+'poster/'):
		os.makedirs(path+'poster/')
	if not os.path.exists(path+'cover/'):
		os.makedirs(path+'cover/')
	if not os.path.exists(path+'cover/thumbnails/'):
		os.makedirs(path+'cover/thumbnails/')
	if not os.path.exists(path+'poster/thumbnails/'):
		os.makedirs(path+'poster/thumbnails/')

def getPictureDir():
	return dir

def removeExtension(ext):
	ext = ext.replace('.wmv','').replace('.mpeg2','').replace('.ts','').replace('.m2ts','').replace('.mkv','').replace('.avi','').replace('.mpeg','').replace('.mpg','').replace('.iso','').replace('.mp4','')
	return ext

def createBackup():
	global STATUS
	STATUS = "erzeuge Backup in " + str(backuppath)
	write_log("create backup in " + str(backuppath))
	try:
		if not os.path.exists(backuppath):
			os.makedirs(backuppath)
		if not os.path.exists(backuppath+'poster/'):
			os.makedirs(backuppath+'poster/')
		if not os.path.exists(backuppath+'cover/'):
			os.makedirs(backuppath+'cover/')

		if dbfolder.value == "Flash":
			dbpath = '/etc/enigma2/eventLibrary.db'
		else:
			dbpath = os.path.join(getPictureDir(), 'eventLibrary.db')
		if os.path.isfile(dbpath):
			shutil.copy2(dbpath, os.path.join(backuppath, 'eventLibrary.db'))

		for root, directories, files in os.walk(getPictureDir()+'poster/'):
			if not "thumbnails" in str(root):
				progress = 0
				pics = len(files)
				copied = 0
				for file in files:
					try:
						progress += 1
						target = os.path.join(backuppath+'poster/', file)
						if not os.path.isfile(target):
							shutil.copy2(os.path.join(root, file),target)
							STATUS = "(" + str(progress) + "/" + str(pics) + ") sichere Poster : " + str(os.path.join(root, file))
							copied += 1
						else:
							if os.path.getmtime(os.path.join(root, file)) > os.path.getmtime(target):
								shutil.copy2(os.path.join(root, file),target)
								STATUS = "(" + str(progress) + "/" + str(pics) + ") sichere Poster : " + str(os.path.join(root, file))
								copied += 1
					except Exception as ex:
						write_log("Fehler beim kopieren : " + str(ex))
						continue
				write_log("have copied " + str(copied) + " Poster to " + str(backuppath) + "poster/")

		for root, directories, files in os.walk(getPictureDir()+'cover/'):
			if not "thumbnails" in str(root):
				progress = 0
				pics = len(files)
				copied = 0
				for file in files:
					try:
						progress += 1
						target = os.path.join(backuppath+'cover/', file)
						if not os.path.isfile(target):
							shutil.copy2(os.path.join(root, file),target)
							STATUS = "(" + str(progress) + "/" + str(pics) + ") sichere Cover : " + str(os.path.join(root, file))
							copied += 1
						else:
							if os.path.getmtime(os.path.join(root, file)) > os.path.getmtime(target):
								shutil.copy2(os.path.join(root, file),target)
								STATUS = "(" + str(progress) + "/" + str(pics) + ") sichere Cover : " + str(os.path.join(root, file))
								copied += 1
					except Exception as ex:
						write_log("Fehler beim kopieren : " + str(ex))
						continue
				write_log("have copied " + str(copied) + " Cover to " + str(backuppath) + "cover/")

	except Exception as ex:
		write_log("Fehler in createBackup : " + str(ex))
	STATUS = None
	write_log("backup finished")


def checkUsedSpace(db=None):
	try:
		recordings = getRecordings()
		if dbfolder.value == "Flash":
			dbpath = '/etc/enigma2/eventLibrary.db'
		else:
			dbpath = os.path.join(getPictureDir(), 'eventLibrary.db')
		if os.path.isfile(dbpath) and db:
			config.plugins.AdvancedEventLibrary.MaxSize = ConfigInteger(default=1, limits=(1, 100))
			if "/etc" in dir:
				maxSize = 1 * 1024.0 * 1024.0
			else:
				maxSize = config.plugins.AdvancedEventLibrary.MaxSize.value * 1024.0 * 1024.0
			PDIR = dir + 'poster/'
			CDIR = dir + 'cover/'
			posterSize = float(subprocess.check_output(['du','-sk', PDIR]).split()[0])
			coverSize = float(subprocess.check_output(['du','-sk', CDIR]).split()[0])
			write_log('benutzter Speicherplatz = ' + str(float(posterSize) + float(coverSize)) + ' kB von ' + str(maxSize) + ' kB.')
			if (int(posterSize) + int(coverSize)) > int(maxSize):
				i = 0
				while i < 100:
					titles = db.getUnusedTitles()
					if titles:
						write_log(str(i+1) + '. Bereinigung des Speicherplatzes.')
						for title in titles:
							try:
								if not str(title[0]) in recordings:
									if os.path.isfile(PDIR + title[0] + '.jpg'):
										os.remove(PDIR + title[0] + '.jpg')
									if os.path.isfile(CDIR + title[0] + '.jpg'):
										os.remove(CDIR + title[0] + '.jpg')
									db.cleanDB(title[0])
							except:
								continue
						posterSize = float(subprocess.check_output(['du','-sk', PDIR]).split()[0])
						coverSize = float(subprocess.check_output(['du','-sk', CDIR]).split()[0])
						write_log('benutzter Speicherplatz = ' + str(float(posterSize) + float(coverSize)) + ' kB von ' + str(maxSize) + ' kB.')
					if (posterSize + coverSize) < maxSize:
						break
					i +=1
				db.vacuumDB()
				write_log('benutzter Speicherplatz = ' + str(float(posterSize) + float(coverSize)) + ' kB von ' + str(maxSize) + ' kB.')
	except Exception as ex:
		write_log("Fehler in getUsedSpace : " + str(ex))

def removeLogs():
	if os.path.isfile(log):
		os.remove(log)

def startUpdate():
	if isInstalled:
		start_new_thread(getallEventsfromEPG, ())
	else:
		write_log("AdvancedEventLibrary not installed")

def isconnected():
	try:
		return os.system("ping -c 2 -W 2 -w 4 8.8.8.8")
	except Exception as ex:
		write_log("no internet connection! " + str(ex))
		return False

def createMovieInfo(db):
	global STATUS
	try:
		STATUS = 'suche nach fehlenden meta-Dateien...'
		recordPaths = config.movielist.videodirs.value
		for recordPath in recordPaths:
			if os.path.isdir(recordPath):
				for root, directories, files in os.walk(recordPath):
					if os.path.isdir(root):
						doIt = False
						if str(root) in sPDict:
							if sPDict[root]:
								doIt = True
						if doIt:
							for filename in files:
								try:
									foundAsMovie = False
									foundOnTMDbTV = False
									foundOnTVDb = False
									if (filename.endswith('.ts') or filename.endswith('.mkv') or filename.endswith('.avi') or filename.endswith('.mpg') or filename.endswith('.mp4') or filename.endswith('.iso') or filename.endswith('.mpeg2')):
										if not db.getimageBlackList(removeExtension(str(filename).decode('utf8'))):
											if not os.path.isfile(os.path.join(root, filename + '.meta')):
												title = convertSearchName(convertDateInFileName(((filename.split('/')[-1]).rsplit('.', 1)[0]).replace('__',' ').replace('_',' ')))
												mtitle = title
												titleNyear = convertYearInTitle(title)
												title = titleNyear[0]
												jahr = str(titleNyear[1])
												if title and title != '' and title != ' ':
													tmdb.API_KEY = get_keys('tmdb')
													tvdb.KEYS.API_KEY = get_keys('tvdb')
													titleinfo = {
														"title" : mtitle,
														"genre" : "",
														"year" : "",
														"country" : "",
														"overview" : ""
														}
													try:
														STATUS = 'suche meta-Informationen f�r ' + str(title)
														write_log('suche meta-Informationen f�r ' + str(title), addlog.value)
														search = tmdb.Search()
														if jahr != '':
															res = search.movie(query=title, language='de', year=jahr)
														else:
															res = search.movie(query=title, language='de')
														if res:
															if res['results']:
																reslist = []
																for item in res['results']:
																	reslist.append(item['title'].lower())
																bestmatch = get_close_matches(title.lower(), reslist, 1, 0.7)
																if not bestmatch:
																	bestmatch = [title.lower()]
																for item in res['results']:
																	if item['title'].lower() == bestmatch[0]:
																		foundAsMovie = True
																		titleinfo['title'] = item['title']
																		if 'overview' in item:
																			titleinfo['overview'] = item['overview']
																		if 'release_date' in item:
																			titleinfo['year'] = item['release_date'][:4]
																		if item['genre_ids']:
																			for genre in item['genre_ids']:
																				if not tmdb_genres[genre] in titleinfo['genre']:
																					titleinfo['genre'] = titleinfo['genre'] + tmdb_genres[genre] + ' '
																			maxGenres = titleinfo['genre'].split()
																			if maxGenres:
																				if len(maxGenres) >= 1:
																					titleinfo['genre'] = maxGenres[0]
																		if 'id' in item:
																			details = tmdb.Movies(item['id'])
																			for country in details.info(language='de')['production_countries']:
																				titleinfo['country'] = titleinfo['country'] + country['iso_3166_1'] + " | "
																			titleinfo['country'] = titleinfo['country'][:-3]
																		break
													except Exception as ex:
														write_log('Fehler in createMovieInfo themoviedb movie : ' + str(ex))

													try:
														if not foundAsMovie:
															search = tmdb.Search()
															searchName = findEpisode(title)
															if searchName: 
																res = search.tv(query=searchName[2], language='de', include_adult=True, search_type='ngram')
															else:
																res = search.tv(query=title, language='de', include_adult=True, search_type='ngram')
															if res:
																if res['results']:
																	reslist = []
																	for item in res['results']:
																		reslist.append(item['name'].lower())
																	if searchName:
																		bestmatch = get_close_matches(searchName[2].lower(), reslist, 1, 0.7)
																		if not bestmatch:
																			bestmatch = [searchName[2].lower()]
																	else:
																		bestmatch = get_close_matches(title.lower(), reslist, 1, 0.7)
																		if not bestmatch:
																			bestmatch = [title.lower()]
																	for item in res['results']:
																		if item['name'].lower() == bestmatch[0]:
																			foundOnTMDbTV = True
																			if searchName:
																				try:
																					details = tmdb.TV_Episodes(item['id'],searchName[0],searchName[1])
																					epi = details.info(language='de')
																					#imgs = details.images(language='de')
																					if 'name' in epi:
																						titleinfo['title'] = item['name'] + ' - S' + searchName[0] + 'E' + searchName[1] + ' - ' + epi['name']
																					if 'air_date' in epi:
																						titleinfo['year'] = epi['air_date'][:4]
																					if 'overview' in epi:
																						titleinfo['overview'] = epi['overview']
																					if item['origin_country']:
																						for country in item['origin_country']:
																							titleinfo['country'] = titleinfo['country'] + country + ' | '
																						titleinfo['country'] = titleinfo['country'][:-3]
																					if item['genre_ids']:
																						for genre in item['genre_ids']:
																							if not tmdb_genres[genre] in titleinfo['genre']:
																								titleinfo['genre'] = titleinfo['genre'] + tmdb_genres[genre] + '-Serie '
																						maxGenres = titleinfo['genre'].split()
																						if maxGenres:
																							if len(maxGenres) >= 1:
																								titleinfo['genre'] = maxGenres[0]
																				except:
																					pass
																			else:
																				titleinfo['title'] = item['name']
																				if 'overview' in item:
																					titleinfo['overview'] = item['overview']
																				if item['origin_country']:
																					for country in item['origin_country']:
																						titleinfo['country'] = titleinfo['country'] + country + ' | '
																					titleinfo['country'] = titleinfo['country'][:-3]
																				if 'first_air_date' in item:
																					titleinfo['year'] = item['first_air_date'][:4]
																				if item['genre_ids']:
																					for genre in item['genre_ids']:
																						if not tmdb_genres[genre] in titleinfo['genre']:
																							titleinfo['genre'] = titleinfo['genre'] + tmdb_genres[genre] + '-Serie '
																					maxGenres = titleinfo['genre'].split()
																					if maxGenres:
																						if len(maxGenres) >= 1:
																							titleinfo['genre'] = maxGenres[0]
																			break
													except Exception as ex:
														write_log('Fehler in createMovieInfo themoviedb tv : ' + str(ex))

													try:
														if not foundAsMovie and not foundOnTMDbTV:
															search = tvdb.Search()
															seriesid = None
															ctitle = title
															title = convertTitle2(title)
															try:
																response = search.series(title, language="de")
																if response:
																	reslist = []
																	for result in response:
																		reslist.append(result['seriesName'].lower())
																	bestmatch = get_close_matches(title.lower(), reslist, 1, 0.7)
																	if not bestmatch:
																		bestmatch = [title.lower()]
																	for result in response:
																		if result['seriesName'].lower() == bestmatch[0]:
																			seriesid = result['id']
																			break
															except Exception as ex:
																try:
																	response = search.series(title)
																	if response:
																		reslist = []
																		for result in response:
																			reslist.append(result['seriesName'].lower())
																		bestmatch = get_close_matches(title.lower(), reslist, 1, 0.7)
																		if not bestmatch:
																			bestmatch = [title.lower()]
																		for result in response:
																			if result['seriesName'].lower() == bestmatch[0]:
																				seriesid = result['id']
																				break
																except Exception as ex:
																	pass
															if seriesid:
																foundOnTVDb = True
																show = tvdb.Series(seriesid)
																response = show.info()
																epis = tvdb.Series_Episodes(seriesid)
																episoden = None
																try:
																	episoden = epis.all()
																except:
																	pass
																if episoden:
																	if episoden != 'None':
																		for episode in episoden:
																			try:
																				if str(episode['episodeName']) in str(ctitle):
																					if 'firstAired' in episode:
																						titleinfo['year'] = episode['firstAired'][:4]
																					if 'overview' in episode:
																						titleinfo['overview'] = episode['overview']
																					if response:
																						searchName = findEpisode(title)
																						if searchName:
																							titleinfo['title'] = response['seriesName'] + ' - S' + searchName[0] + 'E' + searchName[1] + ' - ' + episode['episodeName']
																						else:
																							titleinfo['title'] = response['seriesName'] + ' - ' + episode['episodeName']
																						if titleinfo['genre'] == "":
																							for genre in response['genre']:
																								titleinfo['genre'] = titleinfo['genre'] + genre + '-Serie '
																						titleinfo['genre'] = titleinfo['genre'].replace("Documentary", "Dokumentation").replace("Children", "Kinder")
																						if titleinfo['country'] == "":
																							if response['network'] in networks:
																								titleinfo['country'] = networks[response['network']]
																					break
																			except:
																				continue
																else:
																	if response:
																		titleinfo['title'] = response['seriesName']
																		if titleinfo['year'] == "":
																			titleinfo['year'] = response['firstAired'][:4]
																		if titleinfo['genre'] == "":
																			for genre in response['genre']:
																				titleinfo['genre'] = titleinfo['genre'] + genre + '-Serie '
																		titleinfo['genre'] = titleinfo['genre'].replace("Documentary", "Dokumentation").replace("Children", "Kinder")
																		if titleinfo['country'] == "":
																			if response['network'] in networks:
																				titleinfo['country'] = networks[response['network']]
																		if 'overview' in response:
																			titleinfo['overview'] = response['overview']
													except Exception as ex:
														write_log('Fehler in createMovieInfo TVDb : ' + str(ex))


													if titleinfo['overview'] != "":
														txt = open(os.path.join(root, removeExtension(filename) + ".txt"),"w")
														txt.write(titleinfo['overview'])
														txt.close()
														write_log('createMovieInfo for : ' + str(filename))

													if foundAsMovie or foundOnTMDbTV or foundOnTVDb:
														if titleinfo['year'] != "" or titleinfo['genre'] != "" or titleinfo['country'] != "":
															filedt = int(os.stat(os.path.join(root, filename)).st_mtime)
															txt = open(os.path.join(root, filename + ".meta"),"w")
															minfo = "1:0:0:0:B:0:C00000:0:0:0:\n" + str(titleinfo['title']) + "\n"
															if str(titleinfo['genre']) != "":
																minfo += str(titleinfo['genre']) + ", "
															if str(titleinfo['country']) != "":
																minfo += str(titleinfo['country']) + ", "
															if str(titleinfo['year']) != "":
																minfo += str(titleinfo['year']) + ", "
															if minfo.endswith(', '):
																minfo = minfo[:-2]
															else:
																minfo += "\n"
															minfo += "\n" + str(filedt) + "\nAdvanced-Event-Library\n"
															txt.write(minfo)
															txt.close()
															write_log('create meta-Info for ' + str(os.path.join(root, filename)))
														else:
															db.addimageBlackList(removeExtension(str(filename).decode('utf8')))
													else:
														db.addimageBlackList(removeExtension(str(filename).decode('utf8')))
														write_log('nothing found for ' + str(os.path.join(root, filename)))
								except Exception as ex:
									write_log('Fehler in createMovieInfo : ' + str(ex))
									continue
	except Exception as ex:
		write_log('Fehler in createMovieInfo : ' + str(ex))


def getAllRecords(db):
	global STATUS
	try:
		STATUS = 'durchsuche Aufnahmeverzeichnisse...'
		PDIR = dir + 'poster/'
		CDIR = dir + 'cover/'
		names = set()
		recordPaths = config.movielist.videodirs.value
		doPics = False
		if "Pictures" in sPDict:
			if sPDict["Pictures"]:
				doPics = True
		else:
			doPics = True
		for recordPath in recordPaths:
			if os.path.isdir(recordPath):
				for root, directories, files in os.walk(recordPath):
					if os.path.isdir(root):
						doIt = False
						if str(root) in sPDict:
							if sPDict[root]:
								doIt = True
						fileCount = 0
						if doIt:
							for filename in files:
								try:
									if (filename.endswith('.ts') or filename.endswith('.mkv') or filename.endswith('.avi') or filename.endswith('.mpg') or filename.endswith('.mp4') or filename.endswith('.iso') or filename.endswith('.mpeg2')) and doPics:
										if os.path.isfile(os.path.join(root,filename + '.meta')):
											fname = convertDateInFileName(linecache.getline(os.path.join(root,filename + '.meta'), 2).replace("\n",""))
										else:
											fname = convertDateInFileName(convertSearchName(convertTitle(((filename.split('/')[-1]).rsplit('.', 3)[0]).replace('_',' '))))
										searchName = filename + '.jpg'
										if (os.path.isfile(os.path.join(root,searchName)) and not os.path.isfile(PDIR + convert2base64(fname) + '.jpg')):
											write_log('copy poster ' + str(searchName) + ' nach ' + str(fname) + ".jpg")
											shutil.copy2(os.path.join(root,searchName), PDIR + convert2base64(fname) + ".jpg")
										searchName = removeExtension(filename) + '.jpg'
										if (os.path.isfile(os.path.join(root,searchName)) and not os.path.isfile(PDIR + convert2base64(fname) + '.jpg')):
											write_log('copy poster ' + str(searchName) + ' nach ' + str(fname) + ".jpg")
											shutil.copy2(os.path.join(root,searchName), PDIR + convert2base64(fname) + ".jpg")
										searchName = filename + '.bdp.jpg'
										if (os.path.isfile(os.path.join(root,searchName)) and not os.path.isfile(CDIR + convert2base64(fname) + '.jpg')):
											write_log('copy cover ' + str(searchName) + ' nach ' + str(fname) + ".jpg")
											shutil.copy2(os.path.join(root,searchName), CDIR + convert2base64(fname) + ".jpg")
										searchName = removeExtension(filename) + '.bdp.jpg'
										if (os.path.isfile(os.path.join(root,searchName)) and not os.path.isfile(CDIR + convert2base64(fname) + '.jpg')):
											write_log('copy cover ' + str(searchName) + ' nach ' + str(fname) + ".jpg")
											shutil.copy2(os.path.join(root,searchName), CDIR + convert2base64(fname) + ".jpg")
									if filename.endswith('.meta'):
										fileCount += 1
										foundInBl = False
										name = convertDateInFileName(linecache.getline(os.path.join(root,filename), 2).replace("\n",""))
										if db.getblackList(convert2base64(name)):
											name = convertDateInFileName(convertTitle(linecache.getline(os.path.join(root,filename), 2).replace("\n","")))
											if db.getblackList(convert2base64(name)):
												name = convertDateInFileName(convertTitle2(linecache.getline(os.path.join(root,filename), 2).replace("\n","")))
												if db.getblackList(convert2base64(name)):
													foundInBl = True
										if not db.checkTitle(convert2base64(name)) and not foundInBl and name != '' and name != ' ':
											names.add(name)
									if (filename.endswith('.ts') or filename.endswith('.mkv') or filename.endswith('.avi') or filename.endswith('.mpg') or filename.endswith('.mp4') or filename.endswith('.iso') or filename.endswith('.mpeg2')) and doPics:
										foundInBl = False
										name = convertDateInFileName(((filename.split('/')[-1]).rsplit('.', 1)[0]).replace('__',' ').replace('_',' '))
										if db.getblackList(convert2base64(name)):
											name = convertDateInFileName(convertTitle(((filename.split('/')[-1]).rsplit('.', 1)[0]).replace('__',' ').replace('_',' ')))
											if db.getblackList(convert2base64(name)):
												name = convertDateInFileName(convertTitle2(((filename.split('/')[-1]).rsplit('.', 1)[0]).replace('_',' ')))
												if db.getblackList(convert2base64(name)):
													foundInBl = True
										if not db.checkTitle(convert2base64(name)) and not foundInBl and name != '' and name != ' ':
											names.add(name)
								except Exception as ex:
									write_log("Fehler in getAllRecords : " + ' - ' + str(name) + ' - ' + str(ex))
									continue
							write_log('check ' + str(fileCount) + ' meta Files in ' + str(root))
					else:
						write_log('recordPath ' + str(root) + ' is not exists')
			else:
				write_log('recordPath ' + str(recordPath) + ' is not exists')
		write_log('found ' + str(len(names)) + ' new Records in meta Files')
#		check vtidb
		doIt = False
		if "VTiDB" in sPDict:
			if sPDict["VTiDB"]:
				doIt = True
		else:
			doIt = True
		if (os.path.isfile(vtidb_loc) and doIt):
			STATUS = 'durchsuche VTI-DB...'
			vtidb_conn = sqlite3.connect(vtidb_loc,check_same_thread=False)
			cur = vtidb_conn.cursor()
			query = "SELECT title FROM moviedb_v0001"
			cur.execute(query)
			rows = cur.fetchall()
			if rows:
				write_log('check ' + str(len(rows)) + ' titles in vtidb')
				for row in rows:
					try:
						if row[0] and row[0] != '' and row[0] != ' ':
							foundInBl = False
							name = convertTitle(row[0])
							if db.getblackList(convert2base64(name)):
								name = convertTitle2(row[0])
								if db.getblackList(convert2base64(name)):
									foundInBl = True
							if not db.checkTitle(convert2base64(name)) and not foundInBl:
								names.add(name)
					except Exception as ex:
						write_log("Fehler in getAllRecords vtidb: " + str(row[0]) + ' - ' + str(ex))
						continue
		write_log('found ' + str(len(names)) + ' new Records')
		return names
	except Exception as ex:
		write_log("Fehler in getAllRecords : " + str(ex))
		return names

def getRecordings():
	try:
		names = set()
		recordPaths = config.movielist.videodirs.value
		doPics = False
		for recordPath in recordPaths:
			if os.path.isdir(recordPath):
				for root, directories, files in os.walk(recordPath):
					if os.path.isdir(root):
						doIt = False
						if str(root) in sPDict:
							if sPDict[root]:
								doIt = True
						fileCount = 0
						if doIt:
							for filename in files:
								try:
									if filename.endswith('.meta'):
										fileCount += 1
										foundInBl = False
										name = convertDateInFileName(linecache.getline(os.path.join(root,filename), 2).replace("\n",""))
										names.add(name)
									if (filename.endswith('.ts') or filename.endswith('.mkv') or filename.endswith('.avi') or filename.endswith('.mpg') or filename.endswith('.mp4') or filename.endswith('.iso') or filename.endswith('.mpeg2')) and doPics:
										name = convertDateInFileName(((filename.split('/')[-1]).rsplit('.', 1)[0]).replace('__',' ').replace('_',' '))
										names.add(name)
								except Exception as ex:
									write_log("getRecordings : " + ' - ' + str(name) + ' - ' + str(ex))
									continue
#		check vtidb
		doIt = False
		if "VTiDB" in sPDict:
			if sPDict["VTiDB"]:
				doIt = True
		else:
			doIt = True
		if (os.path.isfile(vtidb_loc) and doIt):
			vtidb_conn = sqlite3.connect(vtidb_loc,check_same_thread=False)
			cur = vtidb_conn.cursor()
			query = "SELECT title FROM moviedb_v0001"
			cur.execute(query)
			rows = cur.fetchall()
			if rows:
				for row in rows:
					try:
						if row[0] and row[0] != '' and row[0] != ' ':
							name = convertTitle(row[0])
							names.add(name)
					except Exception as ex:
						write_log("Fehler in getRecordings vtidb: " + str(row[0]) + ' - ' + str(ex))
						continue
		return names
	except Exception as ex:
		write_log("Fehler in getRecordings : " + str(ex))
		return names

def getallEventsfromEPG():
	global STATUS
	try:
		STATUS = '�berpr�fe Verzeichnisse...'
		createDirs(dir)
		STATUS = 'entferne Logfile...'
		removeLogs()
		write_log("Update start...")
		write_log("default image path is " + str(getEpgShareImagePath()))
		write_log("searchOptions " + str(sPDict))
		db = getDB()
		db.parameter(PARAMETER_SET, 'laststart', str(time()))
		cVersion = db.parameter(PARAMETER_GET, 'currentVersion', None, 57)
		if int(cVersion) < 58 and previewImages:
			db.parameter(PARAMETER_SET, 'currentVersion', '62')
			db.cleanliveTV(int(time() + (14*86400)))
		STATUS = '�berpr�fe reservierten Speicherplatz...'
		checkUsedSpace(db)
		names = getAllRecords(db)
		names = getallEventsfromEPGShare(names, db)
		STATUS = 'durchsuche aktuelles EPG...'
		lines = []
		mask = (eServiceReference.isMarker | eServiceReference.isDirectory)
		root = eServiceReference(str(service_types_tv + ' FROM BOUQUET "bouquets.tv" ORDER BY bouquet'))
		serviceHandler = eServiceCenter.getInstance()
		tvbouquets = serviceHandler.list(root).getContent("SN", True)
		for bouquet in tvbouquets:
			root = eServiceReference(str(bouquet[0]))
			serviceHandler = eServiceCenter.getInstance()
			ret = serviceHandler.list(root).getContent("SN", True)
			doIt = False
			if str(bouquet[1]) in sPDict:
				if sPDict[str(bouquet[1])]:
					doIt = True
			else:
				doIt = True
			if doIt:
				for (serviceref, servicename) in ret:
					playable = not (eServiceReference(serviceref).flags & mask)
					if playable and "p%3a" not in serviceref and "<n/a>" not in servicename and servicename != ".":
						line = [serviceref,servicename]
						if line not in lines:
							lines.append(line)

		acttime = time() + 1000
		test = ['RITB']
		for line in lines:
			test.append((line[0], 0, acttime, -1))

		epgcache = eEPGCache.getInstance()
		allevents = epgcache.lookupEvent(test) or []
		write_log('found ' + str(len(allevents)) + ' Events in EPG')
		evt = 0
		isShare = isEPGShare()
		if isShare:
			db.getEPGShareData(db)

		liveTVRecords = []
		for serviceref, eid, name, begin in allevents:
			try:
				evt += 1
				STATUS = 'durchsuche aktuelles EPG... (' + str(evt) + '/' + str(len(allevents)) + ')'
				tvname = name
				tvname = re.sub('\\(.*?\\)', '', tvname).strip()
				tvname = re.sub(' +', ' ', tvname)
				if not db.checkliveTV(eid, serviceref) and str(tvname) not in excludeNames and not 'Invictus' in str(tvname):
						record = (eid,'in progress','','','','','',tvname.decode('utf8'),begin,'','','','','','','','',serviceref)
						liveTVRecords.append(record)

				foundInBl = False
				name = convertTitle(name)
				if db.getblackList(convert2base64(name)):
					name = convertTitle2(name)
					if db.getblackList(convert2base64(name)):
						foundInBl = True
				if not db.checkTitle(convert2base64(name)) and not foundInBl:
					names.add(name)
			except Exception as ex:
				write_log('Fehler in get_allEventsfromEPG : ' + str(ex))
				continue
		write_log('check ' + str(len(names)) + ' new events')
		limgs = True
		if str(searchfor.value) == "nur Extradaten":
			limgs = False
		get_titleInfo(names, None, limgs, db, liveTVRecords)
	except Exception as ex:
		write_log("Fehler in get_allEventsfromEPG : " + str(ex))

def getTVMovie(db, secondRun = False):
	global STATUS
	try:
		evt = 0
		founded = 0
		imgcount = 0
		tvnames = set()
		coverDir = getPictureDir() + 'cover/'
		if not secondRun:
			tvnames = db.getTitlesforUpdate()
			write_log('check ' + str(len(tvnames)) + ' titles on TV-Movie')
		else:
			tvnames = db.getTitlesforUpdate2()
			write_log('recheck ' + str(len(tvnames)) + ' titles on TV-Movie')
		for title in tvnames:
			try:
				evt += 1
				if not secondRun:
					tvname = correctTitleName(title[0])
					for convName in convNames:
						if str(tvname).startswith(str(convName)):
							if str(tvname).startswith('Die Bergpolizei'):
								tvname = convertTitle2(tvname) + ' - Ganz nah am Himmel'
							else:
								tvname = convertTitle2(tvname)
				else:
					tvname = convertTitle2(title[0])
				results = None
				searchurl = 'http://capi.tvmovie.de/v1/broadcasts/search?q=%s&page=1&rows=400'
#				url = searchurl % urllib2.quote(re.sub('[^0-9a-zA-Z-:!., ]+', '*', str(tvname)))#.lower())
				url = searchurl % urllib2.quote(str(tvname))#.lower())
				STATUS = '(' + str(evt) + '/' + str(len(tvnames)) + ') suche auf TV-Movie nach ' + str(tvname) + " (" + str(founded) + " | " + str(imgcount) + ")"
				results = json.loads(requests.get(url, timeout=4).text)
				if results:
					if 'results' in results:
						reslist = set()
						for event in results['results']:
							reslist.add(event['title'].lower())
							if 'originalTitle' in event:
								reslist.add(event['originalTitle'].lower())
						bestmatch = get_close_matches(tvname.lower(), reslist, 2, 0.7)
						if not bestmatch:
							bestmatch = [tvname.lower()]
						nothingfound = True
						lastImage = ""
						for event in results['results']:
							try:
								original_title = 'abc123def456'
								if 'originalTitle' in event:
									original_title = event['originalTitle'].lower()
								if event['title'].lower() in bestmatch or original_title in bestmatch:
									airtime = 0
									if 'airTime' in event:
										airtime = int(mktime(datetime.strptime(str(event['airTime']), '%Y-%m-%d %H:%M:%S').timetuple()))
									if airtime <= db.getMaxAirtime(title[0]): 
										nothingfound = False
										id = ""
										subtitle = ""
										image = ""
										year = ""
										fsk = ""
										rating = ""
										leadText = ""
										conclusion = ""
										categoryName = ""
										season = ""
										episode = ""
										genre = ""
										country = ""
										imdb = ""
										if 'id' in event:
											id = str(event['id'])
										if 'previewImage' in event:
											image = event['previewImage']['id']
										if 'genreName' in event:
											genre = event['genreName']
										if 'categoryName' in event:
											categoryName = event['categoryName']
										if 'productionYear' in event:
											year = event['productionYear']
										if 'countryOfProduction' in event:
											country = event['countryOfProduction']
										if 'ageRating' in event:
											if not 'Unbekannt' in str(event['ageRating']):
												if 'OhneAlter' in str(event['ageRating']):
													fsk = '0'
												elif 'KeineJugend' in str(event['ageRating']):
													fsk = '18'
												else:
													fsk = event['ageRating']
										if 'season' in event:
											season = event['season']
										if 'episode' in event:
											episode = event['episode']
										if 'subTitle' in event:
											if not 'None' in str(event['subTitle']):
												subtitle = event['subTitle']
										if 'leadText' in event:
											leadText = event['leadText']
										if 'conclusion' in event:
											conclusion = event['conclusion']
										if 'movieStarValue' in event:
											rating = str(int(event['movieStarValue'] * 2))
										if 'imdbId' in event:
											imdb = event['imdbId']

										bld = ""
										if image != "" and str(searchfor.value) != "nur Extradaten" and previewImages:
											bld = image
											imgname = title[0] + ' - '
											if season != "":
												imgname += 'S' + str(season).zfill(2)
											if episode != "":
												imgname += 'E' + str(episode).zfill(2) + ' - '
											if subtitle != "":
												imgname += subtitle + ' - '
											image = imgname[:-3]
										else:
											image = ""
										success = founded
										
										founded += db.updateliveTV(id,subtitle,image,year,fsk,rating,leadText,conclusion,categoryName,season,episode,genre,country,imdb,title[0],airtime)
										if founded > success and bld != "" and str(searchfor.value) != "nur Extradaten" and previewImages and str(image) != str(lastImage):
#											if not db.checkTitle(convert2base64(image)):
#												db.addTitleInfo(convert2base64(image),image,genre,year,rating,fsk,country)
											if len(convert2base64(image)) < 255:
												imgpath = coverDir + convert2base64(image) + '.jpg'
												if downloadTVMovieImage(bld, imgpath):
													imgcount += 1
													lastImage = image
							except Exception as ex:
								write_log('Fehler in TV-Movie : ' + str(ex) + ' - ' + str(title[0]) + ' url ' + str(url))
								continue
						if nothingfound:
							write_log('nothing found on TV-Movie for ' + str(title[0]) + ' url ' + str(url), addlog.value)
			except Exception as ex:
				write_log('Fehler in TV-Movie : ' + str(ex) + ' - ' + str(title[0]) + ' url ' + str(url))
				continue
		write_log('have updated ' + str(founded) + ' events from TV-Movie')
		write_log('have downloaded ' + str(imgcount) + ' images from TV-Movie')
		if not secondRun:
			getTVMovie(db, True)
	except Exception as ex:
		write_log('Fehler in getTVMovie : ' + str(ex))

def correctTitleName(tvname):
	if 'CSI: New York' in tvname:
		tvname = 'CSI: NY'
	elif 'CSI: Vegas' in tvname:
		tvname = 'CSI: Den T�tern auf der Spur'
	elif 'Star Trek - Das n' in tvname:
		tvname = 'Raumschiff Enterprise - Das n�chste Jahrhundert'
	elif 'SAT.1-Fr' in tvname:
		tvname = 'Sat.1-Fr�hst�cksfernsehen'
	elif 'Gefragt - Gejagt' in tvname:
		tvname = 'Gefragt Gejagt'
	elif 'nder - Menschen - Abenteuer' in tvname:
		tvname = 'L�nder Menschen Abenteuer'
	elif 'Land - Liebe - Luft' in tvname:
		tvname = 'Land Liebe Luft'
	elif 'Stadt - Land - Quiz' in tvname:
		tvname = 'Stadt Land Quiz'
	elif 'Peppa Pig' in tvname:
		tvname = 'Peppa'
	elif 'Scooby-Doo!' in tvname:
		tvname = 'Scooby-Doo'
	elif 'ZDF SPORTreportage' in tvname:
		tvname = 'Sportreportage'
	elif 'The Garfield ShowT' in tvname:
		tvname = 'The Garfield Show'
	elif 'ProSieben S' in tvname:
		tvname = 'Sp�tnachrichten'
	elif 'Explosiv - Weekend' in tvname:
		tvname = 'Explosiv Weekend'
	elif 'Exclusiv - Weekend' in tvname:
		tvname = 'Exclusiv Weekend'
	elif 'Exclusiv - Das Starmagazin' in tvname:
		tvname = 'Exclusiv - Das Star-Magazin'
	elif 'Krass Schule - Die jungen Lehrer - Wie alles begann' in tvname:
		tvname = 'Krass Schule - Die jungen Lehrer'
	elif 'Die Megaschiff-Bauer' in tvname:
		tvname = 'Die Megaschiffbauer'
	elif 'Stargate: Atlantis' in tvname:
		tvname = 'Stargate Atlantis'
	elif 'Mega-Bauwerke' in tvname:
		tvname = 'Megastructures'
	elif 'Das Universum' in tvname:
		tvname = 'Das Universum - Eine Reise durch Raum und Zeit'
	elif 'Die wilden Siebziger' in tvname or 'Die Wilden Siebziger' in tvname:
		tvname = 'Die wilden 70er'
	elif 'MDR um 2' in tvname:
		tvname = 'MDR um zwei'
	elif 'MDR um 4' in tvname:
		tvname = 'MDR um vier'
	elif 'MDR um 11' in tvname:
		tvname = 'MDR um elf'
	elif 'MDR SACHSEN-ANHALT HEUTE' in tvname:
		tvname = 'MDR Regional'
	elif 'MDR SACHSENSPIEGEL' in tvname:
		tvname = 'MDR Regional'
	elif 'RINGEN JOURNAL' in tvname:
		tvname = 'MDR Regional'
	elif 'Geo Reportage' in tvname or 'GEO Reportage' in tvname:
		tvname = '360 Geo-Reportage'
	elif '7 Tage' in tvname:
		tvname = '7 Tage'
	elif 'Die Brot-Piloten' in tvname:
		tvname = 'Die Brotpiloten'
	elif 'Die UFO-Akten' in tvname:
		tvname = 'Die geheimen UFO-Akten - Besuch aus dem All'
	elif 'Dragons - Die W' in tvname:
		tvname = 'DreamWorks: Die Drachenreiter von Berk'
	elif 'Jim Hensons: Doozers' in tvname:
		tvname = 'Doozers'
	elif 'Lecker aufs Land' in tvname:
		tvname = 'Lecker aufs Land - eine kulinarische Reise'
	elif 'Schloss Einstein' in tvname:
		tvname = 'Schloss Einstein'
	elif 'Heiter bis t' in tvname:
		if tvname.find(': ') > 0:
			tvname = tvname[tvname.find(': ')+2:].strip()
		elif tvname.find(' - ') > 0:
			tvname = tvname[tvname.find(' - ')+3:].strip()
	return tvname.replace(' & ',' ')


def convertTitle(name):
	if name.find(' (') > 0:
		regexfinder = re.compile(r"\([12][90]\d{2}\)", re.IGNORECASE)
		ex = regexfinder.findall(name)
		if not ex:
			name = name[:name.find(' (')].strip()
	if name.find(' - S0') > 0:
		name = name[:name.find(' - S0')].strip()
	if name.find(' S0') > 0:
		name = name[:name.find(' S0')].strip()
	if name.find('Folge') > 0:
		name = name[:name.find('Folge')].strip()
	if name.find('Episode') > 0:
		name = name[:name.find('Episode')].strip()
	return name

def convertTitle2(name):
	if name.find(' (') > 0:
		regexfinder = re.compile(r"\([12][90]\d{2}\)", re.IGNORECASE)
		ex = regexfinder.findall(name)
		if not ex:
			name = name[:name.find(' (')].strip()
	if name.find(':') > 0:
		name = name[:name.find(':')].strip()
	if name.find(' - S0') > 0:
		name = name[:name.find(' - S0')].strip()
	if name.find(' S0') > 0:
		name = name[:name.find(' S0')].strip()
	if name.find(' -') > 0:
		name = name[:name.find(' -')].strip()
	if name.find('Folge') > 0:
		name = name[:name.find('Folge')].strip()
	if name.find('Episode') > 0:
		name = name[:name.find('Episode')].strip()
	if name.find('!') > 0:
		name = name[:name.find('!')+1].strip()
	return name

def findEpisode(title):
	try:
		regexfinder = re.compile('[Ss]\d{2}[Ee]\d{2}', re.MULTILINE|re.DOTALL)
		ex = regexfinder.findall(str(title))
		if ex:
			removedEpisode = title
			if removedEpisode.find(str(ex[0])) > 0:
					removedEpisode = removedEpisode[:removedEpisode.find(str(ex[0]))]
			removedEpisode = convertTitle2(removedEpisode)
			SE = ex[0].replace('S','').replace('s','').split('E')
			return (SE[0],SE[1], removedEpisode.strip())
		return None
	except:
		return None

def convertSearchName(eventName):
	try:
		text = eventName.decode('utf-8', 'ignore').replace(u'\x86', u'').replace(u'\x87', u'').encode('utf-8', 'ignore')
	except:
		text = eventName.decode('utf-8', 'ignore').replace(u'\x86', u'').replace(u'\x87', u'')
	return text

def convertDateInFileName(fileName):
	regexfinder = re.compile('\d{8} - ', re.IGNORECASE)
	ex = regexfinder.findall(fileName)
	if ex:
		return fileName.replace(ex[0], '')
	return fileName

def convertYearInTitle(title):
	regexfinder = re.compile(r"\([12][90]\d{2}\)", re.IGNORECASE)
	ex = regexfinder.findall(title)
	if ex:
		return [title.replace(ex[0], '').strip(), ex[0].replace('(','').replace(')','')]
	return [title, '']

def downloadImage(url, filename, timeout=5):
	try:
		if not os.path.isfile(filename):
			r = requests.get(url, stream=True, timeout=timeout)
			if r.status_code == 200:
				with open(filename, 'wb') as f:
					r.raw.decode_content = True
					shutil.copyfileobj(r.raw, f)
			else:
				write_log("Fehlerhafter Statuscode beim Download f�r : " + str(filename) + ' auf ' + str(url))
		else:
			write_log("Picture : " + str(base64.b64decode(filename.split('/')[-1].replace('.jpg',''))) + ' exists already ', addlog.value)
	except Exception as ex:
		write_log("Fehler in download image: " + str(ex))

def downloadImagefromAELImageServer(url, filename, timeout=5):
	try:
		if not os.path.isfile(filename):
			write_log("try to download image from: " + str(url))

			res = requests.get(url, stream=True, timeout=timeout)
			if res.status_code == 200:
				with open(filename, 'wb') as f:
					res.raw.decode_content = True
					shutil.copyfileobj(res.raw, f)
				write_log("found Image : " + str(filename) + ' auf AEL-Image-Server')
			else:
				write_log("Fehlerhafter Statuscode beim Download f�r : " + str(filename) + ' auf ' + str(url))
		else:
			write_log("Picture : " + str(base64.b64decode(filename.split('/')[-1].replace('.jpg',''))) + ' exists already ', addlog.value)
	except Exception as ex:
		write_log("Fehler in downloadImagefromAELImageServer : " + str(ex))


def downloadAllImagesfromAELImageServer(overwrite=False):
	global STATUS
	from zipfile import ZipFile
	global what
	global url
	global filename
	global dooverwrite
	dooverwrite = overwrite
	what = 'cover'
	url='http://ael.timobayl.de/index.php/s/J6y2cbB38HDQp33/download'
#	url = 'https://timobayl.de/AEL/index.php/s/RfW2ZXiTcfA3z4D/download?path=%2F&files=cover'
	filename = getPictureDir() + 'cover.zip'
	def downloadProgress(recvbytes, totalbytes):
		global STATUS
		global what
		if totalbytes:
			progress = int(100 * recvbytes / float(totalbytes))
			STATUS = "lade Bilder von AEL-Image-Server ... " + str(int(progress)) + '%'
		else:
			progress = int(recvbytes)
			STATUS = "lade " + str(what) + " von AEL-Image-Server ... " + str(bytes2human(progress,1))

	def downloadFinished(string=''):
		global STATUS
		global what
		global url
		global filename
		global dooverwrite
		write_log("extract files for " + str(what))
		STATUS = 'Extrahiere Dateien f�r ' + str(what)
		cdir = getPictureDir() +'aelDownload/'
		if not os.path.exists(cdir):
			os.makedirs(cdir)
		with ZipFile(filename, 'r') as zip: 
			zip.extractall(cdir)
		cf = 0
		rf = 0
		STATUS = 'kopiere neue ' + str(what)
		for root, directories, files in os.walk(cdir + str(what) + '/'):
			for file in files:
				if dooverwrite:
					shutil.copy2(os.path.join(root, file), os.path.join(dir + str(what).lower() + '/', file))
					createSingleThumbnail(os.path.join(root, file), os.path.join(dir + str(what).lower(), file))
					cf += 1
				else:
					if not os.path.isfile(os.path.join(dir + str(what).lower() + '/', file)):
						shutil.copy2(os.path.join(root, file), os.path.join(dir + str(what).lower() + '/', file))
						createSingleThumbnail(os.path.join(root, file), os.path.join(dir + str(what).lower(), file))
						cf += 1
			for file in files:
				os.remove(os.path.join(root, file))
				rf += 1
		os.remove(filename)
		write_log("found " + str(rf) + ' images. got ' + str(cf) + ' new files')
		STATUS = None
		if what == 'poster':
			db = getDB()
			if db:
				db.parameter(PARAMETER_SET, 'lastimagedownload', str(time()))
		if what != 'poster':
			what = 'poster'
			url = 'http://ael.timobayl.de/index.php/s/476Wk32A8QSsXd7/download'
#			url = 'https://timobayl.de/AEL/index.php/s/RfW2ZXiTcfA3z4D/download?path=%2F&files=poster'
			filename = getPictureDir() + 'poster.zip'
			startDownload()

	def downloadFailed(failure_instance=None, error_message=""):
		global STATUS
		if error_message == "" and failure_instance is not None:
			error_message = failure_instance.getErrorMessage()
			STATUS = None
			write_log("Fehler beim Download : " + str(error_message))

	def startDownload():
		try:
			global STATUS
			global what
			global url
			global filename
			write_log("try to download all " + str(what) + "s from AEL-Image-Server")
			STATUS = 'lade ' + str(what) + ' vom AEL-Image-Server herunter...'
			download = downloadWithProgress(url,filename)
			download.addProgress(downloadProgress)
			download.start().addCallback(downloadFinished).addErrback(downloadFailed)
		except Exception as ex:
			write_log("Fehler in downloadAllImagesfromAELImageServer : " + str(ex))
			STATUS = None
	startDownload()

def checkAELImageServer(url, timeout=5):
	try:
		res = requests.get(url, stream=True, timeout=timeout)
		if res.status_code == 200:
			return True
		else:
			return False
	except Exception as ex:
		write_log("Fehler in checkAELImageServer : " + str(ex))
		return False

def reduceImageSize(path, db):
	try:
		global STATUS
		if 'cover' in str(path):
			imgsize = coverqualityDict[coverquality.value]
		else:
			imgsize = posterqualityDict[posterquality.value]
		sizex, sizey = imgsize.split("x",1)
		filelist = glob.glob(os.path.join(path, "*.jpg"))
		maxSize = int(maxImageSize.value)
		maxcompression = int(maxCompression.value)
		for f in filelist:
			try:
				q = 90
				if not db.getimageBlackList(f):
					oldSize = int(os.path.getsize(f)/1024.0)
					if oldSize > maxSize:
						try:
							fn= base64.b64decode((f.split('/')[-1]).rsplit('.', 1)[0])
						except:
							fn = (f.split('/')[-1]).rsplit('.', 1)[0]
							fn = fn.replace('.jpg','')
						try:
							img = Image.open(f)
						except:
							continue
						w = int(img.size[0])
						h = int(img.size[1])
						STATUS = 'Bearbeite ' + str(fn) + '.jpg mit ' + str(bytes2human(os.path.getsize(f),1)) + ' und ' + str(w) + 'x' + str(h) + 'px'
						img_bytes = StringIO.StringIO()
						img1 = img.convert('RGB', colors=256)
						img1.save(img_bytes, format='jpeg')
						if img_bytes.tell()/1024 >= oldSize:
							if w > int(sizex):
								w = int(sizex)
								h = int(sizey)
								img1 = img.resize((w,h), Image.ANTIALIAS)
								img1.save(img_bytes, format='jpeg')
						else:
							if w > int(sizex):
								w = int(sizex)
								h = int(sizey)
								img1 = img1.resize((w,h), Image.ANTIALIAS)
								img1.save(img_bytes, format='jpeg')
						if img_bytes.tell()/1024 > maxSize:
							while img_bytes.tell()/1024 > maxSize:
								img1.save(img_bytes, format='jpeg', quality=q)
								q -= 8
								if q <= maxcompression:
									break
						img1.save(f, format='jpeg', quality=q)
						write_log('file ' + str(fn) + '.jpg reduced from ' + str(bytes2human(int(oldSize*1024),1)) + ' to '+ str(bytes2human(os.path.getsize(f),1)) + ' and ' + str(w) + 'x' + str(h) + 'px')
						if os.path.getsize(f)/1024.0 > maxSize:
							write_log('Image size cannot be further reduced with the current settings!')
							db.addimageBlackList(str(f))
						img_bytes.close()
			except Exception as ex:
				write_log("Fehler in reduceImageSize: " + str(ex))
				continue
	except Exception as ex:
		write_log("Fehler in reduceImageSize: " + str(ex))

def reduceSigleImageSize(src, dest):
	try:
		if 'cover' in str(dest):
			imgsize = coverqualityDict[coverquality.value]
		else:
			imgsize = posterqualityDict[posterquality.value]
		sizex, sizey = imgsize.split("x",1)
		maxSize = int(maxImageSize.value)
		maxcompression = int(maxCompression.value)
		q = 90
		try:
			oldSize = int(os.path.getsize(src)/1024.0)
			if oldSize > maxSize:
				try:
					fn= base64.b64decode((src.split('/')[-1]).rsplit('.', 1)[0])
				except:
					fn = (src.split('/')[-1]).rsplit('.', 1)[0]
					fn = fn.replace('.jpg','')
				try:
					img = Image.open(src)
					w = int(img.size[0])
					h = int(img.size[1])
					write_log('convert image ' + str(fn) + '.jpg with ' + str(bytes2human(os.path.getsize(src),1)) + ' and ' + str(w) + 'x' + str(h) + 'px')
					img_bytes = StringIO.StringIO()
					img1 = img.convert('RGB', colors=256)
					img1.save(img_bytes, format='jpeg')
					if img_bytes.tell()/1024 >= oldSize:
						if w > int(sizex):
							w = int(sizex)
							h = int(sizey)
							img1 = img.resize((w,h), Image.ANTIALIAS)
							img1.save(img_bytes, format='jpeg')
					else:
						if w > int(sizex):
							w = int(sizex)
							h = int(sizey)
							img1 = img1.resize((w,h), Image.ANTIALIAS)
							img1.save(img_bytes, format='jpeg')
					if img_bytes.tell()/1024 > maxSize:
						while img_bytes.tell()/1024 > maxSize:
							img1.save(img_bytes, format='jpeg', quality=q)
							q -= 8
							if q <= maxcompression:
								break
					img1.save(dest, format='jpeg', quality=q)
					write_log('file ' + str(fn) + '.jpg reduced from ' + str(bytes2human(int(oldSize*1024),1)) + ' to '+ str(bytes2human(os.path.getsize(dest),1)) + ' and ' + str(w) + 'x' + str(h) + 'px')
					if os.path.getsize(dest)/1024.0 > maxSize:
						write_log('Image size cannot be further reduced with the current settings!')
					img_bytes.close()
				except Exception as ex:
					write_log("Fehler in reduceSingleImageSize: " + str(ex))
		except Exception as ex:
			write_log("Fehler in reduceSingleImageSize: " + str(ex))
	except Exception as ex:
		write_log("Fehler in reduceSingleImageSize: " + str(ex))

def createThumbnails(path):
	try:
		global STATUS
		wp, hp = skin.parameters.get("EventLibraryThumbnailPosterSize", (60, 100))
		wc, hc = skin.parameters.get("EventLibraryThumbnailCoverSize", (100, 60))
		filelist = glob.glob(os.path.join(path, "*.jpg"))
		for f in filelist:
			try:
				destfile = f.replace('cover', 'cover/thumbnails').replace('poster', 'poster/thumbnails')
				if not os.path.isfile(destfile):
					STATUS = 'erzeuge Thumbnail f�r ' + str(f)
					img = Image.open(f)
					imgnew = img.convert('RGBA', colors=256)
					if 'cover' in str(f):
						imgnew = img.resize((wc,hc), Image.ANTIALIAS)
					else:
						imgnew = img.resize((wp,hp), Image.ANTIALIAS)
					imgnew.save(destfile)
			except Exception as ex:
				write_log("Fehler in createThumbnails: " + str(ex))
				os.remove(f)
				continue
	except Exception as ex:
		write_log("Fehler in createThumbnails: " + str(ex))

def createSingleThumbnail(src, dest):
	try:
		wp, hp = skin.parameters.get("EventLibraryThumbnailPosterSize", (60, 100))
		wc, hc = skin.parameters.get("EventLibraryThumbnailCoverSize", (100, 60))
		destfile = dest.replace('cover', 'cover/thumbnails').replace('poster', 'poster/thumbnails')
		img = Image.open(src)
		imgnew = img.convert('RGBA', colors=256)
		if 'cover' in str(dest):
			imgnew = img.resize((wc,hc), Image.ANTIALIAS)
		else:
			imgnew = img.resize((wp,hp), Image.ANTIALIAS)
		imgnew.save(destfile)
	except Exception as ex:
		write_log("Fehler in createSingleThumbnail: " + str(ex))

def get_titleInfo(titles, research=None, loadImages=True, db=None, liveTVRecords=[]):
	global STATUS
	if isconnected() == 0 and isInstalled:
		posterDir = getPictureDir()+'poster/'
		coverDir = getPictureDir()+'cover/'
		posters = 0
		covers = 0
		entrys = 0
		blentrys = 0
		position = 0
		for title in titles:
			try:
				if title and title != '' and title != ' ':
					tvdb.KEYS.API_KEY = get_keys('tvdb')
					tmdb.API_KEY = get_keys('tmdb')
					titleinfo = {
						"title" : "",
						"genre" : "",
						"poster_url" : "",
						"backdrop_url" : "",
						"year" : "",
						"rating" : "",
						"fsk" : "",
						"country" : ""
						}
					titleinfo['title'] = convertSearchName(title)
					titleNyear = convertYearInTitle(title)
					title = convertSearchName(titleNyear[0])
					jahr = str(titleNyear[1])
					position += 1
					org_name = None
					imdb_id = None
					omdb_image = None
					foundAsMovie = False
		#			write_log('################################################### themoviedb movie ##############################################')
					try:
						STATUS = str(position) + '/' + str(len(titles)) + ' : themoviedb movie -' + str(title)  + '  (' + str(posters)  + '|' + str(covers)  + '|' + str(entrys)  + '|' + str(blentrys)  + ')'
						write_log('looking for ' + str(title) + ' on themoviedb movie', addlog.value)
						search = tmdb.Search()
						if jahr != '':
							res = search.movie(query=title, language='de', year=jahr)
						else:
							res = search.movie(query=title, language='de')
						if res:
							if res['results']:
								reslist = []
								for item in res['results']:
									reslist.append(item['title'].lower())
								bestmatch = get_close_matches(title.lower(), reslist, 1, 0.7)
								if not bestmatch:
									bestmatch = [title.lower()]
								for item in res['results']:
									if item['title'].lower() == bestmatch[0]:
										foundAsMovie = True
										write_log('found ' + str(bestmatch[0]) + ' for ' + str(title.lower()) + ' on themoviedb movie', addlog.value)
										if item['original_title']:
											org_name = item['original_title']
										if item['poster_path'] and loadImages:
											if item['poster_path'].endswith('.jpg'):
												titleinfo['poster_url'] = 'http://image.tmdb.org/t/p/original' +  item['poster_path']
										if item['backdrop_path'] and loadImages:
											if item['backdrop_path'].endswith('.jpg'):
												titleinfo['backdrop_url'] = 'http://image.tmdb.org/t/p/original' +  item['backdrop_path']
										if 'release_date' in item:
											titleinfo['year'] = item['release_date'][:4]
										if item['genre_ids']:
											for genre in item['genre_ids']:
												if not tmdb_genres[genre] in titleinfo['genre']:
													titleinfo['genre'] = titleinfo['genre'] + tmdb_genres[genre] + ' '
										if 'vote_average' in item and item['vote_average'] != "0":
											titleinfo['rating'] = str(item['vote_average'])
										if 'id' in item:
											details = tmdb.Movies(item['id'])
											for country in details.releases(language='de')['countries']:
												if str(country['iso_3166_1']) == "DE":
													titleinfo['fsk'] = str(country['certification'])
													break
											for country in details.info(language='de')['production_countries']:
												titleinfo['country'] = titleinfo['country'] + country['iso_3166_1'] + " | "
											titleinfo['country'] = titleinfo['country'][:-3]
											imdb_id = details.info(language='de')['imdb_id']
											if not titleinfo['poster_url'].startswith('http') or not titleinfo['backdrop_url'].startswith('http') and loadImages:
												try:
													if not titleinfo['backdrop_url'].startswith('http'):
														showimgs = details.images(language='de')['backdrops']
														if showimgs:
															titleinfo['backdrop_url'] = 'http://image.tmdb.org/t/p/original' +  showimgs[0]['file_path']
												except Exception as ex:
													pass
												try:
													if not titleinfo['poster_url'].startswith('http'):
														showimgs = details.images(language='de')['posters']
														if showimgs:
															titleinfo['poster_url'] = 'http://image.tmdb.org/t/p/original' +  showimgs[0]['file_path']
												except Exception as ex:
													pass
										break
					except Exception as ex:
						write_log('Fehler in get_titleInfo themoviedb movie : ' + str(ex))

		#			write_log('################################################### themoviedb tv ##############################################')
					try:
						if not foundAsMovie:
							STATUS = str(position) + '/' + str(len(titles)) + ' : themoviedb tv -' + str(title)  + '  (' + str(posters)  + '|' + str(covers)  + '|' + str(entrys)  + '|' + str(blentrys)  + ')'
							write_log('looking for ' + str(title) + ' on themoviedb tv', addlog.value)
							search = tmdb.Search()
							searchName = findEpisode(title)
							if searchName: 
								if jahr != '':
									res = search.tv(query=searchName[2], language='de', year=jahr, include_adult=True, search_type='ngram')
								else:
									res = search.tv(query=searchName[2], language='de', include_adult=True, search_type='ngram')
							else:
								if jahr != '':
									res = search.tv(query=title, language='de', year=jahr) 
								else:
									res = search.tv(query=title, language='de') 
							if res:
								if res['results']:
									reslist = []
									for item in res['results']:
										reslist.append(item['name'].lower())
									if searchName:
										bestmatch = get_close_matches(searchName[2].lower(), reslist, 1, 0.7)
										if not bestmatch:
											bestmatch = [searchName[2].lower()]
									else:
										bestmatch = get_close_matches(title.lower(), reslist, 1, 0.7)
										if not bestmatch:
											bestmatch = [title.lower()]
									for item in res['results']:
										if item['name'].lower() == bestmatch[0]:
											write_log('found ' + str(bestmatch[0]) + ' for ' + str(title.lower()) + ' on themoviedb tv', addlog.value)
											if searchName:
												try:
													details = tmdb.TV_Episodes(item['id'],searchName[0],searchName[1])
													if details:
														epi = details.info(language='de')
														#imgs = details.images(language='de')
														if 'air_date' in epi:
															titleinfo['year'] = epi['air_date'][:4]
														if 'vote_average' in epi:
															titleinfo['rating'] = epi['vote_average']
														if epi['still_path'] and loadImages:
															if epi['still_path'].endswith('.jpg'):
																titleinfo['backdrop_url'] = 'http://image.tmdb.org/t/p/original' +  epi['still_path']
														if item['origin_country']:
															for country in item['origin_country']:
																titleinfo['country'] = titleinfo['country'] + country + ' | '
															titleinfo['country'] = titleinfo['country'][:-3]
														if item['genre_ids']:
															for genre in item['genre_ids']:
																if not tmdb_genres[genre] in titleinfo['genre']:
																	titleinfo['genre'] = titleinfo['genre'] + tmdb_genres[genre] + '-Serie '
												except:
													pass
											else:
												if item['original_name']:
													org_name = item['original_name']
												if item['origin_country']:
													for country in item['origin_country']:
														titleinfo['country'] = titleinfo['country'] + country + ' | '
													titleinfo['country'] = titleinfo['country'][:-3]
												if item['poster_path'] and loadImages:
													if item['poster_path'].endswith('.jpg'):
														titleinfo['poster_url'] = 'http://image.tmdb.org/t/p/original' +  item['poster_path']
												if item['backdrop_path'] and loadImages:
													if item['backdrop_path'].endswith('.jpg'):
														titleinfo['backdrop_url'] = 'http://image.tmdb.org/t/p/original' +  item['backdrop_path']
												if 'first_air_date' in item:
													titleinfo['year'] = item['first_air_date'][:4]
												if item['genre_ids']:
													for genre in item['genre_ids']:
														if not tmdb_genres[genre] in titleinfo['genre']:
															titleinfo['genre'] = titleinfo['genre'] + tmdb_genres[genre] + '-Serie '
												if 'vote_average' in item and item['vote_average'] != "0":
													titleinfo['rating'] = str(item['vote_average'])
												if 'id' in item:
													details = tmdb.TV(item['id'])
													for country in details.content_ratings(language='de')['results']:
														if str(country['iso_3166_1']) == "DE":
															titleinfo['fsk'] = str(country['rating'])
															break
													if not titleinfo['poster_url'].startswith('http') or not titleinfo['backdrop_url'].startswith('http') and loadImages:
														try:
															if not titleinfo['backdrop_url'].startswith('http'):
																showimgs = details.images(language='de')['backdrops']
																if showimgs:
																	titleinfo['backdrop_url'] = 'http://image.tmdb.org/t/p/original' +  showimgs[0]['file_path']
														except Exception as ex:
															pass
														try:
															if not titleinfo['poster_url'].startswith('http'):
																showimgs = details.images(language='de')['posters']
																if showimgs:
																	titleinfo['poster_url'] = 'http://image.tmdb.org/t/p/original' +  showimgs[0]['file_path']
														except Exception as ex:
															pass
											break
					except Exception as ex:
						write_log('Fehler in get_titleInfo themoviedb tv : ' + str(ex))

		#			write_log('################################################### thetvdb ##############################################')
					if not foundAsMovie:
						if titleinfo['genre'] == "" or titleinfo['year'] == "" or titleinfo['country'] == "" or titleinfo['rating'] == "" or titleinfo['fsk'] == "" or titleinfo['poster_url'] == "" or titleinfo['backdrop_url'] == "":
							STATUS = str(position) + '/' + str(len(titles)) + ' : thetvdb -' + str(title)  + '  (' + str(posters)  + '|' + str(covers)  + '|' + str(entrys)  + '|' + str(blentrys)  + ')'
							write_log('looking for ' + str(title) + ' on thetvdb', addlog.value)
							seriesid = None
							search = tvdb.Search()
							searchTitle = convertTitle2(title)
							try:
								try:
									response = search.series(searchTitle, language="de")
									if response:
										reslist = []
										for result in response:
											reslist.append(result['seriesName'].lower())
										bestmatch = get_close_matches(searchTitle.lower(), reslist, 1, 0.7)
										if not bestmatch:
											bestmatch = [searchTitle.lower()]
										for result in response:
											if result['seriesName'].lower() == bestmatch[0]:
												write_log('found ' + str(bestmatch[0]) + ' for ' + str(title.lower()) + ' on thetvdb', addlog.value)
												seriesid = result['id']
												break
								except Exception as ex:
									try:
										response = search.series(searchTitle)
										if response:
											reslist = []
											for result in response:
												reslist.append(result['seriesName'].lower())
											bestmatch = get_close_matches(searchTitle.lower(), reslist, 1, 0.7)
											if not bestmatch:
												bestmatch = [searchTitle.lower()]
											for result in response:
												if result['seriesName'].lower() == bestmatch[0]:
													write_log('found ' + str(bestmatch[0]) + ' for ' + str(title.lower()) + ' on thetvdb', addlog.value)
													seriesid = result['id']
													break
									except Exception as ex:
										pass

								if seriesid:
									foundEpisode = False
									show = tvdb.Series(seriesid)
									response = show.info()
									epis = tvdb.Series_Episodes(seriesid)
									episoden = None
									try:
										episoden = epis.all()
									except:
										pass
									epilist = []
									if episoden:
										if episoden != 'None':
											for episode in episoden:
												epilist.append(str(episode['episodeName']).lower())
											bestmatch = get_close_matches(title.lower(), epilist, 1, 0.7)
											if not bestmatch:
												bestmatch = [title.lower()]
											for episode in episoden:
												try:
													if str(episode['episodeName']).lower() == str(bestmatch[0]):
														foundEpisode = True
														if 'firstAired' in episode and episode['firstAired'] != None:
															titleinfo['year'] = episode['firstAired'][:4]
														if 'siteRating' in episode:
															if episode['siteRating'] != '0' and episode['siteRating'] != 'None':
																titleinfo['rating'] = episode['siteRating']
														if 'contentRating' in episode:
															if "TV-MA" in str(episode['contentRating']):
																titleinfo['fsk'] = "18"
															elif "TV-PG" in str(episode['contentRating']):
																titleinfo['fsk'] = "16"
															elif "TV-14" in str(episode['contentRating']):
																titleinfo['fsk'] = "12"
															elif "TV-Y7" in str(episode['contentRating']):
																titleinfo['fsk'] = "6"
														if 'filename' in episode and loadImages:
															if str(episode['filename']).endswith('.jpg') and not titleinfo['backdrop_url'].startswith('http'):
																titleinfo['backdrop_url'] = 'https://www.thetvdb.com/banners/' + episode['filename']
														if 'imdbId' in episode and episode['imdbId'] != None:
															imdb_id = episode['imdbId']
														if response:
															if titleinfo['genre'] == "" and 'genre' in response:
																if response['genre'] and str(response['genre']) != 'None':
																	for genre in response['genre']:
																		titleinfo['genre'] = titleinfo['genre'] + genre + '-Serie '
															titleinfo['genre'] = titleinfo['genre'].replace("Documentary", "Dokumentation").replace("Children", "Kinder")
															if titleinfo['country'] == "" and response['network'] != None:
																if response['network'] in networks:
																	titleinfo['country'] = networks[response['network']]
															if response['poster'] and loadImages:
																if str(response['poster']).endswith('.jpg') and not titleinfo['poster_url'].startswith('http'):
																	titleinfo['poster_url'] = 'https://www.thetvdb.com/banners/' + response['poster']
														break
												except:
													write_log('Fehler in get_titleInfo thetvdb Episoden : ' + str(ex) + ' ' + str(episode))
													continue

									if response and not foundEpisode:
										if titleinfo['year'] == "":
											titleinfo['year'] = response['firstAired'][:4]
										if titleinfo['genre'] == "":
											if response['genre']:
												for genre in response['genre']:
													titleinfo['genre'] = titleinfo['genre'] + genre + '-Serie '
										titleinfo['genre'] = titleinfo['genre'].replace("Documentary", "Dokumentation").replace("Children", "Kinder")
										if titleinfo['country'] == "":
											if response['network'] in networks:
												titleinfo['country'] = networks[response['network']]
										imdb_id = response['imdbId']
										if titleinfo['rating'] == "" and response['siteRating'] != "0":
											titleinfo['rating'] = response['siteRating']
										if titleinfo['fsk'] == "":
											if "TV-MA" in str(response['rating']):
												titleinfo['fsk'] = "18"
											elif "TV-PG" in str(response['rating']):
												titleinfo['fsk'] = "16"
											elif "TV-14" in str(response['rating']):
												titleinfo['fsk'] = "12"
											elif "TV-Y7" in str(response['rating']):
												titleinfo['fsk'] = "6"
										if response['poster'] and loadImages:
											if response['poster'].endswith('.jpg') and not titleinfo['poster_url'].startswith('http'):
												titleinfo['poster_url'] = 'https://www.thetvdb.com/banners/' + response['poster']
										if response['fanart'] and loadImages:
											if response['fanart'].endswith('.jpg') and not titleinfo['backdrop_url'].startswith('http'):
												titleinfo['backdrop_url'] = 'https://www.thetvdb.com/banners/' + response['fanart']
										if not titleinfo['poster_url'].startswith('http') or not titleinfo['backdrop_url'].startswith('http') and loadImages:
											showimgs = tvdb.Series_Images(seriesid)
											try:
												if not titleinfo['backdrop_url'].startswith('http'):
													try:
														response = showimgs.fanart(language=lang)
													except:
														response = showimgs.fanart()
													if response and str(response) != 'None':
														titleinfo['backdrop_url'] = 'https://www.thetvdb.com/banners/' + response[0]['fileName']
											except Exception as ex:
												pass
											try:
												if not titleinfo['poster_url'].startswith('http'):
													try:
														response = showimgs.poster(language=lang)
													except:
														response = showimgs.poster()
													if response and str(response) != 'None':
														titleinfo['poster_url'] = 'https://www.thetvdb.com/banners/' + response[0]['fileName']
											except Exception as ex:
												pass
							except Exception as ex:
								write_log('Fehler in get_titleInfo thetvdb : ' + str(ex) + ' ' + str(title))


		#			write_log('################################################### maze.tv ##############################################')
					if not foundAsMovie:
						if titleinfo['genre'] == "" or titleinfo['country'] == "" or titleinfo['year'] == "" or titleinfo['rating'] == "" or titleinfo['poster_url'] == "":
							STATUS = str(position) + '/' + str(len(titles)) + ' : maze.tv -' + str(title)  + '  (' + str(posters)  + '|' + str(covers)  + '|' + str(entrys)  + '|' + str(blentrys)  + ')'
							write_log('looking for ' + str(title) + ' on maze.tv', addlog.value)
							try:
								if org_name:
									url = "http://api.tvmaze.com/search/shows?q=%s" % (org_name)
								else:
									url = "http://api.tvmaze.com/search/shows?q=%s" % (title)
								r = requests.get(url, timeout=5)
								if r.status_code == 200:
									res = json.loads(r.content)
									if res:
										reslist = []
										for item in res:
											reslist.append(item['show']['name'].lower())
										bestmatch = get_close_matches(title.lower(), reslist, 1, 0.7)
										if not bestmatch:
											bestmatch = [title.lower()]
										for item in res:
											if item['show']['name'].lower() == bestmatch[0]:
												if item['show']['network']['country'] and titleinfo['country'] == "":
													titleinfo['country'] = item['show']['network']['country']['code']
												if item['show']['premiered'] and titleinfo['year'] == "":
													titleinfo['year'] = item['show']['premiered'][:4]
												if item['show']['genres'] and titleinfo['genre'] == "":
													for genre in item['show']['genres']:
														if not genre in titleinfo['genre']:
															titleinfo['genre'] = titleinfo['genre'] + genre + '-Serie '
													titleinfo['genre'] = titleinfo['genre'].replace("Documentary", "Dokumentation").replace("Children", "Kinder")
												if item['show']['image'] and not titleinfo['poster_url'].startswith('http') and loadImages:
													titleinfo['poster_url'] = item['show']['image']['original']
												if item['show']['rating']['average'] and titleinfo['rating'] == "":
													titleinfo['rating'] = item['show']['rating']['average']
												if item['show']['externals']['imdb'] and not imdb_id:
													imdb_id = item['show']['externals']['imdb']
												break
							except Exception as ex:
								write_log('Fehler in get_titleInfo maze.tv : ' + str(ex))

		#			write_log('################################################### omdb ##############################################')
					if titleinfo['genre'] == "" or titleinfo['year'] == "" or titleinfo['rating'] == "" or titleinfo['fsk'] == "" or titleinfo['poster_url'] == "":
						try:
							STATUS = str(position) + '/' + str(len(titles)) + ' : omdb -' + str(title)  + '  (' + str(posters)  + '|' + str(covers)  + '|' + str(entrys)  + '|' + str(blentrys)  + ')'
							write_log('looking for ' + str(title) + ' on omdb', addlog.value)
							if imdb_id:
								url = "http://www.omdbapi.com/?apikey=%s&i=%s" % (get_keys('omdb'), imdb_id)
							else:
								if org_name:
									url = "http://www.omdbapi.com/?apikey=%s&s=%s&page=1" % (get_keys('omdb'), org_name)
								else:
									url = "http://www.omdbapi.com/?apikey=%s&s=%s&page=1" % (get_keys('omdb'), title)
								r = requests.get(url, timeout=5)
								url = "http://www.omdbapi.com/?apikey=%s&t=%s" % (get_keys('omdb'), title)
								if r.status_code == 200:
									res = json.loads(r.content)
									if res['Response'] == "True":
										reslist = []
										for result in res['Search']:
											reslist.append(result['Title'].lower())
										bestmatch = get_close_matches(title.lower(), reslist, 1, 0.7)
										if not bestmatch:
											bestmatch = [title.lower()]
										for result in res['Search']:
											if result['Title'].lower() == bestmatch[0]:
												url = "http://www.omdbapi.com/?apikey=%s&i=%s" % (get_keys('omdb'), result['imdbID'])
												break

							r = requests.get(url, timeout=5)
							if r.status_code == 200:
								res = json.loads(r.content)
								if res['Response'] == "True":
									if res['Year'] and titleinfo['year'] == "":
										titleinfo['year'] = res['Year'][:4]
									if res['Genre'] != "N/A" and titleinfo['genre'] == "":
										type = ' '
										if res['Type']:
											if res['Type'] == 'series':
												type = '-Serie'
										genres = res['Genre'].split(', ')
										for genre in genres:
											if not genre in titleinfo['genre']:
												titleinfo['genre'] = titleinfo['genre'] + genre + type
										titleinfo['genre'] = titleinfo['genre'].replace("Documentary", "Dokumentation").replace("Children", "Kinder")
									if res['Poster'].startswith('http') and not titleinfo['poster_url'].startswith('http') and loadImages:
										titleinfo['poster_url'] = res['Poster']
										omdb_image = True
									if res['imdbRating'] != "N/A" and titleinfo['rating'] == "":
										titleinfo['rating'] = res['imdbRating']
									if res['Country'] != "N/A" and titleinfo['country'] == "":
										rescountries = res['Country'].split(', ')
										countries = ""
										for country in rescountries:
											countries = countries + country + ' | '
										titleinfo['country'] = countries[:-2].replace('West Germany','DE').replace('East Germany','DE').replace('Germany','DE').replace('France','FR').replace('Canada','CA').replace('Austria','AT').replace('Switzerland','S').replace('Belgium','B').replace('Spain','ESP').replace('Poland','PL').replace('Russia','RU').replace('Czech Republic','CZ').replace('Netherlands','NL').replace('Italy','IT')
									if res['imdbID'] != "N/A" and not imdb_id:
										imdb_id = res['imdbID']
									if titleinfo['fsk'] == "" and res['Rated'] != "N/A":
										if "R" in str(res['Rated']):
											titleinfo['fsk'] = "18"
										elif "TV-MA" in str(res['Rated']):
											titleinfo['fsk'] = "18"
										elif "TV-PG" in str(res['Rated']):
											titleinfo['fsk'] = "16"
										elif "TV-14" in str(res['Rated']):
											titleinfo['fsk'] = "12"
										elif "TV-Y7" in str(res['Rated']):
											titleinfo['fsk'] = "6"
										elif "PG-13" in str(res['Rated']):
											titleinfo['fsk'] = "12"
										elif "PG" in str(res['Rated']):
											titleinfo['fsk'] = "6"
										elif "G" in str(res['Rated']):
											titleinfo['fsk'] = "16"
						except Exception as ex:
							write_log('Fehler in get_titleInfo omdb : ' + str(ex))

					if imdb_id and titleinfo['fsk'] == "":
						try:
							STATUS = str(position) + '/' + str(len(titles)) + ' : altersfreigaben.de -' + str(title)  + '  (' + str(posters)  + '|' + str(covers)  + '|' + str(entrys)  + '|' + str(blentrys)  + ')'
							write_log('looking for fsk on altersfreigaben.de', addlog.value)
							url = "https://altersfreigaben.de/api2/s/%s/de" % (imdb_id)
							r = requests.get(url, timeout=4)
							if r.status_code == 200:
								if r.content not in ['100', '300', '310']:
									titleinfo['fsk'] = r.content
									write_log("found FSK " + str(titleinfo['fsk']) + " for " + str(title) + " on altersfreigaben.de", addlog.value)
						except Exception as ex:
							write_log('Fehler in get_titleInfo altersfreigaben.de : ' + str(ex), addlog.value)

					filename = convert2base64(title)
					if filename and filename != '' and filename != ' ':
						if titleinfo['genre'] == "" and titleinfo['year'] == "" and titleinfo['rating'] == "" and titleinfo['fsk'] == "" and titleinfo['country'] == "" and titleinfo['poster_url'] == "" and titleinfo['backdrop_url'] == "":
							blentrys += 1
							db.addblackList(filename)
							write_log('nothing found for : ' + str(titleinfo['title']), addlog.value)

						if titleinfo['genre'] != "" or titleinfo['year'] != "" or titleinfo['rating'] != "" or titleinfo['fsk'] != "" or titleinfo['country'] != "":
							entrys += 1
							if research:
								if db.checkTitle(research):
									db.updateTitleInfo(titleinfo['title'],titleinfo['genre'],titleinfo['year'],titleinfo['rating'],titleinfo['fsk'],titleinfo['country'],research)
								else:
									db.addTitleInfo(filename,titleinfo['title'],titleinfo['genre'],titleinfo['year'],titleinfo['rating'],titleinfo['fsk'],titleinfo['country'])
							else:
								db.addTitleInfo(filename,titleinfo['title'],titleinfo['genre'],titleinfo['year'],titleinfo['rating'],titleinfo['fsk'],titleinfo['country'])
							write_log('found data for : ' + str(titleinfo['title']), addlog.value)
						if titleinfo['poster_url'] and loadImages:
							if titleinfo['poster_url'].startswith('http'):
								posters += 1
								if research:
									downloadImage(titleinfo['poster_url'], os.path.join(posterDir, research +'.jpg'))
								else:
									downloadImage(titleinfo['poster_url'], os.path.join(posterDir, filename +'.jpg'))
								if omdb_image:
									img = Image.open(os.path.join(posterDir, filename +'.jpg'))
									w, h = img.size
									if w > h:
										shutil.move(os.path.join(posterDir, filename +'.jpg'), os.path.join(coverDir, filename +'.jpg'))
									img = None
						if titleinfo['backdrop_url'] and loadImages:
							if titleinfo['backdrop_url'].startswith('http'):
								covers += 1
								if research:
									downloadImage(titleinfo['backdrop_url'], os.path.join(coverDir, research +'.jpg'))
								else:
									downloadImage(titleinfo['backdrop_url'], os.path.join(coverDir, filename +'.jpg'))
					db.parameter(PARAMETER_SET, 'laststop', str(time()))
			except Exception as ex:
				write_log("Fehler in get_titleInfo for : " + str(title) + ' infos = ' + str(titleinfo) + ' : ' + str(ex))
				continue
		write_log("set " + str(entrys) + " on eventInfo")
		write_log("set " + str(blentrys) + " on Blacklist")
		if loadImages:
			write_log("found " + str(posters) + " posters")
			write_log("found " + str(covers) + " covers")
		STATUS = 'entferne alte Extradaten...'
		db.cleanliveTV(int(time() - 28800))
		if len(liveTVRecords) > 0:
			db.addliveTV(liveTVRecords)
			getTVMovie(db)
			db.updateliveTVProgress()
		write_log("create thumbnails for cover")
		createThumbnails(coverDir)
		write_log("create thumbnails for poster")
		createThumbnails(posterDir)
		write_log("reduce large image-size")
		reduceImageSize(coverDir, db)
		reduceImageSize(posterDir, db)
		write_log("looking for missing meta-Info")
		createMovieInfo(db)
		createStatistics(db)
		db.parameter(PARAMETER_SET, 'laststop', str(time()))
		write_log("Update done")
		STATUS = None
		if research:
			return True
	else:
		STATUS = None
		if research:
			return False

def get_size(path):
	total_size = 0
	for dirpath, dirnames, filenames in os.walk(path):
		for f in filenames:
			fp = os.path.join(dirpath, f)
			total_size += os.path.getsize(fp)
	return str(round(float(total_size / 1024.0 / 1024.0),1)) + 'M'

def createStatistics(db):
	try:
		DIR = getPictureDir() + 'poster/'
		posterCount = len([name for name in os.listdir(DIR) if os.path.isfile(os.path.join(DIR, name))])
		try:
			posterSize = subprocess.check_output(['du','-sh', DIR]).split()[0].decode('utf-8')
		except subprocess.CalledProcessError as e:
			write_log("Fehler in createStatistics getposterSize : " + str(e.returncode))
			posterSize = get_size(DIR)

		DIR = getPictureDir() + 'cover/'
		coverCount = len([name for name in os.listdir(DIR) if os.path.isfile(os.path.join(DIR, name))])
		try:
			coverSize = subprocess.check_output(['du','-sh', DIR]).split()[0].decode('utf-8')
		except subprocess.CalledProcessError as e:
			write_log("Fehler in createStatistics getcoverSize : " + str(e.returncode))
			coverSize = get_size(DIR)

		db.parameter(PARAMETER_SET, 'posterCount', str(posterCount))
		db.parameter(PARAMETER_SET, 'coverCount', str(coverCount))
		db.parameter(PARAMETER_SET, 'posterSize', str(posterSize))
		db.parameter(PARAMETER_SET, 'coverSize', str(coverSize))
	except Exception as ex:
		write_log('createStatistics : ' + str(ex))

def get_PictureList(title, what='Cover', count=20, b64title=None, lang='de'):
	if isconnected() == 0 and isInstalled:
		if coverquality.value != "w1920":
			cq = str(coverquality.value)
		else:
			cq = 'original'
		posterDir = getPictureDir()+'poster/'
		coverDir = getPictureDir()+'cover/'
		tvdb.KEYS.API_KEY = get_keys('tvdb')
		tmdb.API_KEY = get_keys('tmdb')
		pictureList = []
		try:
			titleNyear = convertYearInTitle(title)
			title = convertSearchName(titleNyear[0])
			jahr = str(titleNyear[1])
			write_log('searching ' + str(what) + ' for ' + str(title) + ' with language = ' + str(lang))
			if not b64title:
				b64title = convert2base64(title)

#			write_log('################################################### AEL-Image-Server ##############################################')
			if useAELIS.value:
				try:
					if what == 'Poster':
						aelTitle = convert2base64(title)
						aelurl='http://ael.timobayl.de/index.php/s/476Wk32A8QSsXd7/download?path=%2F&files=' + str(aelTitle) + '.jpg'
						if checkAELImageServer(aelurl):
							downloadImagefromAELImageServer(aelurl, '/tmp/' + convert2base64('AELDefaultPoster') + '.jpg')
							itm = [title, what, ' gefunden auf AEL-Image-Server', aelurl, os.path.join(posterDir, aelTitle +'.jpg'), convert2base64('AELDefaultPoster') + '.jpg']
							pictureList.append((itm,))

						if aelTitle != convert2base64(convertTitle(title)):
							aelTitle = convert2base64(convertTitle(title))
							aelurl='http://ael.timobayl.de/index.php/s/476Wk32A8QSsXd7/download?path=%2F&files=' + str(aelTitle) + '.jpg'
							if checkAELImageServer(aelurl):
								downloadImagefromAELImageServer(aelurl, '/tmp/' + convert2base64('AELDefaultPoster') + '.jpg')
								itm = [convertTitle(title), what, ' gefunden auf AEL-Image-Server', aelurl, os.path.join(posterDir, aelTitle +'.jpg'), convert2base64('AELDefaultPoster') + '.jpg']
								pictureList.append((itm,))

						if aelTitle != convert2base64(convertTitle2(title)):
							aelTitle = convert2base64(convertTitle2(title))
							aelurl='http://ael.timobayl.de/index.php/s/476Wk32A8QSsXd7/download?path=%2F&files=' + str(aelTitle) + '.jpg'
							if checkAELImageServer(aelurl):
								downloadImagefromAELImageServer(aelurl, '/tmp/' + convert2base64('AELDefaultPoster') + '.jpg')
								itm = [convertTitle2(title), what, ' gefunden auf AEL-Image-Server', aelurl, os.path.join(posterDir, aelTitle +'.jpg'), convert2base64('AELDefaultPoster') + '.jpg']
								pictureList.append((itm,))

					if what == 'Cover':
						aelTitle = convert2base64(title)
						aelurl='http://ael.timobayl.de/index.php/s/J6y2cbB38HDQp33/download?path=%2F&files=' + str(aelTitle) + '.jpg'
						if checkAELImageServer(aelurl):
							downloadImagefromAELImageServer(aelurl, '/tmp/' + convert2base64('AELDefaultCover') + '.jpg')
							itm = [title, what, ' gefunden auf AEL-Image-Server', aelurl, os.path.join(coverDir, aelTitle +'.jpg'), convert2base64('AELDefaultCover') + '.jpg']
							pictureList.append((itm,))

						if aelTitle != convert2base64(convertTitle(title)):
							aelTitle = convert2base64(convertTitle(title))
							aelurl='http://ael.timobayl.de/index.php/s/J6y2cbB38HDQp33/download?path=%2F&files=' + str(aelTitle) + '.jpg'
							if checkAELImageServer(aelurl):
								downloadImagefromAELImageServer(aelurl, '/tmp/' + convert2base64('AELDefaultCover') + '.jpg')
								itm = [convertTitle(title), what, ' gefunden auf AEL-Image-Server', aelurl, os.path.join(coverDir, aelTitle +'.jpg'), convert2base64('AELDefaultCover') + '.jpg']
								pictureList.append((itm,))

						if aelTitle != convert2base64(convertTitle2(title)):
							aelTitle = convert2base64(convertTitle2(title))
							aelurl='http://ael.timobayl.de/index.php/s/J6y2cbB38HDQp33/download?path=%2F&files=' + str(aelTitle) + '.jpg'
							if checkAELImageServer(aelurl):
								downloadImagefromAELImageServer(aelurl, '/tmp/' + convert2base64('AELDefaultCover') + '.jpg')
								itm = [convertTitle2(title), what, ' gefunden auf AEL-Image-Server', aelurl, os.path.join(coverDir, aelTitle +'.jpg'), convert2base64('AELDefaultCover') + '.jpg']
								pictureList.append((itm,))
				except Exception as ex:
					write_log('Fehler in get_PictureList AEL-Image-Server : ' + str(ex))

#			write_log('################################################### themoviedb tv ##############################################')
			try:
				search = tmdb.Search()
				searchName = findEpisode(title)
				if searchName: 
					if jahr != '':
						res = search.tv(query=searchName[2], language=str(lang), year=jahr, include_adult=True, search_type='ngram')
					else:
						res = search.tv(query=searchName[2], language=str(lang), include_adult=True, search_type='ngram')
				else:
					if jahr != '':
						res = search.tv(query=title, language=str(lang), year=jahr) 
					else:
						res = search.tv(query=title, language=str(lang)) 
				if res:
					if res['results']:
						reslist = []
						for item in res['results']:
							reslist.append(item['name'].lower())
						if searchName:
							bestmatch = get_close_matches(searchName[2].lower(), reslist, 4, 0.7)
							if not bestmatch:
								bestmatch = [searchName[2].lower()]
						else:
							bestmatch = get_close_matches(title.lower(), reslist, 4, 0.7)
							if not bestmatch:
								bestmatch = [title.lower()]
						for item in res['results']:
							write_log('found on TMDb TV ' + str(item['name']))
							if item['name'].lower() in bestmatch:
								if 'id' in item:
									idx = tmdb.TV(item['id'])
									if searchName and what == 'Cover':
										try:
											details = tmdb.TV_Episodes(item['id'],searchName[0],searchName[1])
											if details:
												epi = details.info(language=str(lang))
												if epi:
													imgs = details.images(language=str(lang))
													if imgs:
														if 'stills' in imgs:
															for img in imgs['stills']:
																	imgsize = str(img['width']) + 'x' + str(img['height'])
																	itm = [item['name'] + ' - ' + epi['name'], what, str(imgsize) + ' gefunden auf TMDb TV', 'http://image.tmdb.org/t/p/' + cq + img['file_path'], os.path.join(coverDir, b64title +'.jpg'), convert2base64(img['file_path']) +'.jpg']
																	pictureList.append((itm,))
										except:
											pass
									try:
										if what == 'Cover' and not searchName:
											imgs = idx.images(language=str(lang))['backdrops']
											if imgs:
												for img in imgs:
													imgsize = str(img['width']) + 'x' + str(img['height'])
													itm = [item['name'], what, str(imgsize) + ' gefunden auf TMDb TV', 'http://image.tmdb.org/t/p/' + cq + img['file_path'], os.path.join(coverDir, b64title +'.jpg'), convert2base64(img['file_path']) +'.jpg']
													pictureList.append((itm,))
											if len(imgs) < 2:
												imgs = idx.images()['backdrops']
												if imgs:
													for img in imgs:
														imgsize = str(img['width']) + 'x' + str(img['height'])
														itm = [item['name'], what, str(imgsize) + ' gefunden auf TMDb TV', 'http://image.tmdb.org/t/p/' + cq + img['file_path'], os.path.join(coverDir, b64title +'.jpg'), convert2base64(img['file_path']) +'.jpg']
														pictureList.append((itm,))
									except:
										pass
									try:
										if what == 'Poster':
											imgs = idx.images(language=str(lang))['posters']
											if imgs:
												for img in imgs:
													imgsize = str(img['width']) + 'x' + str(img['height'])
													itm = [item['name'], what, str(imgsize) + ' gefunden auf TMDb TV', 'http://image.tmdb.org/t/p/' + str(posterquality.value) + img['file_path'], os.path.join(posterDir, b64title +'.jpg'), convert2base64(img['file_path']) +'.jpg']
													pictureList.append((itm,))
											if len(imgs) < 2:
												imgs = idx.images()['posters']
												if imgs:
													for img in imgs:
														imgsize = str(img['width']) + 'x' + str(img['height'])
														itm = [item['name'], what, str(imgsize) + ' gefunden auf TMDb TV', 'http://image.tmdb.org/t/p/' + str(posterquality.value) + img['file_path'], os.path.join(posterDir, b64title +'.jpg'), convert2base64(img['file_path']) +'.jpg']
														pictureList.append((itm,))
									except:
										pass
			except:
				pass

#			write_log('################################################### themoviedb movie ##############################################')
			try:
				search = tmdb.Search()
				if jahr != '':
					res = search.movie(query=title, language=str(lang), year=jahr)
				else:
					res = search.movie(query=title, language=str(lang))
				if res:
					if res['results']:
						reslist = []
						for item in res['results']:
							reslist.append(item['title'].lower())
						bestmatch = get_close_matches(title.lower(), reslist, 4, 0.7)
						if not bestmatch:
							bestmatch = [title.lower()]
						for item in res['results']:
							write_log('found on TMDb Movie ' + str(item['title']))
							if item['title'].lower() in bestmatch:
								if 'id' in item:
									idx = tmdb.Movies(item['id'])
									try:
										if what == 'Cover':
											imgs = idx.images(language=str(lang))['backdrops']
											if imgs:
												for img in imgs:
													imgsize = str(img['width']) + 'x' + str(img['height'])
													itm = [item['title'], what, str(imgsize) + ' gefunden auf TMDb Movie', 'http://image.tmdb.org/t/p/' + cq + img['file_path'], os.path.join(coverDir, b64title +'.jpg'), convert2base64(img['file_path']) +'.jpg']
													pictureList.append((itm,))
											if len(imgs) < 2:
												imgs = idx.images()['backdrops']
												if imgs:
													for img in imgs:
														imgsize = str(img['width']) + 'x' + str(img['height'])
														itm = [item['title'], what, str(imgsize) + ' gefunden auf TMDb Movie', 'http://image.tmdb.org/t/p/' + cq + img['file_path'], os.path.join(coverDir, b64title +'.jpg'), convert2base64(img['file_path']) +'.jpg']
														pictureList.append((itm,))
									except:
										pass
									try:
										if what == 'Poster':
											imgs = idx.images(language=str(lang))['posters']
											if imgs:
												for img in imgs:
													imgsize = str(img['width']) + 'x' + str(img['height'])
													itm = [item['title'], what, str(imgsize) + ' gefunden auf TMDb Movie', 'http://image.tmdb.org/t/p/' + str(posterquality.value) + img['file_path'], os.path.join(posterDir, b64title +'.jpg'), convert2base64(img['file_path']) +'.jpg']
													pictureList.append((itm,))
											if len(imgs) < 2:
												imgs = idx.images()['posters']
												if imgs:
													for img in imgs:
														imgsize = str(img['width']) + 'x' + str(img['height'])
														itm = [item['title'], what, str(imgsize) + ' gefunden auf TMDb Movie', 'http://image.tmdb.org/t/p/' + str(posterquality.value) + img['file_path'], os.path.join(posterDir, b64title +'.jpg'), convert2base64(img['file_path']) +'.jpg']
														pictureList.append((itm,))
									except:
										pass
			except:
				pass

#			write_log('################################################### thetvdb ##############################################')
			seriesid = None
			search = tvdb.Search()
			searchTitle = convertTitle2(title)
			try:
				try:
					response = search.series(searchTitle, language=str(lang)) 
					if response:
						reslist = []
						for result in response:
							reslist.append(result['seriesName'].lower())
						bestmatch = get_close_matches(searchTitle.lower(), reslist, 1, 0.7)
						if not bestmatch:
							bestmatch = [searchTitle.lower()]
						for result in response:
							if bestmatch[0] in result['seriesName'].lower() or result['seriesName'].lower() in bestmatch[0]:
								seriesid = result['id']
								break
				except Exception as ex:
					try:
						response = search.series(searchTitle)
						if response:
							reslist = []
							for result in response:
								reslist.append(result['seriesName'].lower())
							bestmatch = get_close_matches(searchTitle.lower(), reslist, 1, 0.7)
							if not bestmatch:
								bestmatch = [searchTitle.lower()]
							for result in response:
								if bestmatch[0] in result['seriesName'].lower() or result['seriesName'].lower() in bestmatch[0]:
									seriesid = result['id']
									break
					except:
						pass

				if seriesid:
					epis = tvdb.Series_Episodes(seriesid)
					episoden = None
					try:
						episoden = epis.all()
					except:
						pass
					epiname = ''
					epilist = []
					if episoden:
						if episoden != 'None':
							for episode in episoden:
								epilist.append(episode['episodeName'].lower())
							bestmatch = get_close_matches(title.lower(), epilist, 1, 0.7)
							if not bestmatch:
								bestmatch = [title.lower()]
							for episode in episoden:
								if episode['episodeName'].lower() in bestmatch[0]:
									if 'seriesId' in episode:
										seriesid = episode['seriesId']
										epiname = ' - ' + str(episode['episodeName'])
									break
					showimgs = tvdb.Series_Images(seriesid)
					if showimgs:
						try:
							if what == 'Cover':
								try:
									response = showimgs.fanart(language=str(lang))
								except:
									response = showimgs.fanart()
								if response and str(response) != 'None':
									for img in response:
										itm = [result['seriesName'] + epiname, what, str(img['resolution']) + ' gefunden auf TVDb', 'https://www.thetvdb.com/banners/' + img['fileName'], os.path.join(coverDir, b64title +'.jpg'), convert2base64(img['fileName']) +'.jpg']
										pictureList.append((itm,))
						except Exception as ex:
							write_log('Fehler in get Cover : ' + str(ex))
						try:
							if what == 'Poster':
								try:
									response = showimgs.poster(language=str(lang))
								except:
									response = showimgs.poster()
								if response and str(response) != 'None':
									for img in response:
										itm = [result['seriesName'] + epiname, what, str(img['resolution']) + ' gefunden auf TVDb', 'https://www.thetvdb.com/banners/' + img['fileName'], os.path.join(posterDir, b64title +'.jpg'), convert2base64(img['fileName']) +'.jpg']
										pictureList.append((itm,))
						except Exception as ex:
							write_log('Fehler in get Poster : ' + str(ex))
			except Exception as ex:
				write_log('Fehler in get tvdb images : ' + str(ex))

			if not pictureList and what == 'Poster':
				try:
					url = "http://www.omdbapi.com/?apikey=%s&t=%s" % (get_keys('omdb'), title)
					r = requests.get(url, timeout=5)
					if r.status_code == 200:
						res = json.loads(r.content)
						if res['Response'] == "True":
							if res['Poster'].startswith('http'):
								itm = [res['Title'], what, 'OMDB', res['Poster'], os.path.join(posterDir, b64title +'.jpg'), convert2base64('omdbPosterFile') + '.jpg']
								pictureList.append((itm,))

					url = "http://api.tvmaze.com/search/shows?q=%s" % (title)
					r = requests.get(url, timeout=5)
					if r.status_code == 200:
						res = json.loads(r.content)
						if res:
							reslist = []
							for item in res:
								reslist.append(item['show']['name'].lower())
							bestmatch = get_close_matches(title.lower(), reslist, 4, 0.7)
							if not bestmatch:
								bestmatch = [title.lower()]
							for item in res:
								if item['show']['name'].lower() == bestmatch[0]:
									if item['show']['image']:
										itm = [item['show']['name'], what, 'maze.tv', item['show']['image']['original'], os.path.join(posterDir, b64title +'.jpg'), convert2base64('mazetvPosterFile') + '.jpg']
										pictureList.append((itm,))
				except:
					pass

			if pictureList:
				idx = 0
				write_log('found ' + str(len(pictureList)) + ' images for ' + str(title), addlog.value)
				while idx <= int(count) and idx < len(pictureList):
					write_log('Image : ' + str(pictureList[idx]), addlog.value)
					downloadImage(pictureList[idx][0][3], os.path.join('/tmp/', pictureList[idx][0][5]))
					idx += 1
				return pictureList[:count]
			else:
				itm = ["Keine Ergebnisse gefunden", "Bildname '" + str(b64title) + ".jpg'", None, None, None, None]
				pictureList.append((itm,))
				return pictureList
		except Exception as ex:
			write_log('get_PictureList : ' + str(ex))
			return []

def get_searchResults(title, lang='de'):
	if isconnected() == 0 and isInstalled:
		tvdb.KEYS.API_KEY = get_keys('tvdb')
		tmdb.API_KEY = get_keys('tmdb')
		resultList = []
		try:
			titleNyear = convertYearInTitle(title)
			title = convertSearchName(titleNyear[0])
			jahr = str(titleNyear[1])
			write_log('searching results for ' + str(title) + ' with language = ' + str(lang))
			try:
				searchName = findEpisode(title)
				search = tmdb.Search()
				if searchName: 
					if jahr != '':
						res = search.tv(query=searchName[2], language=lang, year=jahr, include_adult=True, search_type='ngram')
					else:
						res = search.tv(query=searchName[2], language=lang, include_adult=True, search_type='ngram')
				else:
					if jahr != '':
						res = search.tv(query=title, language=lang, year=jahr) 
					else:
						res = search.tv(query=title, language=lang) 
				if res:
					if res['results']:
						reslist = []
						for item in res['results']:
							reslist.append(item['name'].lower())
						if searchName:
							bestmatch = get_close_matches(searchName[2].lower(), reslist, 10, 0.4)
							if not bestmatch:
								bestmatch = [searchName[2].lower()]
						else:
							bestmatch = get_close_matches(title.lower(), reslist, 10, 0.4)
							if not bestmatch:
								bestmatch = [title.lower()]
						for item in res['results']:
							if item['name'].lower() in bestmatch:
								countries = ""
								year = ""
								genres = ""
								rating = ""
								fsk = ""
								desc = ""
								epiname = ''
								if searchName:
									try:
										details = tmdb.TV_Episodes(item['id'],searchName[0],searchName[1])
										if details:
											epi = details.info(language=lang)
											if 'name' in epi:
												epiname = ' - S' + searchName[0] + 'E' + searchName[1] + ' - ' + epi['name']
											if 'air_date' in epi:
												year = epi['air_date'][:4]
											if 'vote_average' in epi:
												rating = epi['vote_average']
											if 'overview' in epi:
												desc = epi['overview']
											if item['origin_country']:
												for country in item['origin_country']:
													countries = countries + country + ' | '
												countries = countries[:-3]
											if item['genre_ids']:
												for genre in item['genre_ids']:
													genres = genres + tmdb_genres[genre] + '-Serie '
												maxGenres = genres.split()
												if maxGenres:
													if len(maxGenres) >= 1:
														genres = maxGenres[0]
											if 'id' in item:
												details = tmdb.TV(item['id'])
												for country in details.content_ratings(language='de')['results']:
													if str(country['iso_3166_1']) == "DE":
														fsk = str(country['rating'])
														break
									except:
										pass
								else:
									if 'overview' in item:
										desc = item['overview']
									if item['origin_country']:
										for country in item['origin_country']:
											countries = countries + country + ' | '
										countries = countries[:-3]
									if 'first_air_date' in item:
										year = item['first_air_date'][:4]
									if item['genre_ids']:
										for genre in item['genre_ids']:
											genres = genres + tmdb_genres[genre] + '-Serie '
									if 'vote_average' in item and item['vote_average'] != "0":
										rating = str(item['vote_average'])
									if 'id' in item:
										details = tmdb.TV(item['id'])
										for country in details.content_ratings(language='de')['results']:
											if str(country['iso_3166_1']) == "DE":
												fsk = str(country['rating'])
												break
								itm = [str(item['name'])+epiname, str(countries), str(year), str(genres), str(rating), str(fsk), "TMDb TV", desc]
								resultList.append((itm,))
			except:
				pass

			try:
				search = tmdb.Search()
				if jahr != '':
					res = search.movie(query=title, language=lang, year=jahr)
				else:
					res = search.movie(query=title, language=lang)
				if res:
					if res['results']:
						reslist = []
						for item in res['results']:
							reslist.append(item['title'].lower())
						bestmatch = get_close_matches(title.lower(), reslist, 10, 0.4)
						if not bestmatch:
							bestmatch = [title.lower()]
						for item in res['results']:
							if item['title'].lower() in bestmatch:
								countries = ""
								year = ""
								genres = ""
								rating = ""
								fsk = ""
								desc = ""
								if 'overview' in item:
									desc = item['overview']
								if 'release_date' in item:
									year = item['release_date'][:4]
								if item['genre_ids']:
									for genre in item['genre_ids']:
										genres = genres + tmdb_genres[genre] + ' '
								if 'vote_average' in item and item['vote_average'] != "0":
									rating = str(item['vote_average'])
								if 'id' in item:
									details = tmdb.Movies(item['id'])
									for country in details.releases(language='de')['countries']:
										if str(country['iso_3166_1']) == "DE":
											fsk = str(country['certification'])
											break
									for country in details.info(language='de')['production_countries']:
										countries = countries + country['iso_3166_1'] + " | "
									countries = countries[:-3]
								itm = [str(item['title']), str(countries), str(year), str(genres), str(rating), str(fsk), "TMDb Movie", desc]
								resultList.append((itm,))
			except:
				pass

			search = tvdb.Search()
			searchTitle = convertTitle2(title)
			searchName = findEpisode(title)
			try:
				try:
					response = search.series(searchTitle, language=lang)
					if response:
						reslist = []
						for result in response:
							reslist.append(result['seriesName'].lower())
						bestmatch = get_close_matches(title.lower(), reslist, 10, 0.4)
						if not bestmatch:
							bestmatch = [title.lower()]
						for result in response:
							if result['seriesName'].lower() in bestmatch:
								foundEpisode = False
								seriesid = None
								countries = ""
								year = ""
								genres = ""
								rating = ""
								fsk = ""
								desc = ""
								epiname = ""
								seriesid = result['id']
								if seriesid:
									foundEpisode = False
									show = tvdb.Series(seriesid)
									response = show.info()
									epis = tvdb.Series_Episodes(seriesid)
									episoden = None
									try:
										episoden = epis.all()
									except:
										pass
									epilist = []
									if episoden:
										if episoden != 'None':
											for episode in episoden:
												epilist.append(episode['episodeName'].lower())
											bestmatch = get_close_matches(title.lower(), epilist, 1, 0.6)
											if not bestmatch:
												bestmatch = [title.lower()]
											for episode in episoden:
												try:
													if episode['episodeName'].lower() == bestmatch[0]:
														foundEpisode = True
														if 'episodeName' in episode:
															if searchName:
																epiname = ' - S' + searchName[0] + 'E' + searchName[1] + ' - ' + episode['episodeName']
															else:
																epiname = ' - ' + episode['episodeName']
														if 'overview' in episode:
															desc = episode['overview']
														if 'firstAired' in episode:
															year = episode['firstAired'][:4]
														if 'siteRating' in episode:
															if episode['siteRating'] != '0' and episode['siteRating'] != 'None':
																rating = episode['siteRating']
														if 'contentRating' in episode:
															if "TV-MA" in str(episode['contentRating']):
																fsk = "18"
															elif "TV-PG" in str(episode['contentRating']):
																fsk = "16"
															elif "TV-14" in str(episode['contentRating']):
																fsk = "12"
															elif "TV-Y7" in str(episode['contentRating']):
																fsk = "6"
														if response:
															if 'genre' in response:
																if response['genre']:
																	for genre in response['genre']:
																		genres = genres + genre + '-Serie '
															genres = genres.replace("Documentary", "Dokumentation").replace("Children", "Kinder")
															if response['network'] in networks:
																countries = networks[response['network']]
														itm = [str(result['seriesName']+epiname), str(countries), str(year), str(genres), str(rating), str(fsk), "The TVDB", desc]
														resultList.append((itm,))
														break
												except Exception as ex:
													continue

									if response and not foundEpisode:
										if 'overview' in response:
											desc = response['overview']
										if response['network'] in networks:
											countries = networks[response['network']]
										year = response['firstAired'][:4]
										for genre in response['genre']:
											genres = genres + genre + '-Serie '
										genres = genres.replace("Documentary", "Dokumentation").replace("Children", "Kinder")
										if response['siteRating'] != "0":
											rating = response['siteRating']
										if "TV-MA" in str(response['rating']):
											fsk = "18"
										elif "TV-PG" in str(response['rating']):
											fsk = "16"
										elif "TV-14" in str(response['rating']):
											fsk = "12"
										elif "TV-Y7" in str(response['rating']):
											fsk = "6"
										itm = [str(result['seriesName']), str(countries), str(year), str(genres), str(rating), str(fsk), "The TVDB", desc]
										resultList.append((itm,))
				except Exception as ex:
					try:
						response = search.series(title) 
						if response:
							reslist = []
							for result in response:
								reslist.append(result['seriesName'].lower())
							bestmatch = get_close_matches(title.lower(), reslist, 10, 0.4)
							if not bestmatch:
								bestmatch = [title.lower()]
							for result in response:
								if result['seriesName'].lower() in bestmatch:
									seriesid = None
									countries = ""
									year = ""
									genres = ""
									rating = ""
									fsk = ""
									desc = ""
									seriesid = result['id']
									if seriesid:
										show = tvdb.Series(seriesid)
										response = show.info()
										if response:
											if 'overview' in response:
												desc = response['overview']
											if response['network'] in networks:
												countries = networks[response['network']]
											year = response['firstAired'][:4]
											for genre in response['genre']:
												genres = genres + genre + '-Serie '
											genres = genres.replace("Documentary", "Dokumentation").replace("Children", "Kinder")
											if response['siteRating'] != "0":
												rating = response['siteRating']
											if "TV-MA" in str(response['rating']):
												fsk = "18"
											elif "TV-PG" in str(response['rating']):
												fsk = "16"
											elif "TV-14" in str(response['rating']):
												fsk = "12"
											elif "TV-Y7" in str(response['rating']):
												fsk = "6"
											itm = [str(result['seriesName']), str(countries), str(year), str(genres), str(rating), str(fsk), "The TVDB", desc]
											resultList.append((itm,))
					except:
						pass
			except:
				pass

			try:
				url = "http://api.tvmaze.com/search/shows?q=%s" % (title)
				r = requests.get(url, timeout=5)
				if r.status_code == 200:
					res = json.loads(r.content)
					reslist = []
					for item in res:
						reslist.append(item['show']['name'].lower())
					bestmatch = get_close_matches(title.lower(), reslist, 10, 0.4)
					if not bestmatch:
						bestmatch = [title.lower()]
					for item in res:
						if item['show']['name'].lower() in bestmatch:
							countries = ""
							year = ""
							genres = ""
							rating = ""
							fsk = ""
							desc = ""
							if item['show']['summary']:
								desc = item['show']['summary']
							if item['show']['network']['country']:
								countries = item['show']['network']['country']['code']
							if item['show']['premiered']:
								year = item['show']['premiered'][:4]
							if item['show']['genres']:
								for genre in item['show']['genres']:
									genres = genres + genre + '-Serie '
								genres = genres.replace("Documentary", "Dokumentation").replace("Children", "Kinder")
							if item['show']['rating']['average'] and str(item['show']['rating']['average']) != None:
								rating = item['show']['rating']['average']
							itm = [str(item['show']['name']), str(countries), str(year), str(genres), str(rating), str(fsk), "maze.tv", desc]
							resultList.append((itm,))
			except: 
				pass

			try:
				url = "http://www.omdbapi.com/?apikey=%s&s=%s&page=1" % (get_keys('omdb'), title)
				r = requests.get(url, timeout=5)
				if r.status_code == 200:
					res = json.loads(r.content)
					if res['Response'] == "True":
						reslist = []
						for result in res['Search']:
							reslist.append(result['Title'].lower())
						bestmatch = get_close_matches(title.lower(), reslist, 10, 0.4)
						if not bestmatch:
							bestmatch = [title.lower()]
						for result in res['Search']:
							if result['Title'].lower() in bestmatch:
								url = "http://www.omdbapi.com/?apikey=%s&i=%s" % (get_keys('omdb'), result['imdbID'])
								r = requests.get(url, timeout=5)
								if r.status_code == 200:
									countries = ""
									year = ""
									genres = ""
									rating = ""
									fsk = ""
									desc = ""
									res = json.loads(r.content)
									if res['Response'] == "True":
										if res['Plot']:
											desc = res['Plot']
										if res['Year']:
											year = res['Year'][:4]
										if res['Genre'] != "N/A":
											type = ' '
											if res['Type']:
												if res['Type'] == 'series':
													type = '-Serie '
											resgenres = res['Genre'].split(', ')
											for genre in resgenres:
												genres = genres + genre + type
											genres = genres.replace("Documentary", "Dokumentation").replace("Children", "Kinder")
										if res['imdbRating'] != "N/A":
											rating = res['imdbRating']
										if res['Country'] != "N/A":
											rescountries = res['Country'].split(', ')
											for country in rescountries:
												countries = countries + country + ' | '
											countries = countries[:-2].replace('West Germany','DE').replace('East Germany','DE').replace('Germany','DE').replace('France','FR').replace('Canada','CA').replace('Austria','AT').replace('Switzerland','S').replace('Belgium','B').replace('Spain','ESP').replace('Poland','PL').replace('Russia','RU').replace('Czech Republic','CZ').replace('Netherlands','NL').replace('Italy','IT')
										if res['Rated'] != "N/A":
											if "R" in str(res['Rated']):
												fsk = "18"
											elif "TV-MA" in str(res['Rated']):
												fsk = "18"
											elif "TV-PG" in str(res['Rated']):
												fsk = "16"
											elif "TV-14" in str(res['Rated']):
												fsk = "12"
											elif "TV-Y7" in str(res['Rated']):
												fsk = "6"
											elif "PG-13" in str(res['Rated']):
												fsk = "12"
											elif "PG" in str(res['Rated']):
												fsk = "6"
											elif "G" in str(res['Rated']):
												fsk = "16"
										itm = [str(res['Title']), str(countries), str(year), str(genres), str(rating), str(fsk), "omdb", desc]
										resultList.append((itm,))
			except Exception as ex:
				write_log('get_searchResults omdb: ' + str(ex))

			write_log('search results : ' + str(resultList))
			if resultList:
				return(sorted(resultList, key = lambda x: x[0]))
			else:
				itm = ["Keine Ergebnisse gefunden", None, None, None, None, None, None, None]
				resultList.append((itm,))
				return resultList
		except Exception as ex:
			write_log('get_searchResults : ' + str(ex))
			return []

def downloadTVMovieImage(tvMovieImage, imgname):
	try:
		if not os.path.isfile(imgname):
			imgurl = 'http://images.tvmovie.de/' + str(coverqualityDict[coverquality.value]) + '/Center/' + tvMovieImage
			ir = requests.get(imgurl, stream=True, timeout=4)
			if ir.status_code == 200:
				with open(imgname, 'wb') as f:
					ir.raw.decode_content = True
					shutil.copyfileobj(ir.raw, f)
				return True
			else:
				return False
		else:
			return True
	except Exception as ex:
		write_log("Fehler beim laden des Previewbildes : " + str(ex))
		return False

def getImageFile(path, eventName):
	name = eventName
	pictureName = convert2base64(name) + '.jpg'
	imageFileName = os.path.join(path, pictureName)
	if (os.path.exists(imageFileName)):
		return imageFileName
	else:
		name = convertTitle(eventName)
		pictureName = convert2base64(name) + '.jpg'
		imageFileName = os.path.join(path, pictureName)
		if (os.path.exists(imageFileName)):
			return imageFileName
		else:
			name = convertTitle2(eventName)
			pictureName = convert2base64(name) + '.jpg'
			imageFileName = os.path.join(path, pictureName)
			if (os.path.exists(imageFileName)):
				return imageFileName
	return None

############################################### EPGShare ##########################################################
def isEPGShare():
	if os.path.exists('/usr/lib/enigma2/python/Plugins/Extensions/EpgShare/main.so'):
		return True
	return False

def getEpgShareImagePath():
	try:
		if os.path.exists('/usr/lib/enigma2/python/Plugins/Extensions/EpgShare/main.so'):
			return str(config.plugins.epgShare.autocachelocation.value)
		else:
			return str(dir)[:-1]
	except:
		return str(dir)[:-1]

def getEpgShareDefaultImage(title):
	try:
		EpgShareImagePath = getEpgShareImagePath()
		if EpgShareImagePath:
			path = '%s/Default/' % (EpgShareImagePath)
			title = title.decode('utf-8').lower().split('(')[0].strip() + '.jpg'
			imageFileName = '%s%s' % (path, base64.b64encode(title))
			if (os.path.isfile(imageFileName)):
				return imageFileName
		return None
	except Exception as ex:
		write_log("getEpgShareDefaultImage :" + str(ex))
		return None

def getEpgShareEventImage(timestamp, eventId):
	try:
		EpgShareImagePath = getEpgShareImagePath()
		if EpgShareImagePath:
			path = os.path.join(EpgShareImagePath, str(strftime('%D', localtime(int(timestamp)))).replace('/', '.'))
			imageFileName = '%s/%s.jpg' % (path, eventId)
			if (os.path.isfile(imageFileName)):
				return imageFileName

			if os.path.isdir(path):
				files = [i for i in os.listdir(path) if os.path.isfile(os.path.join(path, i)) and i.startswith("%s_" % eventId)]
				if(len(files) > 0):
					imageFileName = '%s/%s' % (path, files[0])
					if (os.path.isfile(imageFileName)):
						return imageFileName
	except Exception as ex:
		write_log("getEpgShareEventImage : " + str(ex))
	return None

def getallEventsfromEPGShare(names=set(), db=None):
	global STATUS
	try:
		data = None
		doIt = False
		if "EPGShareDB" in sPDict:
			if sPDict["EPGShareDB"]:
				doIt = True
		else:
			doIt = True
		if isEPGShare() and doIt:
			STATUS = 'durchsuche EPGShare Datenbank...'
			from Plugins.Extensions.EpgShare.main import getEPGDB
			data = getEPGDB().selectSQL("SELECT DISTINCT title FROM epg_extradata WHERE airtime > " + str(time()))
			if data and len(data) > 0:
				write_log('found ' + str(len(data)) + ' Events in EPGShare Database')
				for titles in data:
					foundInBl = False
					name = convertTitle(titles['title'])
					if db.getblackList(convert2base64(name)):
						name = convertTitle2(titles['title'])
						if db.getblackList(convert2base64(name)):
							foundInBl = True
					if not db.checkTitle(convert2base64(name)) and not foundInBl:
						names.add(name)
				write_log('found :' + str(len(names)) + ' new Events in EPGShare Database')
				return names
			else:
				write_log('no new events in EPGShare-DB')
				return names
		else:
			write_log('EPGShare is not installed')
			return names
	except Exception as ex:
		write_log("getallEventsfromEPGShare : " + str(ex))
		return names

def getEPGShareExtraData(source):
	if source.event:
		if type(source) == ExtEvent:
			try:
				starttime = source.event.getBeginTime()
				title = source.event.getEventName()
				return json.dumps(getEPGShareDataFromDatabase(str(source.service), str(source.event.getEventId()), starttime, title))
			except Exception as ex:
				write_log("getEPGShareExtraData (ExtEvent) : " + str(ex))
				return ""
		elif str(type(source)) == "<class 'Components.Sources.extEventInfo.extEventInfo'>":
			try:
				if source.service and source.eventid:
					return json.dumps(getEPGShareDataFromDatabase(str(source.service), str(source.eventid)))
				return ""
			except Exception as ex:
				write_log("getEPGShareExtraData (ExtEventInfo) : " + str(ex))
				return ""
		elif hasattr(source, 'service'):
			try:
				service = source.getCurrentService()
				if service:
					servicereference = ServiceReference(service)
					if servicereference:
						return json.dumps(getEPGShareDataFromDatabase(str(servicereference), str(source.event.getEventId())))
				return ""
			except Exception as ex:
				write_log("getEPGShareExtraData (Service) : " + str(ex),addlog.value)
				return ""
		elif type(source) == Event:
			return source.event.getExtraEventData()
	return ""

def getEPGShareDataFromDatabase(service, eventid, beginTime=None, EventName=None):
	try:
		if isEPGShare():
			from Plugins.Extensions.EpgShare.main import getEPGDB
			data = None
			if "::" in str(service):
				service = service.split("::")[0] + ":"
			if "http" in str(service):
				service = service.split("http")[0]

			# Bug Fix, if channel has alternatives
			if str(service).startswith("1:134"):
				service = GetWithAlternative(str(service))

			if not "1:0:0:0:0:0:0:0:0:0:" in service and not "4097:0:0:0:0:0:0:0:0:0:" in service:
				if beginTime and EventName:
					queryPara = "ref: %s, eventId: %s, title:: %s, beginTime: %s" % (str(service), str(eventid), str(EventName.lower()).decode("utf-8"), str(int(beginTime)))
					data = getEPGDB().selectSQL("SELECT * FROM epg_extradata WHERE ref = ? AND (eventid = ? or (LOWER(title) = ? and airtime BETWEEN ? AND ?))",
												[str(service), str(eventid), str(EventName.lower()).decode("utf-8"), str(int(beginTime) - 120), str(int(beginTime) + 120)])
				else:
					queryPara = "ref: %s, eventId: %s" % (str(service), str(eventid))
					data = getEPGDB().selectSQL("SELECT * FROM epg_extradata WHERE ref = ? AND eventid = ?",
												[str(service), str(eventid)])
				if data and len(data) > 0:
					return data[0]
				else:
					return None
			else:
				return None
	except Exception as ex:
		write_log("getEPGShareDataFromDatabase : " + str(ex))
		return None
	return None

########################################### DB Helper Class #######################################################
class DB_Functions(object):
	@staticmethod
	def dict_factory(cursor, row):
		d = {}
		for idx, col in enumerate(cursor.description):
			d[col[0]] = row[idx]
		return d

	def __init__(self, db_file):
		createDirs(dir)
		self.conn = sqlite3.connect(db_file,check_same_thread=False)
		self.create_DB()

	def create_DB(self):
		try:
			cur = self.conn.cursor()
			# create table eventInfo
			query = "SELECT name FROM sqlite_master WHERE type='table' AND name='eventInfo';"
			cur.execute(query)
			if not cur.fetchall():
				query = "CREATE TABLE [eventInfo] ([base64title] TEXT NOT NULL,[title] TEXT NOT NULL,[genre] TEXT NULL,[year] TEXT NULL,[rating] TEXT NULL,[fsk] TEXT NULL,[country] TEXT NULL,[gDate] TEXT NOT NULL,[postercalls] INTEGER DEFAULT 0,[covercalls] INTEGER DEFAULT 0,PRIMARY KEY ([base64title]))"
				cur.execute(query)
				self.conn.commit()
				write_log("Tabelle 'eventInfo' hinzugef�gt")

			# create table blackList
			query = "SELECT name FROM sqlite_master WHERE type='table' AND name='blackList';"
			cur.execute(query)
			if not cur.fetchall():
				query = "CREATE TABLE [blackList] ([base64title] TEXT NOT NULL,PRIMARY KEY ([base64title]))"
				cur.execute(query)
				self.conn.commit()
				write_log("Tabelle 'blackList' hinzugef�gt")

			# create table myliveTV
			query = "SELECT name FROM sqlite_master WHERE type='table' AND name='myliveTV';"
			cur.execute(query)
			if not cur.fetchall():
				query = "CREATE TABLE [myliveTV] (eid INTEGER NOT NULL, id TEXT,subtitle TEXT,image TEXT,year TEXT,fsk TEXT,rating TEXT,title TEXT,airtime INTEGER,leadText TEXT,conclusion TEXT,categoryName TEXT,season TEXT,episode TEXT,genre TEXT,country TEXT,imdb TEXT,sref TEXT, PRIMARY KEY ([eid]))"
				cur.execute(query)
				self.conn.commit()
				write_log("Tabelle 'myliveTV' hinzugef�gt")

			# create table imageBlackList
			query = "SELECT name FROM sqlite_master WHERE type='table' AND name='imageBlackList';"
			cur.execute(query)
			if not cur.fetchall():
				query = "CREATE TABLE [imageBlackList] ([name] TEXT NOT NULL,PRIMARY KEY ([name]))"
				cur.execute(query)
				self.conn.commit()
				write_log("Tabelle 'imageBlackList' hinzugef�gt")

			# delete table liveTV
			query = "SELECT name FROM sqlite_master WHERE type='table' AND name='liveTV';"
			cur.execute(query)
			if cur.fetchall():
				query = "DROP TABLE liveTV"
				cur.execute(query)
				self.conn.commit()

			query = "SELECT name FROM sqlite_master WHERE type='table' AND name='parameters';"
			cur.execute(query)
			if not cur.fetchall():
				query = "CREATE TABLE `parameters` ( `name` TEXT NOT NULL UNIQUE, `value` TEXT, PRIMARY KEY(`name`) )"
				cur.execute(query)
				self.conn.commit()
				write_log("Tabelle 'parameters' hinzugef�gt")

			#append columns eventInfo
			query = "PRAGMA table_info('eventInfo');"
			cur.execute(query)
			rows = cur.fetchall()
			found = False
			for row in rows:
				if "postercalls" in row[1]:
					found = True
					break
			if found == False:
				query ="ALTER TABLE 'eventInfo' ADD COLUMN `postercalls` INTEGER DEFAULT 0"
				cur.execute(query)
				self.conn.commit()
			found = False
			for row in rows:
				if "covercalls" in row[1]:
					found = True
					break
			if found == False:
				query ="ALTER TABLE 'eventInfo' ADD COLUMN `covercalls` INTEGER DEFAULT 0"
				cur.execute(query)
				self.conn.commit()

			#append columns myliveTV
			query = "PRAGMA table_info('myliveTV');"
			cur.execute(query)
			rows = cur.fetchall()
			found = False
			for row in rows:
				if "sref" in row[1]:
					found = True
					break
			if found == False:
				query ="ALTER TABLE 'myliveTV' ADD COLUMN `sref` TEXT DEFAULT ''"
				cur.execute(query)
				self.conn.commit()

		except Error as ex:
			write_log("Fehler in DB Create: " + str(ex))

	def releaseDB(self):
		self.conn.close()

	def execute(self,query,args=()):
		cur = self.conn.cursor()
		cur.execute(query,args)

	def parameter(self,action,name,value=None,default=None):
		cur = self.conn.cursor()
		if action == PARAMETER_GET:
			ret = None
			query = "SELECT value FROM parameters WHERE name = ?"
			cur.execute(query,(name,))
			rows = cur.fetchall()
			if rows:
				if rows[0][0] == "False":
					ret = False
				elif rows[0][0] == "True":
					ret = True
				else:
					ret = rows[0][0]
				return ret
			else:
				return default

		elif action == PARAMETER_SET:
			if value or value == False:
				if value == False:
					val = "False"
				elif value == True:
					val = "True"
				else:
					val = value

				query = "REPLACE INTO parameters (name,value) VALUES (?,?)"
				cur.execute(query,(name,val))
				self.conn.commit()
				return value
			else:
				return None
		else:
			return None

	def addTitleInfo(self, base64title,title,genre,year,rating,fsk,country):
		try:
			now = str(time())
			cur = self.conn.cursor()
			query = "insert or ignore into eventInfo (base64title,title,genre,year,rating,fsk,country,gDate) values (?,?,?,?,?,?,?,?);"
			cur.execute(query,(base64title, str(title).decode('utf8'), str(genre).decode('utf8'), year, rating, fsk, str(country).decode('utf8'),now))
			self.conn.commit()
		except Error as ex:
			write_log("Fehler in addTitleInfo : " + str(ex))

	def addliveTV(self, records):
		try:
			cur = self.conn.cursor()
			cur.executemany('insert or ignore into myliveTV values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);',records)
			write_log("have inserted " + str(cur.rowcount) + " events into myliveTV")
			self.conn.commit()
		except Error as ex:
			write_log("Fehler in addliveTV : " + str(ex))

	def getEPGShareData(self,db):
		try:
			from Plugins.Extensions.EpgShare.main import getEPGDB
			records = []
			data = getEPGDB().selectSQL("SELECT * FROM epg_extradata WHERE airtime > " + str(time()))
			if data and len(data) > 0:
				for titles in data:
					if not db.checkliveTV(titles["eventid"], titles["ref"]):
						image = str(titles["image"]).split('/')[-1]
						fsk = ''
						if not 'Unbekannt' in str(titles["ageRating"]) and not 'None' in str(titles["ageRating"]):
							if 'OhneAlter' in str(titles["ageRating"]):
								fsk = '0'
							elif 'KeineJugend' in str(titles["ageRating"]):
								fsk = '18'
							else:
								fsk = titles["ageRating"]
						record = (titles["eventid"],titles["id"],titles["subtitle"].decode('utf8'),image,titles["year"],fsk.replace('None',''),titles["vote"].replace('None',''),titles["title"].decode('utf8'),titles["airtime"],titles["leadText"].decode('utf8'),titles["conclusion"],titles["categoryName"],titles["season"],titles["episode"],titles["genre"],titles["country"],titles["imdbid"],titles["ref"])
						records.append(record)
			if records:
				cur = self.conn.cursor()
				cur.executemany('insert or ignore into myliveTV values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);',records)
				write_log("have inserted " + str(cur.rowcount) + " events into myliveTV from EPGShare DB")
				self.conn.commit()
		except Error as ex:
			write_log("Fehler in getEPGShareData : " + str(ex))

	def updateTitleInfo(self, title, genre,year,rating,fsk,country,base64title):
		try:
			now = str(time())
			cur = self.conn.cursor()
			query = "update eventInfo set title = ?, genre = ?, year = ?, rating = ?, fsk = ?, country = ?, gDate = "+now+" where base64title = ?;"
			cur.execute(query,(str(title).decode('utf8'), str(genre).decode('utf8'), year, rating, fsk, str(country).decode('utf8'), base64title))
			self.conn.commit()
		except Error as ex:
			write_log("Fehler in updateTitleInfo : " + str(ex))

	def updateliveTV(self, id,subtitle,image,year,fsk,rating,leadText,conclusion,categoryName,season,episode,genre,country, imdb, title, airtime):
		try:
			low = airtime - 360
			high = airtime + 360
			cur = self.conn.cursor()
			query = "update myliveTV set id = ?, subtitle = ?, image = ?, year = ?, fsk = ?, rating = ?, leadText = ?, conclusion = ?, categoryName = ?, season = ?, episode = ?, genre = ?, country = ?, imdb = ? where title = ? AND airtime BETWEEN ? AND ? AND id = 'in progress';"
			cur.execute(query,(id, str(subtitle).decode('utf8'), image, year, fsk, rating, str(leadText).decode('utf8'), str(conclusion).decode('utf8'), str(categoryName).decode('utf8'), season, episode, str(genre).decode('utf8'), country, imdb, str(title).decode('utf8'), low, high))
			self.conn.commit()
			return cur.rowcount
		except Error as ex:
			write_log("Fehler in updateliveTV : " + str(ex))

	def updateliveTVProgress(self):
		try:
			cur = self.conn.cursor()
			query = "update myliveTV set id = '' where id = 'in progress';"
			cur.execute(query)
			write_log("nothing found for " + str(cur.rowcount) + " events in liveTV")
			self.conn.commit()
		except Error as ex:
			write_log("Fehler in updateliveTVProgress : " + str(ex))

	def updatePosterCalls(self, base64title):
		try:
			cur = self.conn.cursor()
			query = "update eventInfo set postercalls = postercalls + 1 where base64title = ?;"
			cur.execute(query,(str(base64title),))
			self.conn.commit()
		except Error as ex:
			write_log("Fehler in updatePosterCalls : " + str(ex) + ' - ' + str(query))

	def updateCoverCalls(self, base64title):
		try:
			cur = self.conn.cursor()
			query = "update eventInfo set covercalls = covercalls + 1 where base64title = ?;"
			cur.execute(query,(str(base64title),))
			self.conn.commit()
		except Error as ex:
			write_log("Fehler in updateCoverCalls : " + str(ex) + ' - ' + str(query))

	def getTitleInfo(self, base64title):
		try:
			cur = self.conn.cursor()
			query = "SELECT base64title,title,genre,year,rating,fsk,country FROM eventInfo WHERE base64title = ?"
			cur.execute(query,(str(base64title),))
			row = cur.fetchall()
			if row:
				return [row[0][0],row[0][1].decode('utf8'),row[0][2].decode('utf8'),row[0][3],row[0][4],row[0][5],row[0][6].decode('utf8')]
			else:
				return []
		except Error as ex:
			write_log("Fehler in getTitleInfo : " + str(ex) + ' - ' + str(base64title))
			return []

	def getliveTV(self, eid, name=None, beginTime=None):
		try:
			cur = self.conn.cursor()
			if name:
				tvname = name.decode('utf8')
				tvname = re.sub('\\(.*?\\)', '', tvname).strip()
				tvname = re.sub(' +', ' ', tvname)
				query = "SELECT * FROM myliveTV WHERE eid = ? AND title = ?"
				cur.execute(query,(eid, tvname))
			else:
				query = "SELECT * FROM myliveTV WHERE eid = ?"
				cur.execute(query,(eid,))
			row = cur.fetchall()
			if row:
				if row[0][1] != "":
					return [row[0]]
				else:
					if name and beginTime:
						query = "SELECT * FROM myliveTV WHERE airtime = ? AND title = ?"
						cur.execute(query,(str(beginTime), tvname))
						row = cur.fetchall()
						if row:
							return [row[0]]
						else:
							return []
			else:
				return []
		except Error as ex:
			write_log("Fehler in getliveTV : " + str(ex) + ' - ' + str(eid) + ' : ' + str(name))
			return []

	def getTitlesforUpdate(self):
		try:
			now = str(int(time()-7200))
			titleList = []
			cur = self.conn.cursor()
			query = "SELECT DISTINCT title FROM myliveTV WHERE id = 'in progress' and airtime > " + now
			cur.execute(query)
			rows = cur.fetchall()
			if rows:
				for row in rows:
					itm = [row[0].decode('utf8')]
					titleList.append(itm)
			return titleList
		except Error as ex:
			write_log("Fehler in getTitlesforUpdate : " + str(ex))
			return []

	def getTitlesforUpdate2(self):
		try:
			now = str(int(time()-7200))
			titleList = []
			cur = self.conn.cursor()
			query = "SELECT DISTINCT title FROM myliveTV WHERE id = 'in progress' and (title like '% - %' or title like '%: %') and airtime > " + now
			cur.execute(query)
			rows = cur.fetchall()
			if rows:
				for row in rows:
					itm = [row[0].decode('utf8')]
					titleList.append(itm)
			return titleList
		except Error as ex:
			write_log("Fehler in getTitlesforUpdate2 : " + str(ex))
			return []

	def getUnusedTitles(self):
		try:
			cur = self.conn.cursor()
			titleList = []
			cur = self.conn.cursor()
			query = "SELECT base64title FROM eventInfo ORDER BY gDate ASC LIMIT 100;"
			cur.execute(query)
			rows = cur.fetchall()
			if rows:
				for row in rows:
					itm = [row[0]]
					titleList.append(itm)
			return titleList
		except Error as ex:
			write_log("Fehler in getUnusedTitles : " + str(ex))
			return []

	def checkTitle(self, base64title):
		try:
			cur = self.conn.cursor()
			query = "SELECT base64title FROM eventInfo where base64title = ?;"
			cur.execute(query,(str(base64title),))
			rows = cur.fetchall()
			if rows:
				return True
			else:
				return False
		except Error as ex:
			write_log("Fehler in checkTitle: " + str(ex))
			return False

	def checkliveTV(self, eid, ref):
		try:
			cur = self.conn.cursor()
			query = "SELECT eid FROM myliveTV where eid = ? AND sref = ?;"
			cur.execute(query,(eid,ref))
			rows = cur.fetchall()
			if rows:
				return True
			else:
				return False
		except Error as ex:
			write_log("Fehler in checkliveTV: " + str(ex))
			return False

	def cleanDB(self, base64title):
		try:
			cur = self.conn.cursor()
			query = "delete from eventInfo where base64title = ?;"
			cur.execute(query,(str(base64title),))
			self.conn.commit()
			query = "delete from blackList where base64title = ?;"
			cur.execute(query,(str(base64title),))
			self.conn.commit()
		except Error as ex:
			write_log("Fehler in cleanDB : " + str(ex))

	def cleanliveTV(self, airtime):
		try:
			cur = self.conn.cursor()
			query = "delete from myliveTV where airtime < ?;"
			cur.execute(query,(str(airtime),))
			write_log("have deleted " + str(cur.rowcount) + " events from myliveTV")
			self.conn.commit()
			self.vacuumDB()
		except Error as ex:
			write_log("Fehler in cleanliveTV : " + str(ex))

	def cleanblackList(self):
		try:
			cur = self.conn.cursor()
			query = "delete from blackList;"
			cur.execute(query)
			self.conn.commit()
			query = "delete from imageBlackList;"
			cur.execute(query)
			self.conn.commit()
			self.vacuumDB()
		except Error as ex:
			write_log("Fehler in cleanblackList : " + str(ex))


	def cleanNadd2BlackList(self, base64title):
		try:
			cur = self.conn.cursor()
			query = "delete from eventInfo where base64title = ?;"
			cur.execute(query,(str(base64title),))
			self.conn.commit()
			query = "insert or ignore into blackList (base64title) values (?);"
			cur.execute(query,(str(base64title),))
			self.conn.commit()
		except Error as ex:
			write_log("Fehler in cleanNadd2BlackList : " + str(ex))

	def addblackList(self, base64title):
		try:
			cur = self.conn.cursor()
			query = "insert or ignore into blackList (base64title) values (?);"
			cur.execute(query,(str(base64title),))
			self.conn.commit()
		except Error as ex:
			write_log("Fehler in addblackList : " + str(ex))

	def addimageBlackList(self, name):
		try:
			cur = self.conn.cursor()
			query = "insert or ignore into imageBlackList (name) values (?);"
			cur.execute(query,(name,))
			self.conn.commit()
		except Error as ex:
			write_log("Fehler in addimageBlackList : " + str(ex))


	def getimageBlackList(self, name):
		try:
			cur = self.conn.cursor()
			query = "SELECT name FROM imageBlackList WHERE name = ?"
			cur.execute(query,(name,))
			row = cur.fetchall()
			if row:
				return True
			else:
				return False
		except Error as ex:
			write_log("Fehler in getimageBlackList : " + str(ex))
			return False

	def getblackList(self, base64title):
		try:
			cur = self.conn.cursor()
			query = "SELECT base64title FROM blackList WHERE base64title = ?"
			cur.execute(query,(str(base64title),))
			row = cur.fetchall()
			if row:
				return True
			else:
				return False
		except Error as ex:
			write_log("Fehler in getblackList : " + str(ex))
			return False

	def getblackListCount(self):
		try:
			cur = self.conn.cursor()
			query = "SELECT COUNT(base64title) FROM blackList"
			cur.execute(query)
			row = cur.fetchall()
			if row:
				return row[0][0]
			else:
				return 0
		except Error as ex:
			write_log("Fehler in getblackListCount : " + str(ex))
			return 0

	def getTitleInfoCount(self):
		try:
			cur = self.conn.cursor()
			query = "SELECT COUNT(base64title) FROM eventInfo"
			cur.execute(query)
			row = cur.fetchall()
			if row:
				return row[0][0]
			else:
				return 0
		except Error as ex:
			write_log("Fehler in getTitleInfoCount : " + str(ex))
			return 0

	def getliveTVCount(self):
		try:
			cur = self.conn.cursor()
			query = "SELECT COUNT(eid) FROM myliveTV"
			cur.execute(query)
			row = cur.fetchall()
			if row:
				return row[0][0]
			else:
				return 0
		except Error as ex:
			write_log("Fehler in getliveTVCount : " + str(ex))
			return 0

	def getliveTVidCount(self):
		try:
			cur = self.conn.cursor()
			query = "SELECT COUNT(id) FROM myliveTV WHERE id <> '' AND id <> 'in progress'"
			cur.execute(query)
			row = cur.fetchall()
			if row:
				return row[0][0]
			else:
				return 0
		except Error as ex:
			write_log("Fehler in getliveTVidCount : " + str(ex))
			return 0

	def getMaxAirtime(self, title):
		try:
			cur = self.conn.cursor()
			query = "SELECT Max(airtime) FROM myliveTV WHERE title = ?"
			cur.execute(query,(str(title).decode('utf8'),))
			row = cur.fetchall()
			if row:
				return row[0][0]
			else:
				return 4000000000
		except Error as ex:
			write_log("Fehler in getMaxAirtime : " + str(ex))
			return 4000000000

	def getSeriesStarts(self):
		try:
			now = time()
			titleList = []
			cur = self.conn.cursor()
			if str(seriesStartType.value) == 'Staffelstart':
				query = "SELECT sref, eid, categoryName FROM myliveTV WHERE sref <> '' AND episode = '1' AND airtime > " + str(now) + " ORDER BY categoryName, airtime"
			else:
				query = "SELECT sref, eid, categoryName FROM myliveTV WHERE sref <> '' AND season = '1' AND episode = '1' AND airtime > " + str(now) + "  ORDER BY categoryName, airtime"
			cur.execute(query)
			rows = cur.fetchall()
			if rows:
				for row in rows:
					itm = [row[0], row[1], row[2]]
					titleList.append(itm)
			return titleList
		except Error as ex:
			write_log("Fehler in getSeriesStarts : " + str(ex))
			return []

	def getSeriesStartsCategories(self):
		try:
			now = time()
			titleList = []
			cur = self.conn.cursor()
			if str(seriesStartType.value) == 'Staffelstart':
				query = "SELECT Distinct categoryName from myliveTV where airtime > " + str(now) + " AND sref <> '' and episode = '1'"
			else:
				query = "SELECT Distinct categoryName from myliveTV where airtime > " + str(now) + " AND sref <> '' and season = '1' and episode = '1'"
			cur.execute(query)
			rows = cur.fetchall()
			if rows:
				for row in rows:
					itm = [row[0].decode('utf8')]
					titleList.append(itm)
			return titleList
		except Error as ex:
			write_log("Fehler in getSeriesStartsCategories : " + str(ex))
			return []

	def vacuumDB(self):
		cur = self.conn.cursor()
		cur.execute("VACUUM")
		self.conn.commit()

########################################### Download Helper Class #######################################################
class HTTPProgressDownloader(client.HTTPDownloader):
	def __init__(self, url, outfile, headers=None):
		client.HTTPDownloader.__init__(self, url, outfile, headers=headers, agent="AEL-Image-Server Downloader")
		self.status = None
		self.progress_callback = None
		self.deferred = defer.Deferred()

	def noPage(self, reason):
		if self.status == "304":
			client.HTTPDownloader.page(self, "")
		else:
			client.HTTPDownloader.noPage(self, reason)

	def gotHeaders(self, headers):
		if self.status == "200":
			if headers.has_key("content-length"):
				self.totalbytes = int(headers["content-length"][0])
			else:
				self.totalbytes = 0
			self.currentbytes = 0.0
		return client.HTTPDownloader.gotHeaders(self, headers)

	def pagePart(self, packet):
		if self.status == "200":
			self.currentbytes += len(packet)
		if self.progress_callback:
			self.progress_callback(self.currentbytes, self.totalbytes)
		return client.HTTPDownloader.pagePart(self, packet)

	def pageEnd(self):
		return client.HTTPDownloader.pageEnd(self)

import urlparse
def url_parse(url, defaultPort=None):
	parsed = urlparse.urlparse(url)
	scheme = parsed[0]
	path = urlparse.urlunparse(('', '') + parsed[2:])
	if defaultPort is None:
		if scheme == 'https':
			defaultPort = 443
		else:
			defaultPort = 80
	host, port = parsed[1], defaultPort
	if ':' in host:
		host, port = host.split(':')
		port = int(port)
	return scheme, host, port, path

class downloadWithProgress:
	def __init__(self, url, outputfile, contextFactory=None, *args, **kwargs):
		scheme, host, port, path = url_parse(url)
		self.factory = HTTPProgressDownloader(url, outputfile, *args, **kwargs)
		if scheme == 'https':
			if contextFactory is None:
				class TLSSNIContextFactory(ssl.ClientContextFactory): 
					def getContext(self, hostname=None, port=None): 
						ctx = ssl.ClientContextFactory.getContext(self) 
						ClientTLSOptions(host, ctx) 
						return ctx
				contextFactory = TLSSNIContextFactory()
				self.connection = reactor.connectSSL(host, port, self.factory, contextFactory)
		else:
			self.connection = reactor.connectTCP(host, port, self.factory)

	def start(self):
		return self.factory.deferred

	def stop(self):
		if hasattr(self, "connection") and self.connection:
			self.connection.disconnect()

	def addProgress(self, progress_callback):
		self.factory.progress_callback = progress_callback

#https://live.tvspielfilm.de/static/broadcast/list/ARD/2020-06-11
#https://live.tvspielfilm.de/static/content/channel-list/livetv