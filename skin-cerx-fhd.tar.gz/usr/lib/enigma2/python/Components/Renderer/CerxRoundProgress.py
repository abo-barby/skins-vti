# License: this is closed source!
# you are not allowed to use this Converter or parts of it outside of CerX Skin
# you are not allowed to use this Converter or parts of it on any other image than VTi
# you are not allowed to use this Converter or parts of it on NON VU Hardware
# Copyright: schomi 2019

import skin
import os
from time import time
from enigma import gFont, eRect, eWidget, eLabel, loadPNG, ePixmap
from PIL import Image, ImageFont, ImageDraw
from Components.VariableValue import VariableValue
from Renderer import Renderer
from skin import parseColor

class CerxRoundProgress(Renderer):				
	def __init__(self):
		Renderer.__init__(self)
		self.__start = 0
		self.__end = 100
		self.range = (0, 100)
		self.value = 0
		self.icon = None
		self.text = None
		self.orientation = None
		self.width = 60
		self.height = 60
		self.thickness = 10
		self.backgroundcolor = '#212121'
		self.progressColor = '#009f3c'
		self.badprogressColor = '#9ca81b'
		self.progressbackgroundColor = '#212121'
		self.badprogress = 40
		self.ptr = None
		self.image = None
		self.text = None
		self.act = ''
		GUI_WIDGET = eWidget
		return

	def GUIcreate(self, parent):
		self.instance = eWidget(parent)
		self.image = ePixmap(self.instance)
		self.text = eLabel(self.instance)
		self.createdoughnut()

	def GUIdelete(self):
		self.image = None
		self.text = None
		self.instance = None
		return

	def applyAllAttributes(self, guiObject, desktop, attributes, scale):
		for attrib, value in attributes:
			try:
				skin.applySingleAttribute(guiObject, desktop, attrib, value, scale)
			except Exception as ex:
				pass

		return True

	def applySkin(self, desktop, parent):
		attribs = []
		textattribs = []
		imageattribs = []
		if self.skinAttributes:
			for attrib, value in self.skinAttributes:
				if attrib == 'size':
					attribs.append((attrib, value))
					imageattribs.append((attrib, value))
					textattribs.append((attrib, value))
					self.width = int(value.split(',')[0])
					self.height = int(value.split(',')[1])
				elif attrib == 'foregroundColor':
					textattribs.append((attrib, value))
				elif attrib == 'backgroundColor':
					attribs.append((attrib, value))
					textattribs.append((attrib, value))
				elif attrib == 'alphatest':
					imageattribs.append((attrib, value))
				elif attrib == 'font':
					textattribs.append((attrib, value))
				elif attrib == 'valign':
					textattribs.append((attrib, value))
				elif attrib == 'halign':
					textattribs.append((attrib, value))
				elif attrib == 'progressColor':
					if value[1:] != '#':
						value = self.NameToHTML(value)
					self.progressColor = self.HTMLColorToRGBA(value)
				elif attrib == 'badprogressColor':
					if value[1:] != '#':
						value = self.NameToHTML(value)
					self.badprogressColor = self.HTMLColorToRGBA(value)
				elif attrib == 'progressbackgroundColor':
					if value[1:] != '#':
						value = self.NameToHTML(value)
					self.progressbackgroundColor = self.HTMLColorToRGBA(value)
				elif attrib == 'badprogress':
					self.badprogress = int(value)
				elif attrib == 'borderthickness':
					self.thickness = int(value)
				elif attrib == 'itemname':
					self.act = str(value)					
				else:
					attribs.append((attrib, value))

			self.skinAttributes = attribs
		
		imageattribs.append(('position', '0,0'))
		textattribs.append(('position', '0,0'))
		textattribs.append(('transparent', '1'))
		self.applyAllAttributes(self.text, desktop, textattribs, parent.scale)
		self.applyAllAttributes(self.image, desktop, imageattribs, parent.scale)
		self.applyAllAttributes(self.instance, desktop, attribs, parent.scale)
		self.createdoughnut()
		return True

	def changed(self, what):
		if what[0] == self.CHANGED_CLEAR:
			self.range, self.value = ((0, 1), 0)
			self.createdoughnut()
			return
		else:
			range = self.source.range or 100
			value = self.source.value
			if value is None:
				value = 0
			self.range, self.value = (0, range), value
			self.createdoughnut()
			return

	def postWidgetCreate(self, instance):
		self.setRange(self.__start, self.__end)
		self.createdoughnut()

	def setRange(self, range):
		self.__start, self.__end = range
		self.createdoughnut()

	def getRange(self):
		return (self.__start, self.__end)

	def createdoughnut(self):
		try:
			self.value = 100-int(float(float(self.value)/float(self.range[1]))*100)
			fillcolour = self.progressColor
			if self.value >= self.badprogress:
				fillcolour = self.badprogressColor				
			filename = '/tmp/dougnut.png'
			im = Image.new('RGBA', (self.width * 2, self.height * 2), (0, 0, 0, 0))
			dr = ImageDraw.Draw(im)
			dr.ellipse((0, 0, self.width * 2,self.height * 2), fill=fillcolour)
			dr.pieslice((0, 0, self.width * 2, self.height * 2), 0, 0 + int(360/100) * self.value, fill=self.progressbackgroundColor)
			dr.ellipse((self.thickness * 2, self.thickness * 2, self.width * 2 - self.thickness * 2,self.height * 2 - self.thickness * 2), fill=(0, 0, 0, 0))
			im.thumbnail((self.width, self.height), Image.ANTIALIAS)
			im.save(filename)
			self.ptr = loadPNG(filename)
			self.image.setPixmap(self.ptr)
		except:
			pass

	def NameToHTML(self, value):
		color = parseColor(value)
		a = str(hex(color.a)[2:-1]).zfill(2)
		r = str(hex(color.r)[2:-1]).zfill(2)
		g = str(hex(color.g)[2:-1]).zfill(2)
		b = str(hex(color.b)[2:-1]).zfill(2)
		return "#" + a+r+g+b


	def HTMLColorToRGBA(self, colorstring):
		colorstring = colorstring.strip()
		if colorstring[0] == '#':
			colorstring = colorstring[1:]
		if len(colorstring) != 8:
			raise ValueError, 'input #%s is not in #AARRGGBB format' % colorstring
		a, r, g, b = (colorstring[:2], colorstring[2:4], colorstring[4:6], colorstring[6:])
		a, r, g, b = [ int(n, 16) for n in (a, r, g, b) ]
		return (r, g, b, 255-a)

	def HTMLColorToPILColor(self, colorstring):
		colorstring = colorstring.strip()
		while colorstring[0] == '#':
			colorstring = colorstring[1:]
		colorstring = colorstring[-2:] + colorstring[2:4] + colorstring[:2]
		color = int(colorstring, 16)
		return color

	range = property(getRange, setRange)
	