# License: this is closed source!
# you are not allowed to use this Converter or parts of it outside of CerX Skin
# you are not allowed to use this Converter or parts of it on any other image than VTi
# you are not allowed to use this Converter or parts of it on NON VU Hardware
# Copyright: schomi 2019

from Components.VariableText import VariableText
from Renderer import Renderer

from enigma import eLabel
import re

class CerxFavName(VariableText, Renderer):
	def __init__(self):
		Renderer.__init__(self)
		VariableText.__init__(self)

	GUI_WIDGET = eLabel

	def connect(self, source):
		Renderer.connect(self, source)
		self.changed((self.CHANGED_DEFAULT,))

	def changed(self, what):
		if what[0] == self.CHANGED_CLEAR:
			self.text = ""
		else:
			self.text = self.source.text.replace("(TV)", "").replace("(Radio)", "").replace(_("User - bouquets"), "").replace("/", " ").replace( _("Channel Selection"), "")
			if self.source.text.find("(TV)") < 0:
				self.text += " (Radio)"
			else:
				self.text += " (TV)"
