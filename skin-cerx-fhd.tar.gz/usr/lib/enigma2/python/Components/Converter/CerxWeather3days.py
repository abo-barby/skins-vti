# License: this is closed source!
# you are not allowed to use this Converter or parts of it outside of CerX Skin
# you are not allowed to use this Converter or parts of it on any other image than VTi
# you are not allowed to use this Converter or parts of it on NON VU Hardware
# Copyright: schomi 2019

from Components.Converter.Converter import Converter
from Components.Element import cached

class CerxWeather3days(Converter, object):
	def __init__(self, type):
		Converter.__init__(self, type)
		self.type = int(type)

	@cached
	def getText(self):
		return str(str(self.source.text)[:self.type] + ".")
		
	text = property(getText)