# License: this is closed source!
# you are not allowed to use this Converter or parts of it outside of CerX Skin
# you are not allowed to use this Converter or parts of it on any other image than VTi
# you are not allowed to use this Converter or parts of it on NON VU Hardware
# Copyright: hmmmmdada 2018, mod by schomi 2019

from Components.Converter.Converter import Converter
from Components.Element import cached
from Components.Sources.Event import  Event
from Components.Sources.ExtEvent import ExtEvent
from Components.Sources.extEventInfo import extEventInfo
from Components.Sources.ServiceEvent import  ServiceEvent
from Tools.MovieInfoParser import getExtendedMovieDescription
from Tools.Alternatives import GetWithAlternative

try:
	EPGDB = True
	from Plugins.Extensions.EpgShare.main import getEPGDB
except:
	EPGDB = False
	print "[Cerx FHD] EPGShare not installed!"

from ServiceReference import ServiceReference
import json

def get_Extradata(service, eventid, beginTime=None, EventName= None):
	try:
		data = None
		if "::" in str(service):
			service = service.split("::")[0] + ":"
		if "http" in str(service):
			service = service.split("http")[0]
		if str(service).startswith("1:134"):
			service = GetWithAlternative(str(service))
		if not "1:0:0:0:0:0:0:0:0:0:" in service and not "4097:0:0:0:0:0:0:0:0:0:" in service:
			if beginTime and EventName and EPGDB:
				data = getEPGDB().selectSQL("SELECT * FROM epg_extradata WHERE ref = ? AND (eventid = ? or (LOWER(title) = ? and airtime BETWEEN ? AND ?))", [str(service), str(eventid),str(EventName.lower()).decode("utf-8"), str(int(beginTime) -120), str(int(beginTime) + 120) ])
			else:
				data = getEPGDB().selectSQL("SELECT * FROM epg_extradata WHERE ref = ? AND eventid = ?", [str(service), str(eventid)])
			if data and len(data) > 0:
				return data[0]
			else:
				return None
		else:
			return None
	except Exception, ex:
		print "DB Error: %s" % str(ex) 
		return None	

class CerxExtEventName(Converter, object):
	EVENT_EXTRADATA = 0

	def __init__(self, type):
		Converter.__init__(self, type)

	@cached
	def getText(self):
		if self.source.event:
			if type(self.source) == ExtEvent:
				try:
					starttime = self.source.event.getBeginTime()
					title = self.source.event.getEventName()
					return json.dumps(get_Extradata(str(self.source.service), str(self.source.event.getEventId()), starttime, title))
				except Exception, ex:
					print "Error1: %s" % str(ex)
					return ""
			elif str(type(self.source)) == "<class 'Components.Sources.extEventInfo.extEventInfo'>":
				try:
					return json.dumps(get_Extradata(str(self.source.service), str(self.source.eventid)))
				except Exception, ex:
					#print "Error2: %s" % str(ex)
					return ""
			elif hasattr(self.source, 'service'):
				try:
					service = self.source.getCurrentService()
					servicereference = ServiceReference(service)
					return json.dumps(get_Extradata(str(servicereference), str(self.source.event.getEventId())))
				except Exception, ex:
					#print "Error3: %s" % str(ex)
					return ""
			elif type(self.source) == Event:
				return self.source.event.getExtraEventData()
			return ""
	text = property(getText)
	
