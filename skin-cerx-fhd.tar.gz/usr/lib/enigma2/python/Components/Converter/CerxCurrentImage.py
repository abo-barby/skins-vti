# License: this is closed source!
# you are not allowed to use this Converter or parts of it outside of CerX Skin
# you are not allowed to use this Converter or parts of it on any other image than VTi
# you are not allowed to use this Converter or parts of it on NON VU Hardware
# Copyright: schomi 2019

from enigma import eEPGCache, eServiceReference
from Components.Converter.Converter import Converter
from Components.Element import cached
from time import localtime, strftime, mktime, time
from Components.config import config

class CerxCurrentImage(Converter, object):

	def __init__(self, type):
		Converter.__init__(self, type)
		self.epgcache = eEPGCache.getInstance()

	@cached
	def getEvent(self):
		actualtime = localtime(time())
		ctime = [actualtime.tm_hour, actualtime.tm_min]
		entry = None
		ref = self.source.service
		info = ref and self.source.info
		if info is None:
			return entry
		else:
			curTimeEvent = self.source.getCurrentEvent()
			if curTimeEvent:
				if not self.epgcache.startTimeQuery(eServiceReference(ref.toString()), curTimeEvent.getBeginTime()):
					event = self.epgcache.getNextTimeEntry()
					entry = event
			return entry

	@cached
	def getService(self):
		ref = self.source.service
		return ref.toString()

	service = property(getService)
	event = property(getEvent)

	def changed(self, changedvalue):
		Converter.changed(self, changedvalue)