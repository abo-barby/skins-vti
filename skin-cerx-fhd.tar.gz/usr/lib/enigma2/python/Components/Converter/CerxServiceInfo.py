# License: this is closed source!
# you are not allowed to use this Converter or parts of it outside of CerX Skin
# you are not allowed to use this Converter or parts of it on any other image than VTi
# you are not allowed to use this Converter or parts of it on NON VU Hardware
# Copyright: hmmmmdada 2018, mod by schomi 2019

from Components.Converter.Converter import Converter
from enigma import iServiceInformation, iPlayableService, eTimer
from Components.Element import cached
from Poll import Poll

frqdic = {'23976': '24',
 '24000': '24',
 '25000': '25',
 '29970': '30',
 '30000': '30',
 '50000': '50',
 '59940': '60',
 '60000': '60'}

class CerxServiceInfo(Poll, Converter, object):
	changer = None
	VIDEO_DETAILS = 0

	def __init__(self, type):
		Poll.__init__(self)
		Converter.__init__(self, type)
		self.type = self.VIDEO_DETAILS
		self.interesting_events = (iPlayableService.evVideoSizeChanged,
		 iPlayableService.evVideoProgressiveChanged,
		 iPlayableService.evVideoFramerateChanged,
		 iPlayableService.evUpdatedInfo)

	def getServiceInfoString(self, info, what, convert = lambda x: '%d' % x):
		v = info.getInfo(what)
		if v == -1:
			return 'N/A'
		if v == -2:
			return info.getInfoString(what)
		return convert(v)

	@cached
	def getText(self):
		service = self.source.service
		info = service and service.info()
		if not info:
			return ''
		yres = self.getServiceInfoString(info, iServiceInformation.sVideoHeight)
		xres = self.getServiceInfoString(info, iServiceInformation.sVideoWidth)
		fr = str(self.getServiceInfoString(info, iServiceInformation.sFrameRate))
		if str(fr) in frqdic:
			frame_rate = frqdic[str(fr)]
		else:
			frame_rate = ''
		progressive = self.getServiceInfoString(info, iServiceInformation.sProgressive)
		#print 'h', yres, 'w', xres, 'fr', frame_rate, 'p', progressive
		try:
			height = 0
			if int(xres) > 1920:
				height = 2160
			elif int(xres) > 1280:
				height = 1080
			elif int(xres) > 1270:
				height = 720
			elif int(yres) > 480:
				height = 576
			else:
				height = 480
			suffix = 'P'
			if str(progressive) == '0':
				suffix = 'i'
				if frame_rate != '':
					frame_rate = 2 * int(frame_rate)
			return '%s\n%s%s' % (str(height), str(frame_rate), suffix)
		except Exception as ex:
			print 'Error: %s' % str(ex)
			return ''

	text = property(getText)

	@cached
	def getValue(self):
		service = self.source.service
		info = service and service.info()
		if not info:
			return -1
		if self.type == self.VIDEO_DETAILS:
			h = self.getServiceInfoString(info, iServiceInformation.sVideoHeight)
			r = self.getServiceInfoString(info, iServiceInformation.sFrameRate)
			p = self.getServiceInfoString(info, iServiceInformation.sProgressive)
			if h < 0 or r < 0 or p < 0:
				return -1
			else:
				return -2
		return -1

	value = property(getValue)

	def changed(self, what):
		if self.poll_enabled:
			self.poll_enabled = False
		if len(what) >= 2 and what[1] == iPlayableService.evEnd:
			self.poll_interval = 3000
			self.poll_enabled = True
		if what[0] != self.CHANGED_SPECIFIC or what[1] in self.interesting_events:
			Converter.changed(self, what)