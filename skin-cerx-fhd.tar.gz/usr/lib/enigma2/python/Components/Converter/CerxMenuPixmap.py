# License: this is closed source!
# you are not allowed to use this Converter or parts of it outside of CerX Skin
# you are not allowed to use this Converter or parts of it on any other image than VTi
# you are not allowed to use this Converter or parts of it on NON VU Hardware
# Copyright: schomi 2019

from Components.Converter.Converter import Converter
from Components.Element import cached, ElementError
from Tools.Directories import fileExists, SCOPE_SKIN_IMAGE, SCOPE_CURRENT_SKIN, resolveFilename
from Tools.LoadPixmap import LoadPixmap

class CerxMenuPixmap(Converter, object):
	def __init__(self, type):
		Converter.__init__(self, type)
		self.type = type

	def selChanged(self):
		self.downstream_elements.changed((self.CHANGED_ALL, 0))	
		
	@cached
	def getPixmap(self):
		if self.source:
			val = self.source.current[2]
			#print "[CerXmenu] ", val
		png = LoadPixmap(cached=True, path=resolveFilename(SCOPE_CURRENT_SKIN, "icons/" + str(val) + ".png"))
		if png == None:
			png = LoadPixmap(cached=True, path=resolveFilename(SCOPE_CURRENT_SKIN, "icons/undefined.png"))
		return png
	
	pixmap = property(getPixmap)

	def changed(self, what):
		if what[0] == self.CHANGED_DEFAULT:
			self.source.onSelectionChanged.append(self.selChanged)
		Converter.changed(self, what)
