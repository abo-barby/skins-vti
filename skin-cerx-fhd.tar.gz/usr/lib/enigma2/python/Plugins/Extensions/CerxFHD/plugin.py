# -*- coding: utf-8 -*-

# License: this is closed source!
# you are not allowed to use this Converter or parts of it outside of CerX Skin
# you are not allowed to use this Converter or parts of it on any other image than VTi
# you are not allowed to use this Converter or parts of it on NON VU Hardware
# Copyright: schomi 2021
# 20211111

from enigma import eTimer
from enigma import loadJPG, loadPNG
from enigma import eServiceCenter
from Components.ActionMap import ActionMap
from Components.config import config, getConfigListEntry, ConfigSubsection, ConfigSelection, ConfigClock, ConfigYesNo, NoSave, ConfigNothing, ConfigNumber
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from Components.MenuList import MenuList
from Components.Pixmap import Pixmap
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
from Plugins.Plugin import PluginDescriptor
from Plugins.SystemPlugins.SkinSelector.plugin import SkinSelector
from Screens.InputBox import InputBox
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.Standby import TryQuitMainloop
from Screens.InfoBar import InfoBar
from ServiceReference import ServiceReference
from Tools.Directories import *
from Tools import *
#from Tools.Directories import SCOPE_CURRENT_SKIN, SCOPE_CURRENT_PLUGIN, SCOPE_PLUGINS, resolveFilename, fileExists
from Tools.LoadPixmap import LoadPixmap
#from Tools.WeatherID import get_woeid_from_yahoo
from Tools import Notifications
from os import listdir, remove, rename, system, path, symlink, chdir, makedirs
import shutil, filecmp
import xml.etree.ElementTree as ET
from Screens.MessageBox import MessageBox
import math

config.plugins.CerxFHD = ConfigSubsection()
config.plugins.CerxFHD.primetime = ConfigClock(default=((19 * 3600) + (15 * 60)))
config.plugins.CerxFHD.endtype = ConfigSelection(default = "1", choices = [("1",_("Standard")),("2",_("Letzter Marker")), ("3",_("Alle Marker"))])
config.plugins.CerxFHD.searchcurbouquet = ConfigYesNo(default = True)

checkPlugins = [("VWeather3","VWeather3"),("VWeather3","Weather"),("VWeather3","Wetter"),("AdvancedEventLibrary","AdvancedEventLibrary"),("AdvancedEventLibrary","AEL")]
pathPlugins = "/usr/lib/enigma2/python/Plugins/Extensions/"

try:
	from Plugins.Extensions.AtileHD.plugin import AtileHD_Config, AtileHDScreens
	print"[CerX FHD] Plugin Atile Import ok"
except:
	print"[CerX FHD] Plugin Atile Import Error"

try:
	from Screens.EventView import *
	from Components.Sources.ExtEvent import ExtEvent
	from Components.Sources.ServiceEvent import ServiceEvent
	print"[CerX FHD] EventView Import ok"
except:
	print"[CerX FHD] EventView Import Error"

try:
	from Screens.VirtualKeyBoard import *
	print"[CerX FHD] VirtualKeyBoard Import ok"
except:
	print"[CerX FHD] VirtualKeyBoard Import Error"
	
try:
	from Plugins.Extensions.GraphMultiEPG.GraphMultiEpg import GraphMultiEPG
	print"[CerX FHD] GMEPG Import ok"
	gmepgInstalled = True
except:
	print"[CerX FHD] GMEPG Import Error"
	gmepgInstalled = False
	
try:
	from Plugins.Extensions.EPGSearch.EPGSearch import EPGSearch
	print"[CerX FHD] EPGSearch Import ok"
	epgsearchInstalled = True
except:
	print"[CerX FHD] EPGSearch Import Error"
	epgsearchInstalled = False

try:
	from Screens.EpgSelection import *
	print"[CerX FHD] EpgSelection Import ok"
	epgselectionInstalled = True
except:
	print"[CerX FHD] EpgSelection Import Error"
	epgselectionInstalled = False
	
try:
	from Screens.LocationBox import *
	print"[CerX FHD] LocationBox Import ok"
except:
	print"[CerX FHD] LocationBox Import Error"

try:
	from Plugins.Extensions.AdvancedEventLibrary import plugin as AELplugin
	from Screens.InfoBar import MoviePlayer
	from Tools.AdvancedEventLibrary import getDB, convertTitle, convert2base64
	print"[CerX FHD] AEL Import ok"
	aelInstalled = True
except:
	print"[CerX FHD] AEL Import Error"
	aelInstalled = False

cur_filter = ""
cur_skin = config.skin.primary_skin.value.replace('/skin.xml', '')
print"[CerX FHD] Current Skin: ", cur_skin

def Plugins(**kwargs):
	return [PluginDescriptor(where = [PluginDescriptor.WHERE_SESSIONSTART, PluginDescriptor.WHERE_AUTOSTART], fnc = autostart)]
		
def autostart(reason, **kwargs):
	print"[CerX FHD]: Modification of Atile HD Plugin ..."

#
# Atile Setup		
#

def getInitConfig_new(self):
	global cur_skin
	self.is_atile = False
	if cur_skin == 'AtileHD':
		self.is_atile = True
	self.title = _("%s - Setup") % cur_skin
	self.skin_base_dir = "/usr/share/enigma2/%s/" % cur_skin
	if self.is_atile:
		self.default_font_file = "font_atile_Roboto.xml"
		self.default_color_file = "colors_atile_Grey_transparent.xml"
	else:
		self.default_font_file = "font_Original.xml"
		self.default_color_file = "colors_Original.xml"
	self.color_file = "skin_user_colors.xml"
	self.font_file = "skin_user_header.xml"
	current_color = self.getCurrentColor()
	color_choices = self.getPossibleColor()
	default_color = ("default", _("Default"))
	if current_color is None:
		current_color = default_color
	if default_color not in color_choices:
		color_choices.append(default_color)
	current_color = current_color[0]
	current_font = self.getCurrentFont() 
	font_choices = self.getPossibleFont()
	default_font = ("default", _("Default"))
	if current_font is None:
		current_font = default_font
	if default_font not in font_choices:
		font_choices.append(default_font)
	current_font = current_font[0]
	myatile_active = self.getmyAtileState()
	self.myAtileHD_active = NoSave(ConfigYesNo(default=myatile_active))
	choices = self.getPossibleFont()
	self.myAtileHD_font = NoSave(ConfigSelection(default=current_font, choices = font_choices))
	self.myAtileHD_style = NoSave(ConfigSelection(default=current_color, choices = color_choices))
	self.myAtileHD_fake_entry = NoSave(ConfigNothing())
	
def createConfigList_new(self):
	self.set_color = getConfigListEntry(_("Style:"), self.myAtileHD_style)
	self.set_font = getConfigListEntry(_("Font:"), self.myAtileHD_font)
	self.set_myatile = getConfigListEntry(_("Enable %s pro:") % cur_skin, self.myAtileHD_active)
	self.set_new_skin = getConfigListEntry(_("Change skin"), ConfigNothing())
	self.find_woeid = getConfigListEntry(_("Search weather location ID"), ConfigNothing())
	self.primetime = getConfigListEntry(_("Prime Time:"), config.plugins.CerxFHD.primetime)
	self.endtype = getConfigListEntry(_("Zeitanzeige Aufnahmen:"), config.plugins.CerxFHD.endtype)
	self.searchcurbouquet = getConfigListEntry(_("Suche nur in aktivem Bouquet:"), config.plugins.CerxFHD.searchcurbouquet)
	self.list = []
	self.list.append(self.set_myatile)
	self.list.append(self.set_color)
	self.list.append(self.set_font)
	self.list.append(self.primetime)
	self.list.append(self.endtype)
	self.list.append(self.searchcurbouquet)
	self.list.append(self.set_new_skin)
	#self.list.append(getConfigListEntry(_("---Weather---"), self.myAtileHD_fake_entry))
	#self.list.append(getConfigListEntry(_("Refresh interval in minutes:"), config.plugins.AtileHD.refreshInterval))
	#self.list.append(getConfigListEntry(_("Temperature unit:"), config.plugins.AtileHD.tempUnit))
	#self.list.append(self.find_woeid)
	#self.list.append(getConfigListEntry(_("Location # (http://weather.yahoo.com/):"), config.plugins.AtileHD.woeid))
	self["config"].list = self.list
	self["config"].l.setList(self.list)
	if self.myAtileHD_active.value:
		self["key_yellow"].setText("%s pro" % cur_skin)
	else:
		self["key_yellow"].setText("")

def init_new(self, session):
	Screen.__init__(self, session)
	self.session = session
	
	global cur_skin
	self.is_atile = False
	if cur_skin == 'AtileHD':
		self.is_atile = True
	
	self.title = _("%s additional screens") % cur_skin
	try:
		self["title"]=StaticText(self.title)
	except:
		vtilog('self["title"] was not found in skin')
	
	self.showfold = True
	
	self["key_red"] = StaticText(_("Exit"))
	self["key_green"] = StaticText(_("on"))
	self["key_yellow"] = StaticText(_("Sort"))
	self["key_blue"] = StaticText(_("Reset"))
	
	self["Picture"] = Pixmap()
	
	menu_list = []
	self["menu"] = List(menu_list)
	
	self["shortcuts"] = ActionMap(["SetupActions", "ColorActions", "DirectionActions"],
	{
		"ok": self.runMenuEntry,
		"cancel": self.keyCancel,
		"red": self.keyCancel,
		"green": self.runMenuEntry,
		"yellow": self.keySort_new,
		"blue": self.keyReset_new,
		}, -2)
	
	self.skin_base_dir = "/usr/share/enigma2/%s/" % cur_skin
	self.screen_dir = "allScreens"
	self.file_dir = "mySkin_off"
	my_path = resolveFilename(SCOPE_SKIN, "%s/icons/input_info.png" % cur_skin)
	if not path.exists(my_path):
		my_path = resolveFilename(SCOPE_SKIN, "skin_default/icons/lock_on.png")
	self.enabled_pic = LoadPixmap(cached = True, path = my_path)
	
	my_path = resolveFilename(SCOPE_SKIN, "%s/icons/input_error.png" % cur_skin)
	if not path.exists(my_path):
		my_path = resolveFilename(SCOPE_SKIN, "skin_default/icons/lock_off.png")
	self.disabled_pic = LoadPixmap(cached = True, path = my_path)

	my_path = resolveFilename(SCOPE_SKIN, "%s/icons/folder_link.png" % cur_skin)
	if not path.exists(my_path):
		my_path = resolveFilename(SCOPE_SKIN, "skin_default/icons/folder_link.png")
		
	self.folder_pic = LoadPixmap(cached = True, path = my_path)
	
	if not self.selectionChanged in self["menu"].onSelectionChanged:
		self["menu"].onSelectionChanged.append(self.selectionChanged)
	
	self.onLayoutFinish.append(self.createMenuList)

def keyReset_new(self):
	print"[CerX FHD] Reset all Skinparts done"
	if path.exists(self.skin_base_dir + "mySkin_off"):
		shutil.rmtree(self.skin_base_dir + "mySkin_off")

def keySort_new(self):
	if self.showfold:
		self.showfold = False
	else:
		self.showfold = True
	self["menu"].setIndex(0)	
	self.createMenuList()		

def selectionChanged_new(self):
	sel = self["menu"].getCurrent()
	self.setPicture(sel[0])
	if sel is not None:
		if sel[2] == self.enabled_pic:
			self["key_green"].setText(_("off"))
		elif sel[2] == self.disabled_pic:
			self["key_green"].setText(_("on"))
		elif sel[2] == self.folder_pic:
			self["key_green"].setText(_("Select"))			
	
def createMenuList_new(self):
	global cur_filter
	chdir(self.skin_base_dir)
	f_list = []
	f_list_fold = []	
	dir_path = self.skin_base_dir + self.screen_dir
	if not path.exists(dir_path):
		makedirs(dir_path)
	file_dir_path = self.skin_base_dir + self.file_dir
	if not path.exists(file_dir_path):
		makedirs(file_dir_path)
	list_dir = sorted(listdir(dir_path), key=str.lower)
	for f in list_dir:
		if f.endswith('.xml') and f.startswith('skin_'):
			friendly_name = f.replace("skin_", "")
			friendly_name = friendly_name.replace(".xml", "")
			friendly_name = friendly_name.replace("_", " ")
			filter_name = friendly_name.split() or ""
			linked_file = file_dir_path + "/" + f
			if path.exists(linked_file):
				if path.islink(linked_file):
					pic = self.enabled_pic
				else:
					remove(linked_file)
					symlink(dir_path + "/" + f, file_dir_path + "/" + f)
					pic = self.enabled_pic
			else:
				pic = self.disabled_pic
			f_list.append((f, friendly_name, pic, filter_name[0]))
			f_list_fold.append(filter_name[0])

	menu_list = [ ]

	if self.showfold:
		f_list_fold = list(set(f_list_fold))
		f_list_fold.sort()
		
		for entry in f_list_fold:
			menu_list.append(("", entry, self.folder_pic))
		
		for entry in f_list:
			if entry[3] == cur_filter: 
				menu_list.append((entry[0], entry[1], entry[2]))
	else:
		for entry in f_list:
			menu_list.append((entry[0], entry[1], entry[2]))	
	
	self["menu"].updateList(menu_list)
	self.selectionChanged()

def runMenuEntry_new(self):
	global cur_filter
	sel = self["menu"].getCurrent()
	if sel is not None:
		if sel[2] == self.folder_pic:
			cur_filter = sel[1]
		elif sel[2] == self.enabled_pic:
			remove(self.skin_base_dir + self.file_dir + "/" + sel[0])
		elif sel[2] == self.disabled_pic:
			found = False
			for check in checkPlugins:
				compare = sel[1].split(" ")
				for comp in compare:
					if check[1] == comp and not fileExists(pathPlugins+check[0]+"/plugin.py"):
						found = True
						plugmiss = check[0]
						break
			if found==False:
				symlink(self.skin_base_dir + self.screen_dir + "/" + sel[0], self.skin_base_dir + self.file_dir + "/" + sel[0])				
			else:
				mess = ("Plugin %s ist nicht installiert!") % plugmiss
				self.session.open(MessageBox,mess, type = 3, timeout = 5) 
				print"[CerX FHD] Plugin for Skinpart not installed!"
		self.createMenuList()
		
def setPicture_new(self, f):
	pic = f.replace(".xml", "")
	preview = self.skin_base_dir + "preview/preview_" + pic
	if path.exists(preview + ".jpg"):
		self["Picture"].instance.setPixmap(loadJPG(preview + ".jpg"))
		self["Picture"].show()
	elif path.exists(preview + ".png"):
		self["Picture"].instance.setPixmap(loadPNG(preview + ".png"))
		self["Picture"].show()		
	else:
		self["Picture"].hide()
		
#
# Eventview	aus AEL mit TMDb	
#

def AEL_EventViewBase_init_new(self, Event, Ref, callback=None, similarEPGCB=None):
	from Components.Sources.ExtEvent import ExtEvent
	from Components.Sources.ServiceEvent import ServiceEvent
	self.db = getDB()
	self.trailer = None
	if not AutoTimerHook.CHECKAUTOTIMER:
		AutoTimerHook.initAutoTimerGlobals()
	self.screentitle = _("Eventview")
	self.similarEPGCB = similarEPGCB
	self.cbFunc = callback
	self.currentService=Ref
	path = Ref.ref.getPath()
	self.isRecording = (not Ref.ref.flags & eServiceReference.isGroup) and path
	if path.find('://') != -1:
		self.isRecording = None
	self.event = Event
	self["epg_description"] = ScrollLabel()
	self["datetime"] = Label()
	self["channel"] = Label()
	self["duration"] = Label()
	self["key_red"] = Button("")
	self["ExtEvent"] = ExtEvent()
	self["Service"] = ServiceEvent()
	self["trailer"] = Pixmap()
	if similarEPGCB is not None:
		self.SimilarBroadcastTimer = eTimer()
		self.SimilarBroadcastTimer.callback.append(self.getSimilarEvents)
	else:
		self.SimilarBroadcastTimer = None
	self.key_green_choice = self.ADD_TIMER
	if self.isRecording:
		self["key_green"] = Button("")
	else:
		self["key_green"] = Button(_("Add timer"))
	self["key_yellow"] = Button("")
	self["key_blue"] = Button("")
	
	# TMDb installed?
	try:
		from Plugins.Extensions.tmdb.tmdb import tmdbScreen
		self["key_yellow"] = Button(_("TMDb Infos ..."))
	except ImportError:
		pass	

	def key_play_handler():
		if self.trailer:
			global leavePlayerfromTrailer
			leavePlayerfromTrailer = True
			sRef = eServiceReference(4097, 0, str(self.trailer))
			sRef.setName(str(self.event.getEventName()))
			self.session.open(MoviePlayer,sRef)

	self["actions"] = ActionMap(["OkCancelActions", "EventViewActions", "ColorActions"],
		{
			"cancel": self.close,
			"ok": self.close,
			"pageUp": self.pageUp,
			"pageDown": self.pageDown,
			"prevEvent": self.prevEvent,
			"nextEvent": self.nextEvent,
			"timerAdd": self.timerAdd,
			"instantTimer": self.addInstantTimer,
			"openSimilarList": self.openSimilarList,
			"yellow": self.tmdbSearch,
		})
	self["menu_actions"] =  HelpableActionMap(self, "MenuActions", {
			"menu": (self.menuClicked, _("Setup")),
		},-2)
	self["aelactions"] = ActionMap(["AdvancedEventLibraryActions"],
		{
			"key_play": key_play_handler,
		},-1)
	self.onShown.append(self.onCreate)

def tmdbSearch(self):
	self.tmdb_plugin_installed = False
	try:
		from Plugins.Extensions.tmdb.tmdb import tmdbScreen
		name = self.event.getEventName() or info.getName() or ''
		self.session.open(tmdbScreen, name, 2)
	except ImportError:
		pass

#
# Virtual Keyboard		
#
	
def setLang_new(self):
	if self.lang == 'de_DE':
		self.keys_list = [
			u"EXIT", u"1", u"2", u"3", u"4", u"5", u"6", u"7", u"8", u"9", u"0", u"ß",
			u"q", u"w", u"e", u"r", u"t", u"z", u"u", u"i", u"o", u"p", u"ü", u"+",
			u"a", u"s", u"d", u"f", u"g", u"h", u"j", u"k", u"l", u"ö", u"ä", u"#",
			u"<", u"y", u"x", u"c", u"v", u"b", u"n", u"m", u",", ".", u"-", u"@",
			u"?", u"*", u"^", u"\\", u"(", u")",u"|", u"CLEAR", u"SHIFT", u"SPACE", u"LEFT", u"RIGHT",
			u"BACKSPACE", u"OK"] # characters added for RegEx search in Autotimer
		self.shiftkeys_list = [
			u"EXIT", u"!", u'"', u"§", u"$", u"%", u"&", u"/", u"(", u")", u"=", u"?",
			u"Q", u"W", u"E", u"R", u"T", u"Z", u"U", u"I", u"O", u"P", u"Ü", u"*",
			u"A", u"S", u"D", u"F", u"G", u"H", u"J", u"K", u"L", u"Ö", u"Ä", u"'",
			u">", u"Y", u"X", u"C", u"V", u"B", u"N", u"M", u";", u":", u"_", u"\\",
			u"{", u"}", u"[", u"]", u"CLEAR", u"SHIFT", u"SPACE", u"LEFT", u"RIGHT", u"BACKSPACE", u"OK"]
		self.nextLang = 'pl_PL'
	elif self.lang == 'pl_PL':
		self.keys_list = [
			u"EXIT", u"1", u"2", u"3", u"4", u"5", u"6", u"7", u"8", u"9", u"0", u"ó",
			u"q", u"w", u"e", u"r", u"t", u"y", u"u", u"i", u"o", u"p", u"[]", u"+",
			u"a", u"s", u"d", u"f", u"g", u"h", u"j", u"k", u"l", u"ł", u"@", u"#",
			u"<", u"z", u"x", u"c", u"v", u"b", u"n", u"m", u",", ".", u"-",
			u"ą", u"ę", u"ć", u"ś", u"ł", u"ń", u"ź", u"ż",
			u"CLEAR", u"SHIFT", u"SPACE", u"LEFT", u"RIGHT", u"BACKSPACE", u"OK"]
		self.shiftkeys_list = [
			u"EXIT", u"!", u'"', u"§", u"$", u"%", u"&", u"/", u"(", u")", u"=", u"?",
			u"Q", u"W", u"E", u"R", u"T", u"Y", u"U", u"I", u"O", u"P", u"Ó", u"*",
			u"A", u"S", u"D", u"F", u"G", u"H", u"J", u"K", u"L", u"Ł", u"<", u"'",
			u">", u"Z", u"X", u"C", u"V", u"B", u"N", u"M", u";", u":", u"_",
			u"\\", u"Ą", u"Ę", u"Ć", u"Ś", u"Ń", u"Ź", u"Ż",
			u"CLEAR", u"SHIFT", u"SPACE", u"LEFT", u"RIGHT", u"BACKSPACE", u"OK"]
		self.nextLang = 'es_ES'
	elif self.lang == 'es_ES':
		#still missing keys (u"ùÙ")
		self.keys_list = [
			u"EXIT", u"1", u"2", u"3", u"4", u"5", u"6", u"7", u"8", u"9", u"0", u"ň",
			u"q", u"w", u"e", u"r", u"t", u"z", u"u", u"i", u"o", u"p", u"ú", u"+",
			u"a", u"s", u"d", u"f", u"g", u"h", u"j", u"k", u"l", u"ó", u"á", u"#",
			u"<", u"y", u"x", u"c", u"v", u"b", u"n", u"m", u",", ".", u"-",
			u"@", u"Ł", u"ŕ", u"é", u"č", u"í", u"ě", u"ń",
			u"CLEAR", u"SHIFT", u"SPACE", u"LEFT", u"RIGHT", u"BACKSPACE", u"OK"]
		self.shiftkeys_list = [
			u"EXIT", u"!", u'"', u"§", u"$", u"%", u"&", u"/", u"(", u")", u"=", u"?",
			u"Q", u"W", u"E", u"R", u"T", u"Z", u"U", u"I", u"O", u"P", u"Ú", u"*",
			u"A", u"S", u"D", u"F", u"G", u"H", u"J", u"K", u"L", u"Ó", u"Á", u"'",
			u">", u"Y", u"X", u"C", u"V", u"B", u"N", u"M", u";", u":", u"_",
			u"\\", u"Ŕ", u"É", u"Č", u"Í", u"Ě", u"Ń", u"Ň",
			u"CLEAR", u"SHIFT", u"SPACE", u"LEFT", u"RIGHT", u"BACKSPACE", u"OK"]
		self.nextLang = 'fi_FI'
	elif self.lang == 'fi_FI':
		self.keys_list = [
			u"EXIT", u"1", u"2", u"3", u"4", u"5", u"6", u"7", u"8", u"9", u"0", u"ß",
			u"q", u"w", u"e", u"r", u"t", u"z", u"u", u"i", u"o", u"p", u"é", u"+",
			u"a", u"s", u"d", u"f", u"g", u"h", u"j", u"k", u"l", u"ö", u"ä", u"#",
			u"<", u"y", u"x", u"c", u"v", u"b", u"n", u"m", u",", ".", u"-", u"@", u"ĺ",
			u"CLEAR", u"SHIFT", u"SPACE", u"LEFT", u"RIGHT", u"BACKSPACE", u"OK"]
		self.shiftkeys_list = [
			u"EXIT", u"!", u'"', u"§", u"$", u"%", u"&", u"/", u"(", u")", u"=", u"?",
			u"Q", u"W", u"E", u"R", u"T", u"Z", u"U", u"I", u"O", u"P", u"É", u"*",
			u"A", u"S", u"D", u"F", u"G", u"H", u"J", u"K", u"L", u"Ö", u"Ä", u"'",
			u">", u"Y", u"X", u"C", u"V", u"B", u"N", u"M", u";", u":", u"_", u"\\", u"Ĺ",
			u"CLEAR", u"SHIFT", u"SPACE", u"LEFT", u"RIGHT", u"BACKSPACE", u"OK"]
		self.nextLang = 'sv_SE'
	elif self.lang == 'sv_SE':
		self.keys_list = [
			u"EXIT", u"1", u"2", u"3", u"4", u"5", u"6", u"7", u"8", u"9", u"0", u"ß",
			u"q", u"w", u"e", u"r", u"t", u"z", u"u", u"i", u"o", u"p", u"é", u"+",
			u"a", u"s", u"d", u"f", u"g", u"h", u"j", u"k", u"l", u"ö", u"ä", u"#",
			u"<", u"y", u"x", u"c", u"v", u"b", u"n", u"m", u",", ".", u"-", u"@", u"ĺ",
			u"CLEAR", u"SHIFT", u"SPACE", u"LEFT", u"RIGHT", u"BACKSPACE", u"OK"]
		self.shiftkeys_list = [
			u"EXIT", u"!", u'"', u"§", u"$", u"%", u"&", u"/", u"(", u")", u"=", u"?",
			u"Q", u"W", u"E", u"R", u"T", u"Z", u"U", u"I", u"O", u"P", u"É", u"*",
			u"A", u"S", u"D", u"F", u"G", u"H", u"J", u"K", u"L", u"Ö", u"Ä", u"'",
			u">", u"Y", u"X", u"C", u"V", u"B", u"N", u"M", u";", u":", u"_", u"\\", u"Ĺ",
			u"CLEAR", u"SHIFT", u"SPACE", u"LEFT", u"RIGHT", u"BACKSPACE", u"OK"]
		self.nextLang = 'sk_SK'
	elif self.lang =='sk_SK':
		self.keys_list = [
			u"EXIT", u"1", u"2", u"3", u"4", u"5", u"6", u"7", u"8", u"9", u"0", u"é",
			u"q", u"w", u"e", u"r", u"t", u"z", u"u", u"i", u"o", u"p", u"ú", u"+",
			u"a", u"s", u"d", u"f", u"g", u"h", u"j", u"k", u"l", u"ľ", u"@", u"#",
			u"<", u"y", u"x", u"c", u"v", u"b", u"n", u"m", u",", ".", u"-", u"š",
			u"č", u"ž", u"ý", u"á", u"í",
			u"CLEAR", u"SHIFT", u"SPACE", u"LEFT", u"RIGHT", u"BACKSPACE", u"OK"]
		self.shiftkeys_list = [
			u"EXIT", u"!", u'"', u"§", u"$", u"%", u"&", u"/", u"(", u")", u"=", u"?",
			u"Q", u"W", u"E", u"R", u"T", u"Z", u"U", u"I", u"O", u"P", u"ť", u"*",
			u"A", u"S", u"D", u"F", u"G", u"H", u"J", u"K", u"L", u"ň", u"ď", u"'",
			u"Á", u"É", u"Ď", u"Í", u"Ý", u"Ó", u"Ú", u"Ž", u"Š", u"Č", u"Ť", u"Ň",
			u">", u"Y", u"X", u"C", u"V", u"B", u"N", u"M", u";", u":", u"_",
			u"\\", u"ä", u"ö", u"ü", u"ô", u"ŕ", u"ĺ",
			u"CLEAR", u"SHIFT", u"SPACE", u"LEFT", u"RIGHT", u"BACKSPACE", u"OK"]
		self.nextLang = 'cs_CZ'
	elif self.lang == 'cs_CZ':
		self.keys_list = [
			u"EXIT", u"1", u"2", u"3", u"4", u"5", u"6", u"7", u"8", u"9", u"0", u"é",
			u"q", u"w", u"e", u"r", u"t", u"z", u"u", u"i", u"o", u"p", u"ú", u"+",
			u"a", u"s", u"d", u"f", u"g", u"h", u"j", u"k", u"l", u"ů", u"@", u"#",
			u"<", u"y", u"x", u"c", u"v", u"b", u"n", u"m", u",", ".", u"-",
			u"ě", u"š", u"č", u"ř", u"ž", u"ý", u"á", u"í",
			u"CLEAR", u"SHIFT", u"SPACE", u"LEFT", u"RIGHT", u"BACKSPACE", u"OK"]
		self.shiftkeys_list = [
			u"EXIT", u"!", u'"', u"§", u"$", u"%", u"&", u"/", u"(", u")", u"=", u"?",
			u"Q", u"W", u"E", u"R", u"T", u"Z", u"U", u"I", u"O", u"P", u"ť", u"*",
			u"A", u"S", u"D", u"F", u"G", u"H", u"J", u"K", u"L", u"ň", u"ď", u"'",
			u">", u"Y", u"X", u"C", u"V", u"B", u"N", u"M", u";", u":", u"_",
			u"\\", u"Č", u"Ř", u"Š", u"Ž", u"Ú", u"Á", u"É",
			u"CLEAR", u"SHIFT", u"SPACE", u"LEFT", u"RIGHT", u"BACKSPACE", u"OK"]
		self.nextLang = 'en_EN'
	else:
		self.keys_list = [
			u"EXIT", u"1", u"2", u"3", u"4", u"5", u"6", u"7", u"8", u"9", u"0", u"-",
			u"q", u"w", u"e", u"r", u"t", u"z", u"u", u"i", u"o", u"p", u"+", u"@",
			u"a", u"s", u"d", u"f", u"g", u"h", u"j", u"k", u"l", u"#", u"\\", u"|",
			u"<", u"y", u"x", u"c", u"v", u"b", u"n", u"m", u",", ".",
			u"CLEAR", u"SHIFT", u"SPACE", u"LEFT", u"RIGHT", u"BACKSPACE", u"OK"]
		self.shiftkeys_list = [
			u"EXIT", u"!", u'"', u"§", u"$", u"%", u"&", u"/", u"(", u")", u"=", u"_",
			u"Q", u"W", u"E", u"R", u"T", u"Z", u"U", u"I", u"O", u"P", u"*", u"[",
			u"A", u"S", u"D", u"F", u"G", u"H", u"J", u"K", u"L", u"'", u"?", u"]",
			u">", u"Y", u"X", u"C", u"V", u"B", u"N", u"M", u";", u":",
			u"CLEAR", u"SHIFT", u"SPACE", u"LEFT", u"RIGHT", u"BACKSPACE", u"OK"]
		self.lang = 'en_EN'
		self.nextLang = 'de_DE'
	u_chars = ""
	self.setLangMapping(self.lang)
	for x in self.mapping:
		u_chars += x
	self.setUseableChars(u'%s' % u_chars)
	self.keys_list = self.buildKeyBoardLayout(self.keys_list)
	self.shiftkeys_list = self.buildKeyBoardLayout(self.shiftkeys_list)
	self["country"].setText(self.lang)

#
# GMEPG
#

# GMEPG fix	(included in VTi 20201211)	
#def moveToService_new(self,serviceref):
#	if serviceref is not None:
#		for x in range(len(self.list)):
#			if self.list[x][0] == serviceref.toString():
#				self.instance.moveSelectionTo(x)
#				break
#			if self.list[x][0] == serviceref.toString().split("http")[0]:
#				self.instance.moveSelectionTo(x)
#				break

def timerAdd_new(self, instantTimer = False):
	cur = self["list"].getCurrent()
	event = cur[0]
	serviceref = cur[1]
	if event is None:
		return
	eventid = event.getEventId()
	refstr = serviceref.ref.toString()
	
	if self.key_green_choice == self.ENABLE_TIMER:
		for timer in self.session.nav.RecordTimer.processed_timers:
			if timer.eit == eventid and timer.service_ref.ref.toString() == refstr and timer.disabled == True:
				if instantTimer:
					self.removeTimer(timer, True)
				else:
					cb_func = lambda ret : not ret or self.removeTimer(timer)
					self.session.openWithCallback(cb_func, MessageBox, _("Do you really want to delete %s?") % event.getEventName())
				break
	else:
		for timer in self.session.nav.RecordTimer.timer_list:
			if timer.eit == eventid and timer.service_ref.ref.toString() == refstr:
				if instantTimer:
					self.removeTimer(timer, True)
					break
				else:
					cb_func = lambda ret : not ret or self.removeTimer(timer)
					self.session.openWithCallback(cb_func, MessageBox, _("Do you really want to delete %s?") % event.getEventName())
					break
		else:
			newEntry = RecordTimerEntry(serviceref, checkOldTimers = True, allow_duplicate = config.usage.timer_allow_duplicate.value, *parseEvent(event))
			if instantTimer:
				if config.usage.timer_ask_path.value and config.movielist.videodirs.value and len(config.movielist.videodirs.value) > 1:
					choicelist = []
					for x in config.movielist.videodirs.value:
						choicelist.append((x,x))
					idx = 0
					pref = (preferredTimerPath(), preferredTimerPath())
					if pref in choicelist:
						idx = choicelist.index(pref)
					self.session.openWithCallback(self.askTimerPath, ChoiceBox, title=_("Timer record location"), list = choicelist, selection = idx)
				else:
					self.session.nav.RecordTimer.saveTimer()
					self.finishedAdd((True, newEntry), True)
			else:
				if AutoTimerHook.AUTOTIMER_OK and config.usage.ask_for_timer_typ.value:
					liste = AutoTimerHook.getChoiceList()
					liste.insert(0,(_("zap"),"justplay"))
					liste.insert(1,(_("reminder"),"justremind"))
					self.session.openWithCallback(self.askTimerType, ChoiceBox, title=_("Select timer type..."), list = liste)
				else:
					self.session.openWithCallback(self.finishedAdd, TimerEntry, newEntry)

def askTimerType_new(self, ret = None):
	if ret:
		cur = self["list"].getCurrent()
		event = cur[0]
		serviceref = cur[1]
		if event is None:
			return
		if ret[1] == "default":
			newEntry = RecordTimerEntry(serviceref, checkOldTimers = True, dirname = preferredTimerPath(), allow_duplicate = config.usage.timer_allow_duplicate.value, *parseEvent(event))
			self.session.openWithCallback(self.finishedAdd, TimerEntry, newEntry)
		elif ret[1] == "justplay":
			evt = parseEvent(event)
			evt = list(evt)
			evt[0] += config.recording.margin_before.value * 60
			evt[1] = evt[0]
			newEntry = RecordTimerEntry(serviceref, justplay= True, checkOldTimers = True, dirname = preferredTimerPath(), allow_duplicate = config.usage.timer_allow_duplicate.value, *evt)
			self.session.openWithCallback(self.finishedAdd, TimerEntry, newEntry)
		elif ret[1] == "justremind":
			evt = parseEvent(event)
			evt = list(evt)
			evt[0] += config.recording.margin_before.value * 60
			evt[1] = evt[0]
			newEntry = RecordTimerEntry(serviceref, justremind= True, checkOldTimers = True, dirname = preferredTimerPath(), allow_duplicate = config.usage.timer_allow_duplicate.value, *evt)
			self.session.openWithCallback(self.finishedAdd, TimerEntry, newEntry)
		elif ret[1] == "autotimer":
			AutoTimerHook.addAutotimerFromEvent(self.session,evt = event, service = serviceref)
		elif ret[1] == "show_autotimer":
			AutoTimerHook.AutoTimerOverView(self.session)
		elif ret[1] == "show_timerlist":
			self.session.open(TimerEditList)

#
# LocationBox without bookmark creation
#
def MLB_init_new(self, session, text, dir, minFree = None):
	inhibitDirs = ["/bin", "/boot", "/dev", "/etc", "/lib", "/proc", "/sbin", "/sys", "/usr", "/var"]
	LocationBox.__init__(self, session, text = text, currDir = dir, bookmarks = config.movielist.videodirs, autoAdd = False, editDir = True, inhibitDirs = inhibitDirs, minFree = minFree)
	self.skinName = "LocationBox"

#
# EPGSearch use active bouquet only
#
def getBouquetServices_new(self):
	services = []
	InfoBar_Instance = InfoBar.instance
	servicelist = InfoBar_Instance.servicelist
	bouquets = servicelist.getBouquetList()

	if servicelist is not None:
		bouquet = servicelist.getRoot()
		bname = bouquet.toString()
		str_name = "?"
		ref = "?"
		pos = bname.find(' (TV)') or bname.find(' (Radio)')
		ref = bname[:pos]
		curBouquet = ServiceReference(ref).getServiceName()
	
	if bouquets and bouquets is not None:
		for bouquet in bouquets:
			servicelist = eServiceCenter.getInstance().list(bouquet[1])
			if not servicelist is None:
				while True:
					service = servicelist.getNext()
					if not service.valid(): #check if end of list
						break
					if service.flags & (eServiceReference.isDirectory | eServiceReference.isMarker): #ignore non playable services
						continue
					if config.plugins.CerxFHD.searchcurbouquet.value and bouquet[0] == curBouquet:
						services.append(service.toString())
					if not config.plugins.CerxFHD.searchcurbouquet.value:
						services.append(service.toString())
	return services

#
# EPGSelection EPGbar Crash mit Streaming Senderzuweisung
#
def zapTo_new(self): # just used in multiepg
	if self.zapFunc and self.key_red_choice == self.ZAP:
		lst = self["list"]
		count = lst.getCurrentChangeCount()
		if count == 0:
			self.closeRecursive = True
			ref = lst.getCurrent()[1]
			if not ref: # this could be none if we have no event data in SingleEPG or EPGBar
				ref = self.currentService
			check_bouquet = False
			if self.type == EPG_TYPE_EPGBAR or self.type == EPG_TYPE_SINGLE:
				check_bouquet = True
			print"[CerX FHD] EpgSelection Bug: Workaround"
			#print"######", str(ref).count("http")
			if not str(ref).count("http") >= 1:
				self.zapFunc(ref.ref, check_bouquet)
			if self.type == EPG_TYPE_EPGBAR:
				self.closeScreen()
			elif self.type == EPG_TYPE_SINGLE and not config.usage.servicelist_preview_mode.value:
				self.closeScreen()


#	
# Replace
#
if cur_skin == 'CerxFHD' or cur_skin == 'AtileHD':
	AtileHD_Config.getInitConfig = getInitConfig_new
	AtileHD_Config.createConfigList = createConfigList_new
	AtileHD_Config.setPicture = setPicture_new
	AtileHDScreens.__init__ = init_new
	AtileHDScreens.createMenuList = createMenuList_new
	AtileHDScreens.selectionChanged = selectionChanged_new
	AtileHDScreens.runMenuEntry = runMenuEntry_new
	AtileHDScreens.setPicture = setPicture_new
	AtileHDScreens.keyReset_new = keyReset_new
	AtileHDScreens.keySort_new = keySort_new
	VirtualKeyBoard.setLang = setLang_new
	EventViewBase.tmdbSearch = tmdbSearch
	MovieLocationBox.__init__ = MLB_init_new
	if gmepgInstalled:
		GraphMultiEPG.timerAdd = timerAdd_new
		GraphMultiEPG.askTimerType = askTimerType_new
	if epgsearchInstalled:
		EPGSearch.getBouquetServices = getBouquetServices_new
	if epgselectionInstalled:
		EPGSelection.zapTo = zapTo_new
	if aelInstalled:
		AELplugin.EventViewBase__init__ = AEL_EventViewBase_init_new
