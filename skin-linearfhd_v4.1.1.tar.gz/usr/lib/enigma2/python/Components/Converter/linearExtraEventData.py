# License: this is closed source!
# you are not allowed to use this Converter or parts of it  on any other image than VTI
# you are not allowed to use this Converter or parts of it  on NON VU Hardware
# Copyright: hmmmmdada 2018, mod by @Eisman for linearFHD
#
# Apr.2018    (g55)   a) change separation symbol from "B7" to "2022" (bigger dot) as default, as font HandelgotD has wrong "b7"
#                        Alternatives could be : 2026 (3 dots, but not in DroidSans), 2014 (long minus)
#                     b) add field for separator unicode (U+) character, insert f.e. "SEP=B7". Everythin after the "=" will be taken as unicode HEX number.
#                        valid U+ numbers start from "20" and are depending on the used font.
#                     c) modify exceptions, replace "," with "as" to get exception value
# May 2018		(g55)		add string "FSK " to "AGE" field
# Apr 2019 		(Nathanael)		add Leadtext

from Components.Converter.Converter import Converter
from Components.Element import cached
import json
import HTMLParser

class linearExtraEventData(Converter, object):

	def __init__(self, type):
		Converter.__init__(self, type)
		self.type = str(type).split()

	@cached
	def getText(self):
		h = HTMLParser.HTMLParser()
		if self.type != '':
			rets = []
			ret = ""
			gotevent = False
			try:
				if str(self.source.text) != '':
					values = json.loads(str(self.source.text))
					#print "[linearExtraEventData] 1: ", values
					gotevent = True
			except Exception as ex1:
				#print "[linearExtraEventData] ex1: %s" % str(ex1)
				try:
					if str(self.source) != '':
						values = json.loads(self.source)
						#print "[linearExtraEventData] 2: ", values
						gotevent = True
				except Exception as ex2:
					#print "[linearExtraEventData] ex2: %s" % str(ex2)
					pass
			if gotevent and values:
				sep = " %s " % str(h.unescape('&#x2022;'))
				for field in self.type:
					if field == "IMAGE":
						if len(str(values['id']).strip()) > 0:
							return str(values['id']).strip()
					elif field == "TITLE":
						if len(str(values['title']).strip()) > 0:
							rets.append(str(values['title']).strip())
					elif field == "SUBTITLE":
						if len(str(values['subtitle']).strip()) > 0:
							rets.append(str(values['subtitle']).strip())
					elif field == "SERIESINFO":
						if 'season' in values and 'episode' in values:
							if len(str(values['season']).strip()) > 0 and len(str(values['episode']).strip()) > 0:
								rets.append("S%sE%s" % (str(values['season']).zfill(2), str(values['episode']).zfill(2)))
					elif field == "CATEGORY":
						if 'categoryName' in values:
							if len(str(values['categoryName']).strip()) > 0:
								rets.append(str(values['categoryName']).strip())
					elif field == "GENRE":
						if 'genre' in values:
							if len(str(values['genre']).strip()) > 0:
								rets.append(str(values['genre']).strip())
					elif field == "AGE":
						if 'ageRating' in values:
							if len(str(values['ageRating']).strip()) > 0:
								rets.append("FSK " + str(values['ageRating']).strip())
					elif field == "YEAR":
						if 'year' in values:
							if len(str(values['year']).strip()) > 0:
								rets.append(str(values['year']).strip())
					elif field == "COUNTRY":
						if 'country' in values:
							if len(str(values['country']).strip()) > 0:
								rets.append(str(values['country']).strip())
					elif field == "LEADTEXT":
						if 'leadText' in values:
							if len(str(values['leadText']).strip()) > 0:
								rets.append(str(values['leadText']).strip())            
					elif field.startswith('SEP='):
						sepchars = '&#x' + field.split('=')[1].strip() + ';'
						sep = " %s " % str(h.unescape(sepchars))

				ret = sep.join(rets)
		return ret

	text = property(getText)