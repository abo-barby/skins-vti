# -*- coding: utf-8 -*-
# License: this is closed source!
# you are not allowed to use this Renderer outside of linearFHD Skin
# you are not allowed to use this Renderer on any other image than VTI
# you are not allowed to use this Renderer on NON VU Hardware
# Copyright: hmmmmdada 2016
from Renderer import Renderer
from enigma import ePixmap, loadJPG, loadPNG, eSize, ePoint, eTimer, eLabel, eWidget
from Components.AVSwitch import AVSwitch
from Components.Pixmap import Pixmap
from Components.config import config
from Components.Sources.ServiceEvent import ServiceEvent
from Components.Sources.CurrentService import CurrentService
from Components.Sources.Event import Event
from Components.Sources.extEventInfo import extEventInfo
from Components.Sources.ServiceEvent import ServiceEvent

from twisted.web.client import downloadPage, getPage, error
from os import path as os_path
import re, json, os, time
import math
import skin
import base64
from Tools.Directories import fileExists, pathExists
from collections import OrderedDict
from PIL import Image, ImageOps, ImageDraw, ImageFont
from Plugins.Extensions.EpgShare.main import getEPGDB

class linearInfobarDescription(Renderer):
	SHOW_COVER = 0
	SHOW_PREVIEW = 1
	SHOW_BOTH = 2
	COVERPOSITION_LEFT = 0
	COVERPOSITION_RIGHT = 1

	def __init__(self):
		Renderer.__init__(self)
		self.sourcetype = 0
		self.eventid = None
		self.nameCache = {}
		self.desc = ""
		self.noanimation = False
		self.pixmapcache = OrderedDict()
		self.downloads = []
		self.picname = ""
		self.WCover = self.HCover = self.TCover = self.LCover = self.WPreview = self.HPreview = self.TPreview = self.LPreview = 0
		self.mode = self.SHOW_BOTH
		self.coverposition = self.COVERPOSITION_LEFT
		self.margin = 20
		self.coverwidth = 200
		self.type = "0"
		self.title = ""
		self.cover = None
		self.description = None
		self.instance = None
		self.applyshadow = False

	GUI_WIDGET = eWidget

	# additional Skinattributes
	# covermode 0 = Cover only, 1 = Preview only, 2 = Cover or Preview
	# coverposition left/right
	# margin = space between cover an text
	# coverwidth
	#
	#
	def getimagesubfolder(self, timestamp):
		if str(config.plugins.epgShare.autocachelocation.value) == '/tmp/EPGImages':
			return ''
		else:
			return '/' + str(time.strftime("%D", time.localtime(int(timestamp)))).replace("/", ".")

	def applySkin(self, desktop, screen):
		if self.skinAttributes:
			attribs = []
			labelattribs = []
			coverattribs = []
			for (attrib, value) in self.skinAttributes:
				if attrib == "size":
					attribs.append((attrib, value))
					x, y = value.split(',')
					self.width, self.HCover = int(x), int(y)
				elif attrib == "covermode":
					self.mode = int(value)
				elif attrib == "coverposition":
					if str(value).lower() == "left":
						self.coverposition = self.COVERPOSITION_LEFT
					elif str(value).lower() == "right":
						self.coverposition = self.COVERPOSITION_RIGHT
				elif attrib == "margin":
					self.margin = int(value)
				elif attrib == "coverwidth":
					self.coverwidth = int(value)
				elif attrib in ["font", "foregroundColor"]:
					labelattribs.append((attrib, value))
				elif attrib == "backgroundColor":
					coverattribs.append((attrib, value))
					attribs.append((attrib, value))
					labelattribs.append((attrib, value))
				elif attrib == "alphatest":
					coverattribs.append((attrib, value))
				elif attrib == "valign":
					labelattribs.append((attrib, value))
				elif attrib == "halign":
					labelattribs.append((attrib, value))
				elif attrib == "applyShadow":
					if str(value) == "1":
						self.applyshadow = True
				elif attrib == "sourcetype":
					self.sourcetype = int(value)
				else:
					attribs.append((attrib, value))
			coverattribs.append(("size", "%d,%d" % (self.coverwidth, self.HCover)))
			if self.coverposition == self.COVERPOSITION_LEFT:
				coverattribs.append(("position", "%d,%d" % (0, 0)))
				labelattribs.append(("position", "%d,%d" % (self.coverwidth + self.margin, 0)))
			else:
				coverattribs.append(("position", "%d,%d" % (self.width - (self.coverwidth + self.margin), 0)))
				labelattribs.append(("position", "%d,%d" % (0, 0)))
			labelattribs.append(("size", "%d,%d" % (self.width - (self.margin + self.coverwidth), self.HCover)))
			self.skinAttributes = attribs
		self.applyAllAttributes(self.cover, desktop, coverattribs, screen.scale)
		self.applyAllAttributes(self.description, desktop, labelattribs, screen.scale)
		ret = Renderer.applySkin(self, desktop, screen)
		return ret

	def applyAllAttributes(self, guiObject, desktop, attributes, scale):
		for (attrib, value) in attributes:
			try:
				skin.applySingleAttribute(guiObject, desktop, attrib, value, scale)
			except Exception, ex:
				pass
		return True

	def GUIcreate(self, parent):
		self.instance = eWidget(parent)
		self.cover = ePixmap(self.instance)
		self.description = eLabel(self.instance)

	def GUIdelete(self):
		self.cover = None
		self.description = None
		self.instance = None

	def changed(self, what):
		if not self.instance:
			return
		event = self.source.event
		if event is None:
			self.resizedescription(False)
			self.description.setText("")
			self.description.show()
			self.eventid = None
			return
		description = ""
		self.resizedescription(False)
		if what[0] == self.CHANGED_CLEAR:
			self.eventid = None
		if what[0] != self.CHANGED_CLEAR:
			if self.sourcetype == 0:
				event = self.source.event[0]
			if event:
				if self.sourcetype == 0:
					self.type = self.source.event[1]
				description = event.getExtendedDescription()
				self.title = event.getEventName()
				self.instance.show()
				genre = ''
				search = ''
				cover = ''
				eventid = event.getEventId()
				try:
					#ExtraEventData = event.getExtraEventData()
					ExtraEventData = json.dumps(self.get_Extradata(self.source.service,str(eventid)))
				except:
					self.colorprint("Kein aktuelles VTi Image installiert.")
					return

				if ExtraEventData != '' and eventid:
					try:
						if eventid != self.eventid:
							self.colorprint("try exdata -> JSON")
							dict = json.loads(str(ExtraEventData))
							if self.mode in (0, 2):
								if 'genre' and 'search' in dict.keys():
									self.eventid = eventid
									url = str(dict['search'])
									genre = str(dict['categoryName'])
									if url != '':
										if genre != '':
											if url not in self.pixmapcache:
												if url not in self.downloads:
													self.instance.hide()
													self.picname = url
													self.downloads.append(str(url))
												else:
													self.showcover(url)
										else:
											if "id" in dict.keys():
												if str(dict['id']) != "":
													if self.loadImage(int(event.getBeginTime()),str(dict['id'])) == False:
														u = 'http://capi.tvmovie.de/v1/broadcast/%s?fields=images.id,previewImage.id' % str(dict['id'])
														self.resizedescription(False)
												else:
													self.resizedescription(False)
											else:
												self.resizedescription(False)
									else:
										if "id" in dict.keys():
											if str(dict['id']) != "":
												if self.loadImage(int(event.getBeginTime()),str(dict['id'])) == False:
													self.resizedescription(False)
											else:
												self.resizedescription(False)
										else:
											self.resizedescription(False)
								else:
									if "id" in dict.keys():
											if str(dict['id']) != "":
												if self.loadImage(int(event.getBeginTime()),str(dict['id'])) == False:
													self.resizedescription(False)
											else:
												self.resizedescription(False)
									else:
										self.resizedescription(False)
							elif self.mode == 1:
								if "id" in dict.keys():
											if str(dict['id']) != "":
												if self.loadImage(int(event.getBeginTime()),str(dict['id'])) == False:
													self.resizedescription(False)
											else:
												self.resizedescription(False)
								else:
										self.resizedescription(False)
							if "plot" in dict.keys():
								if str(dict['search']) != "":
									if description == "":
										description = str(dict['search'])


					except Exception, ex:
						self.colorprint("error: " + str(ex))
						description = event.getExtendedDescription()
						self.resizedescription(False)

				else:
					description = event.getExtendedDescription()
					self.resizedescription(False)
			self.description.setText(str(description))
			self.description.show()
			return

	def lookupCover(self, data, genre, eventid, url):
		path = '/tmp/IBcover_%s.jpg' % str(self.type)
		if genre == 'Serien':
			cover_id = re.findall('<seriesid>(.*?)</seriesid>', data, re.I)
			if cover_id:
				cover_url = "http://thetvdb.com/banners/_cache/posters/%s-1.jpg" % str(cover_id[0])
			else:
				self.resizedescription(False)
		elif genre == 'Spielfilm':
			cover_id = re.findall('"poster_path":".(.*?)"', data, re.I)
			if cover_id:
				cover_url = "http://image.tmdb.org/t/p/w185%s" % str(cover_id[0])
			else:
				self.resizedescription(False)

	def downloadingDone(self, data, path, eventid, url):
		if self.applyshadow:
			img = Image.open('/usr/share/enigma2/linearFHD/IBCoverbg.png').convert('RGBA')
			cover = Image.open(path).convert('RGBA')
			cover = cover.resize((210, 305), Image.ANTIALIAS)
			img.paste(cover, (44, 44))
			img.save('/tmp/IBcover_%s.png' % str(self.type))
			ptr = loadPNG('/tmp/IBcover_%s.png' % str(self.type))
			os.remove(path)
		else:
			ptr = loadJPG('/tmp/IBcover_%s.jpg' % str(self.type))
		if ptr:
			if len(self.pixmapcache) == 4:
				self.pixmapcache.popitem()
			self.downloads.remove(url)
			self.pixmapcache[url] = ptr
			self.showcover(url)
		else:
			self.resizedescription(False)

	def previewdownloaddone(self, data, mode, id, begintime):
		if mode == 0:
			try:
				i = json.loads(str(data))
				if 'previewImage' in i:
					url = 'http://images.tvmovie.de/220x142/North/%s' % str(i['previewImage']['id'])
					target = str(config.plugins.epgShare.autocachelocation.value) + self.getimagesubfolder(int(begintime)) + "/" + str(id) + ".jpg"
				else:
					p = str(config.plugins.epgShare.autocachelocation.value) + "/Default/" + base64.encode(self.title.lower())
					if os.path.exists(p):
						ptr = loadJPG(p)
						self.cover.setPixmap(ptr)
						self.cover.setScale(2)
						self.cover.show()
						self.resizedescription(True)
					else:
						self.resizedescription(False)
					self.resizedescription(False)
			except:
				self.resizedescription(False)
		else:
			p = str(config.plugins.epgShare.autocachelocation.value) + self.getimagesubfolder(int(begintime)) + "/" + str(id) + ".jpg"
			if fileExists(p):
				ptr = loadJPG(p)
				self.cover.setPixmap(ptr)
				self.cover.setScale(2)
				self.cover.show()
				self.resizedescription(True)
			else:
				p = str(config.plugins.epgShare.autocachelocation.value) + "/Default/" + base64.encode(self.title.lower())
				if os.path.exists(p):
					ptr = loadJPG(p)
					self.cover.setPixmap(ptr)
					self.cover.setScale(2)
					self.cover.show()
					self.resizedescription(True)
				else:
					self.resizedescription(False)


	def resizedescription(self, hascover=False):
		try:
			if hascover:
				if self.coverposition == self.COVERPOSITION_LEFT:
					self.description.move(ePoint(self.coverwidth + self.margin, 0))
					self.description.resize(eSize(self.width - (self.coverwidth + self.margin), self.HCover))
				else:
					self.description.resize(eSize(self.width - (self.coverwidth + self.margin), self.HCover))
			else:
				self.description.move(ePoint(0, 0))
				self.description.resize(eSize(self.width, self.HCover))
				self.cover.hide()
		except:
			pass

	def showcover(self, url):
		self.resizedescription(True)
		self.cover.setPixmap(self.pixmapcache[url])
		self.cover.setScale(2)
		self.cover.show()

	def downloadFailed(self, Error, eventid, url):
		self.resizedescription(False)
		self.downloads.remove(url)
		self.eventid = eventid

	def colorprint(self, stringvalue):
		color_print = "\033[92m"
		color_end = "\33[0m"
		print color_print + "[linearInfobarDescription] " + str(stringvalue) + color_end

	def get_Extradata(self, service, eventid, beginTime=None, EventName= None):
		try:
			data = None
			if "::" in str(service):
				service = service.split("::")[0] + ":"
			if "http" in str(service):
				service = service.split("http")[0]
			if not "1:0:0:0:0:0:0:0:0:0:" in service and not "4097:0:0:0:0:0:0:0:0:0:" in service:
				if beginTime and EventName:
					data = getEPGDB().selectSQL("SELECT * FROM epg_extradata WHERE ref = ? AND (eventid = ? or (LOWER(title) = ? and airtime BETWEEN ? AND ?))", [str(service), str(eventid),str(EventName.lower()).decode("utf-8"), str(int(beginTime) -120), str(int(beginTime) + 120) ])
				else:
					data = getEPGDB().selectSQL("SELECT * FROM epg_extradata WHERE ref = ? AND eventid = ?", [str(service), str(eventid)])
				if data and len(data) > 0:
					return data[0]
				else:
					return None
			else:
				return None
		except Exception, ex:
			self.colorprint( "DB Error: %s" % str(ex) )
			return None

	def loadImage(self, begin, id):
		p = str(config.plugins.epgShare.autocachelocation.value) + self.getimagesubfolder(begin) + "/" + id + ".jpg"
		self.colorprint("loadImage: " + p)
		if fileExists(p):
			ptr = loadJPG(p)
			self.cover.setPixmap(ptr)
			self.cover.setScale(2)
			self.cover.show()
			self.resizedescription(True)
			return True
		else:
			self.colorprint("Image not exist")
			return False
			
